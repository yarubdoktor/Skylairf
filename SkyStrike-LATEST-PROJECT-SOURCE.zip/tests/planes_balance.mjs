// يتأكد: ما في طائرة بتتفوق على غيرها بكل الصفات إلا إذا كانت أغلى منها
import fs from 'fs';
const src = fs.readFileSync(new URL('../src/data.js', import.meta.url), 'utf8');
const body = src.match(/export const PLANES = (\{[\s\S]*?\n\});/)[1];
const PLANES = new Function('return ' + body)();
const sc = p => [p.speed, p.turn, p.hp, -p.ab.ms];   // ms أقل = أحسن
let bad = 0, ids = Object.keys(PLANES);
for (const a of ids) for (const b of ids) if (a !== b) {
  const x = sc(PLANES[a]), y = sc(PLANES[b]);
  const dom = x.every((v, i) => v >= y[i]) && x.some((v, i) => v > y[i]);
  if (dom && PLANES[a].price <= PLANES[b].price && PLANES[a].price !== PLANES[b].price - 0 + 0 || (dom && PLANES[a].price < PLANES[b].price)) { console.log(`✗ ${a} أقوى من ${b} بكل شي وأرخص/مساوي`); bad++; }
}
console.log(ids.map(i => `${i}: ${PLANES[i].speed}/${PLANES[i].turn}/${PLANES[i].hp}/ms${PLANES[i].ab.ms}/$${PLANES[i].price}`).join('\n'));
console.log(bad ? `فشل: ${bad}` : 'تمام: ما في طائرة مسيطرة وأرخص');
process.exit(bad ? 1 : 0);
