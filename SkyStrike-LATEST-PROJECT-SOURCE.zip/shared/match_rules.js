/* قواعد الماتش (صرف: بلا DOM ولا three ولا استيراد من src). المصدر الوحيد للأرقام والقرارات D3/D5/D7/D11.
   يستعمله العميل والسيرفر معاً. الزمن بالثواني ما لم يُذكر غير ذلك. */
export const MAX_PLAYERS = 8, MIN_TO_START = 2, RESPAWN_S = 5, SCORE_LIMIT = 15, TIME_LIMIT_S = 480;
export const ASSIST_WINDOW_S = 8, SEND_HZ = 15, INTERP_DELAY_MS = 120, PORT = 2567, MIN_REWARD_S = 60;
export const GUN_DMG = 10, MSL_DMG = 83, MSL_AMMO = 7;
export const DMG = {gun: 10, msl: 83};

/* الفريق 0 غرباً يواجه الشرق، الفريق 1 شرقاً يواجه الغرب */
export const MP_MAPS = {island: {limit: 3200, spawns: [
  [{x: -2400, z: -450, yaw: -1.5708}, {x: -2400, z: -150, yaw: -1.5708},
    {x: -2400, z: 150, yaw: -1.5708}, {x: -2400, z: 450, yaw: -1.5708}],
  [{x: 2400, z: -450, yaw: 1.5708}, {x: 2400, z: -150, yaw: 1.5708},
    {x: 2400, z: 150, yaw: 1.5708}, {x: 2400, z: 450, yaw: 1.5708}]]}};

/* جهة الطيار البعيد نسبةً لفريقي */
export const teamSide = (myTeam, otherTeam) => (myTeam === otherTeam ? 'ally' : 'enemy');

/* counts = [n0, n1] ← رقم الفريق الأقل عدداً، والتعادل ← 0 */
export const balancedJoin = counts => (counts[1] < counts[0] ? 1 : 0);

/* النقل مسموح فقط إن كان فرق العددين بعده ≤ 1 */
export function canSwitch(counts, from, to){
  const c = [counts[0], counts[1]]; c[from]--; c[to]++;
  return Math.abs(c[0] - c[1]) <= 1;
}

/* players = [{id, team, ready}] ← {ok, code}. code = 'cannot_start' عند الفشل */
export function canStart(players, hostId){
  const n = [0, 0]; let allReady = true;
  for(const p of players){ n[p.team]++; if(p.id !== hostId && !p.ready) allReady = false; }
  const ok = players.length >= MIN_TO_START && n[0] > 0 && n[1] > 0 && allReady;
  return {ok, code: ok ? null : 'cannot_start'};
}

/* لوحة النتائج: p[id] = [k, a, d] · t = نقاط الفريقين */
export function newBoard(ids){
  const p = {}; for(const id of ids) p[id] = [0, 0, 0];
  return {p, t: [0, 0]};
}

/* تسجيل ضربة على الضحية: log[victimId] مصفوفة {att, t} */
export function recordHit(log, victimId, attackerId, now){
  (log[victimId] || (log[victimId] = [])).push({att: attackerId, t: now});
}

/* موت الضحية: القاتل = آخر مهاجم ضمن النافذة · المساعدون = بقية المختلفين ضمن النافذة (كل واحد مرة) */
export function resolveDeath(board, log, victimId, teamOf, now){
  const hits = (log[victimId] || []).filter(h => now - h.t <= ASSIST_WINDOW_S);
  const killer = hits.length ? hits[hits.length - 1].att : null, assists = [];
  for(const h of hits) if(h.att !== killer && !assists.includes(h.att)) assists.push(h.att);
  const row = id => board.p[id] || (board.p[id] = [0, 0, 0]);
  row(victimId)[2]++;
  if(killer !== null){ row(killer)[0]++; board.t[teamOf(killer)]++; }
  for(const a of assists) row(a)[1]++;
  delete log[victimId];
  return {killer, assists};
}

/* نهاية الماتش (D11): null أثناء اللعب، وإلا {win: 0|1|-1, reason: 'score'|'time'} */
export function checkEnd(board, elapsedS){
  const [a, b] = board.t;
  if(a >= SCORE_LIMIT || b >= SCORE_LIMIT) return {win: a > b ? 0 : b > a ? 1 : -1, reason: 'score'};
  if(elapsedS >= TIME_LIMIT_S) return {win: a > b ? 0 : b > a ? 1 : -1, reason: 'time'};
  return null;
}

export const personalScore = (k, a) => k * 100 + a * 50;

/* مكافأة الأونلاين الوحيدة التي تُحفظ (S.coins/S.xp) */
export function rewardOf(k, a, win, playedS){
  if(playedS < MIN_REWARD_S) return {c: 0, xp: 0};
  return {c: 20 + k * 15 + a * 7 + (win ? 40 : 0), xp: 30 + k * 20 + a * 10 + (win ? 50 : 0)};
}

export const spawnFor = (mapId, team, index) => MP_MAPS[mapId].spawns[team][index % 4];

export function hpState(hp, max){
  if(hp <= 0) return 'dead';
  const f = hp / max;
  return f < .3 ? 'crit' : f < .6 ? 'low' : 'ok';
}
