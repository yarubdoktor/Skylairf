/* بروتوكول الماتش (صرف: بلا DOM ولا three ولا استيراد من src). يستعمله العميل والسيرفر. القسم 6 من AI_PLAN.md.
   validate يغطي رسائل العميل ← السيرفر فقط؛ رسائل السيرفر ← العميل يثق بها العميل (سيرفر محلي، D3). */
export const PROTOCOL_VERSION = 1;
export const MAX_BYTES = 2048;

/* أنواع الرسائل (المفتاح = القيمة) */
export const T = Object.freeze({
  create: 'create', join: 'join', pick: 'pick', team: 'team', ready: 'ready', start: 'start', leave: 'leave',
  st: 'st', fire: 'fire', flr: 'flr', hit: 'hit', die: 'die', chat: 'chat',
  room: 'room', kill: 'kill', respawn: 'respawn', left: 'left', end: 'end', err: 'err'});

/* رموز الأخطاء */
export const ERR = Object.freeze({
  bad_msg: 'bad_msg', version: 'version', no_room: 'no_room', full: 'full', started: 'started',
  not_host: 'not_host', cannot_start: 'cannot_start', bad_state: 'bad_state', unbalanced: 'unbalanced'});

export const PLANE_IDS = ['mig29', 'su57', 'tomcat', 'eagle', 'falcon', 'hornet', 'raptor', 'lightning'];
export const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

const BAD = {ok: false, code: ERR.bad_msg};
const isNum = v => typeof v === 'number' && Number.isFinite(v);
const isInt = v => Number.isInteger(v);
const inR = (v, a, b) => isNum(v) && v >= a && v <= b;
const bit = v => v === 0 || v === 1;

/* اسم اللاعب: يزيل محارف التحكم، ويقصّ إلى 16 حرفاً (بالنقاط الرمزية حتى لا ينقطع رمز مزدوج) */
export function cleanName(s){
  if(typeof s !== 'string') return '';
  return Array.from(s.replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]/g, '')).slice(0, 16).join('').trim();
}

/* مخطط كل نوع: حقل ← دالة تحقق/تنظيف تعيد القيمة المنظّفة أو undefined عند الرفض */
const planeOk = v => PLANE_IDS.includes(v) ? v : undefined;
const skinOk = v => typeof v === 'string' && /^[a-z0-9_]{1,12}$/.test(v) ? v : undefined;
const lvlOk = v => isInt(v) && v >= 1 && v <= 99 ? v : undefined;
const nameOk = v => { const n = cleanName(v); return n ? n : undefined; };
const verOk = v => isInt(v) ? v : undefined;
const codeOk = v => {
  if(typeof v !== 'string') return undefined;
  const c = v.toUpperCase(); if(c === '') return '';
  return c.length === 4 && [...c].every(ch => CODE_CHARS.includes(ch)) ? c : undefined;
};
const num = (a, b) => v => inR(v, a, b) ? v : undefined;
const SCHEMA = {
  create: {v: verOk, name: nameOk, plane: planeOk, skin: skinOk, lvl: lvlOk},
  join: {v: verOk, code: codeOk, name: nameOk, plane: planeOk, skin: skinOk, lvl: lvlOk},
  pick: {plane: planeOk, skin: skinOk},
  team: {team: v => v === 0 || v === 1 ? v : undefined},
  ready: {on: v => typeof v === 'boolean' ? v : undefined},
  start: {}, leave: {}, die: {},
  st: {x: num(-20000, 20000), y: num(-1000, 20000), z: num(-20000, 20000), yw: num(-10, 10), pt: num(-10, 10),
    rl: num(-10, 10), sp: num(0, 2000), hp: v => isInt(v) && v >= 0 && v <= 1000 ? v : undefined,
    b: v => bit(v) ? v : undefined, g: v => bit(v) ? v : undefined},
  fire: {k: v => v === 'msl' ? v : undefined, tg: v => isInt(v) && v >= 0 ? v : undefined,
    x: num(-20000, 20000), y: num(-1000, 20000), z: num(-20000, 20000),
    dx: num(-1.5, 1.5), dy: num(-1.5, 1.5), dz: num(-1.5, 1.5)},
  flr: {x: num(-20000, 20000), y: num(-1000, 20000), z: num(-20000, 20000)},
  hit: {by: v => isInt(v) && v >= 0 ? v : undefined, k: v => v === 'gun' || v === 'msl' ? v : undefined},
  chat: {k: v => isInt(v) && v >= 0 && v <= 5 ? v : undefined}};

/* msg ← {ok:true, msg} بحقول منظّفة فقط (الحقول الزائدة تُسقط) أو {ok:false, code:'bad_msg'} */
export function validate(msg){
  if(!msg || typeof msg !== 'object' || Array.isArray(msg) || typeof msg.t !== 'string') return BAD;
  const sc = Object.prototype.hasOwnProperty.call(SCHEMA, msg.t) ? SCHEMA[msg.t] : null; if(!sc) return BAD;
  const out = {t: msg.t};
  for(const k of Object.keys(sc)){ const v = sc[k](msg[k]); if(v === undefined) return BAD; out[k] = v; }
  return {ok: true, msg: out};
}

const byteLen = s => new TextEncoder().encode(s).length;
export const encode = obj => JSON.stringify(obj);
/* str ← {ok:true, msg} أو {ok:false, code:'bad_msg'} (أكبر من 2048 بايت، أو JSON تالف، أو ليس كائناً بحقل t) */
export function decode(str){
  if(typeof str !== 'string' || byteLen(str) > MAX_BYTES) return BAD;
  let m; try{ m = JSON.parse(str); }catch(e){ return BAD; }
  if(!m || typeof m !== 'object' || Array.isArray(m) || typeof m.t !== 'string') return BAD;
  return {ok: true, msg: m};
}
