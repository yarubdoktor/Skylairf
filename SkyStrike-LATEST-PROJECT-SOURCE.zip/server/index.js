/* سيرفر Sky Strike (محلي فقط، R11): ws على PORT. يشغَّل بـ: cd server && npm install && npm start */
import {WebSocketServer} from 'ws';
import {PORT} from '../shared/match_rules.js';
import {MAX_BYTES, decode, encode, validate} from '../shared/protocol.js';
import {createRooms} from './rooms.js';

const LIMITS = {st: 30, hit: 40};                           // أقصى رسائل/ثانية لكل لاعب (الزائد يُسقط بصمت)
const PING_MS = 15000, TICK_MS = 500;

export function startServer(port = PORT){
  const wss = new WebSocketServer({port, maxPayload: MAX_BYTES});      // أكبر من 2048 بايت ← إغلاق الاتصال
  const conns = new Map(); let seq = 0;
  const send = (id, msg) => { const c = conns.get(id); if(c && c.ws.readyState === 1) c.ws.send(encode(msg)); };
  const rooms = createRooms({send, now: () => Date.now(), setTimer: setTimeout, clearTimer: clearTimeout});
  const tick = setInterval(() => rooms.tick(Date.now()), TICK_MS);
  const ping = setInterval(() => {
    for(const [id, c] of conns){
      if(c.miss >= 2){ console.log('timeout', id); c.ws.terminate(); continue; }
      c.miss++; try{ c.ws.ping(); }catch(e){}
    }
  }, PING_MS);
  const over = (c, t) => {                                   // حد المعدّل: نافذة ثانية
    const lim = LIMITS[t]; if(!lim) return false;
    const now = Date.now(), w = c.win[t] || (c.win[t] = {t0: now, n: 0});
    if(now - w.t0 >= 1000){ w.t0 = now; w.n = 0; }
    return ++w.n > lim;
  };
  wss.on('connection', ws => {
    const id = ++seq, c = {ws, miss: 0, win: {}}; conns.set(id, c); console.log('connect', id);
    ws.on('pong', () => { c.miss = 0; });
    ws.on('message', (data, isBinary) => {
      c.miss = 0;
      const d = isBinary ? null : decode(data.toString());
      const v = d && d.ok ? validate(d.msg) : null;
      if(!v || !v.ok){ send(id, {t: 'err', code: 'bad_msg'}); return; }
      if(over(c, v.msg.t)) return;
      const r = rooms.handle(id, v.msg);
      if(r.close) ws.close();
    });
    ws.on('close', () => { conns.delete(id); rooms.drop(id); console.log('close', id); });
    ws.on('error', () => {});
  });
  wss.on('close', () => { clearInterval(tick); clearInterval(ping); });
  console.log('Sky Strike server on ws://localhost:' + port);
  return {wss, rooms, close(){ for(const c of conns.values()) c.ws.terminate(); wss.close(); }};
}

const entry = process.argv[1] && process.argv[1].split(/[\\/]/).pop();
if(entry && import.meta.url.endsWith(entry)) startServer(Number(process.env.PORT) || PORT);
