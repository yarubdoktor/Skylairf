/* غرفة ماتش واحدة (صرف: بلا ws ولا مؤقتات حقيقية).
   المدخلات: {code, send(id,msg), now(), setTimer(fn,ms), clearTimer(h)}.
   تطبّق D3/D7/D11 بـ shared/match_rules.js. السيرفر يملك الغرف والفرق والجاهزية والمضيف وحالة الغرفة؛
   حركة الطائرة بيد صاحبها فيُمرَّر st كما هو (D3). الضرر/القتل (MP2) والنهاية (MP3) بالبنود اللاحقة. */
import {MAX_PLAYERS, TIME_LIMIT_S, SCORE_LIMIT} from '../shared/match_rules.js';
import {balancedJoin, canSwitch, canStart, spawnFor} from '../shared/match_rules.js';
import {ERR} from '../shared/protocol.js';

const OK = {ok: true}, fail = code => ({ok: false, code});

export class Room{
  constructor({code, send, now, setTimer, clearTimer}){
    this.code = code; this.io = {send, now, setTimer, clearTimer};
    // id ← {id, name, plane, skin, lvl, team, ready} (ترتيب الإدخال = الأقدم أولاً)
    this.players = new Map();
    this.hostId = null; this.state = 'lobby'; this.map = 'island';
  }
  get size(){ return this.players.size; }
  counts(){ const c = [0, 0]; for(const p of this.players.values()) c[p.team]++; return c; }
  /* رسالة room موجّهة لكل لاعب (you = معرّفه) */
  roomMsg(you){
    return {t: 'room', code: this.code, state: this.state, map: this.map, host: this.hostId, you,
      players: [...this.players.values()].map(p => ({id: p.id, name: p.name, plane: p.plane, skin: p.skin,
        team: p.team, ready: p.ready, lvl: p.lvl}))};
  }
  broadcastRoom(){ for(const id of this.players.keys()) this.io.send(id, this.roomMsg(id)); }
  others(id, msg){ for(const o of this.players.keys()) if(o !== id) this.io.send(o, msg); }

  join(id, p){
    if(this.players.has(id)) return fail(ERR.bad_state);
    if(this.state !== 'lobby') return fail(ERR.started);
    if(this.players.size >= MAX_PLAYERS) return fail(ERR.full);
    this.players.set(id, {id, name: p.name, plane: p.plane, skin: p.skin, lvl: p.lvl,
      team: balancedJoin(this.counts()), ready: false});
    if(this.hostId === null) this.hostId = id;
    this.broadcastRoom(); return OK;
  }
  /* يعيد {ok, empty}: empty = الغرفة فرغت (يحذفها السجل) */
  leave(id){
    if(!this.players.delete(id)) return {ok: false, empty: this.players.size === 0};
    if(this.hostId === id) this.hostId = this.players.size ? this.players.keys().next().value : null;   // الأقدم
    if(this.state === 'play') this.others(id, {t: 'left', id});
    this.broadcastRoom(); return {ok: true, empty: this.players.size === 0};
  }
  pick(id, p){
    const me = this.players.get(id); if(!me) return fail(ERR.bad_state);
    if(this.state !== 'lobby') return fail(ERR.bad_state);
    me.plane = p.plane; me.skin = p.skin; this.broadcastRoom(); return OK;
  }
  team(id, team){
    const me = this.players.get(id); if(!me) return fail(ERR.bad_state);
    if(this.state !== 'lobby') return fail(ERR.bad_state);
    if(me.team === team) return OK;
    if(!canSwitch(this.counts(), me.team, team)) return fail(ERR.unbalanced);
    me.team = team; this.broadcastRoom(); return OK;
  }
  ready(id, on){
    const me = this.players.get(id); if(!me) return fail(ERR.bad_state);
    if(this.state !== 'lobby') return fail(ERR.bad_state);
    me.ready = !!on; this.broadcastRoom(); return OK;
  }
  /* المضيف فقط وبشروط canStart. مواضع الظهور: بالترتيب داخل كل فريق (D9/D10: x,z,yaw فقط) */
  start(id){
    if(id !== this.hostId) return fail(ERR.not_host);
    if(this.state !== 'lobby') return fail(ERR.bad_state);
    const list = [...this.players.values()];
    if(!canStart(list, this.hostId).ok) return fail(ERR.cannot_start);
    this.state = 'play';
    const n = [0, 0], spawns = {};
    for(const p of list) spawns[p.id] = spawnFor(this.map, p.team, n[p.team]++);
    this.broadcastRoom();
    for(const pid of this.players.keys()){
      this.io.send(pid, {t: 'start', map: this.map, dur: TIME_LIMIT_S, scoreLimit: SCORE_LIMIT, spawns});
    }
    return OK;
  }
  /* st و fire و flr: تمرير للآخرين فقط وبحالة play */
  onState(id, m){
    if(this.state !== 'play' || !this.players.has(id)) return fail(ERR.bad_state);
    this.others(id, {...m, id}); return OK;
  }
  onFire(id, m){
    if(this.state !== 'play' || !this.players.has(id)) return fail(ERR.bad_state);
    this.others(id, {...m, id}); return OK;
  }
  onFlare(id, m){
    if(this.state !== 'play' || !this.players.has(id)) return fail(ERR.bad_state);
    this.others(id, {...m, id}); return OK;
  }
  /* MP1: لا شيء بعد (طابور إعادة الظهور بـ MP2 وساعة الماتش/النهاية بـ MP3) */
  tick(nowMs){ this.lastTick = nowMs; }
}
