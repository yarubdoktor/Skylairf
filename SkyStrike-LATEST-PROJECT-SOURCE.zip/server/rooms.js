/* سجل الغرف + توجيه رسائل العميل المصدَّقة (shared/protocol.js › validate) إلى الغرفة المناسبة.
   صرف: بلا ws. المدخلات io = {send(id,msg), now(), setTimer, clearTimer}. */
import {CODE_CHARS, PROTOCOL_VERSION, ERR} from '../shared/protocol.js';
import {MAX_PLAYERS} from '../shared/match_rules.js';
import {Room} from './room.js';

export function createRooms(io, rnd = Math.random){
  const byCode = new Map(), byConn = new Map();            // الكود ← غرفة · معرّف الاتصال ← غرفة
  const fromIndex = n => {
    let c = ''; for(let i = 0; i < 4; i++){ c = CODE_CHARS[n % 32] + c; n = Math.floor(n / 32); }
    return c;
  };
  const newCode = () => {
    for(let i = 0; i < 50; i++){                            // عشوائي أولاً، ثم مسح تسلسلي (لا حلقة لا نهائية)
      let c = ''; for(let k = 0; k < 4; k++) c += CODE_CHARS[Math.floor(rnd() * CODE_CHARS.length)];
      if(!byCode.has(c)) return c;
    }
    for(let n = 0; n < 32 ** 4; n++){ const c = fromIndex(n); if(!byCode.has(c)) return c; }
    return null;
  };
  const err = (id, code) => io.send(id, {t: 'err', code});
  const make = () => {
    const code = newCode(); if(!code) return null;
    const r = new Room({code, ...io}); byCode.set(code, r); return r;
  };
  const attach = (id, room, p) => {
    const r = room.join(id, p);
    if(!r.ok){ if(room.size === 0) byCode.delete(room.code); err(id, r.code); return false; }
    byConn.set(id, room); return true;
  };
  const api = {
    find: code => byCode.get(code) || null,
    roomOf: id => byConn.get(id) || null,
    get count(){ return byCode.size; },
    create(id, p){ const r = make(); return r && attach(id, r, p) ? r : null; },
    /* انضمام سريع: أول غرفة lobby فيها مكان، وإلا تُنشأ */
    quick(id, p){
      for(const r of byCode.values()){
        if(r.state === 'lobby' && r.size < MAX_PLAYERS) return attach(id, r, p) ? r : null;
      }
      return api.create(id, p);
    },
    /* مغادرة/انقطاع: يحذف الغرفة الفارغة */
    drop(id){
      const r = byConn.get(id); if(!r) return; byConn.delete(id);
      if(r.leave(id).empty) byCode.delete(r.code);
    },
    tick(nowMs){ for(const r of byCode.values()) r.tick(nowMs); },
    /* msg مُصدَّقة. تعيد {close:true} إن لزم إغلاق الاتصال (إصدار مختلف) */
    handle(id, msg){
      const me = byConn.get(id);
      switch(msg.t){
        case 'create': case 'join':
          if(msg.v !== PROTOCOL_VERSION){ err(id, ERR.version); return {close: true}; }
          if(me){ err(id, ERR.bad_state); break; }
          if(msg.t === 'create') api.create(id, msg);
          else if(msg.code === '') api.quick(id, msg);
          else { const r = api.find(msg.code); if(!r) err(id, ERR.no_room); else attach(id, r, msg); }
          break;
        case 'leave': api.drop(id); break;
        case 'pick': case 'team': case 'ready': case 'start': case 'st': case 'fire': case 'flr': {
          if(!me){ err(id, ERR.bad_state); break; }
          const r = msg.t === 'pick' ? me.pick(id, msg) : msg.t === 'team' ? me.team(id, msg.team)
            : msg.t === 'ready' ? me.ready(id, msg.on) : msg.t === 'start' ? me.start(id)
            : msg.t === 'st' ? me.onState(id, msg) : msg.t === 'fire' ? me.onFire(id, msg) : me.onFlare(id, msg);
          if(!r.ok) err(id, r.code);
          break; }
        default: break;                                      // hit/die (MP2) و chat (MP4ج): لاحقاً
      }
      return {};
    }};
  return api;
}
