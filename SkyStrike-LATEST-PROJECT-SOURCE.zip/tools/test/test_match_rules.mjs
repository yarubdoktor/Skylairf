// اختبار قواعد الماتش (shared/match_rules.js الحقيقي). تشغيل: node tools/test/test_match_rules.mjs
import * as R from '../../shared/match_rules.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if(!c) fail++; };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const teams = {1: 0, 2: 0, 3: 1, 4: 1}, teamOf = id => teams[id];

console.log('ثوابت');
ok(R.MAX_PLAYERS === 8 && R.MIN_TO_START === 2 && R.RESPAWN_S === 5 && R.SCORE_LIMIT === 15, 'D7: 8/2/5/15');
ok(R.TIME_LIMIT_S === 480 && R.ASSIST_WINDOW_S === 8 && R.SEND_HZ === 15 && R.INTERP_DELAY_MS === 120, 'D7: 480/8/15/120');
ok(R.PORT === 2567 && R.MIN_REWARD_S === 60, 'D7: PORT/MIN_REWARD_S');
ok(R.GUN_DMG === 10 && R.MSL_DMG === 83 && R.MSL_AMMO === 7 && eq(R.DMG, {gun: 10, msl: 83}), 'D5: الأضرار والذخيرة');

console.log('teamSide');
ok(R.teamSide(0, 0) === 'ally' && R.teamSide(1, 1) === 'ally', 'نفس الفريق = ally');
ok(R.teamSide(0, 1) === 'enemy' && R.teamSide(1, 0) === 'enemy', 'فريق آخر = enemy');

console.log('balancedJoin / canSwitch');
ok(R.balancedJoin([0, 0]) === 0, '[0,0] ← 0');
ok(R.balancedJoin([1, 0]) === 1, '[1,0] ← 1');
ok(R.balancedJoin([2, 3]) === 0, '[2,3] ← 0');
ok(R.canSwitch([3, 3], 0, 1) === false, '[3,3] من 0 إلى 1 ← false');
ok(R.canSwitch([4, 2], 0, 1) === true, '[4,2] من 0 إلى 1 ← true');

console.log('canStart');
const P = (id, team, ready) => ({id, team, ready});
ok(!R.canStart([P(1, 0, false)], 1).ok && R.canStart([P(1, 0, false)], 1).code === 'cannot_start', 'لاعب واحد ← فشل');
ok(!R.canStart([P(1, 0, false), P(2, 0, true)], 1).ok, 'فريق فارغ ← فشل');
ok(!R.canStart([P(1, 0, false), P(2, 1, false)], 1).ok, 'غير المضيف غير جاهز ← فشل');
ok(R.canStart([P(1, 0, false), P(2, 1, true)], 1).ok, 'المضيف لا يلزمه جاهزية + الآخر جاهز ← نجاح');

console.log('newBoard');
ok(eq(R.newBoard([1, 2]), {p: {1: [0, 0, 0], 2: [0, 0, 0]}, t: [0, 0]}), 'لوحة صفرية');

console.log('resolveDeath');
{ const b = R.newBoard([1, 2, 3, 4]), log = {};
  R.recordHit(log, 3, 1, 100);
  const r = R.resolveDeath(b, log, 3, teamOf, 102);
  ok(r.killer === 1 && eq(r.assists, []), 'مهاجم واحد ← قاتل بلا مساعدين');
  ok(eq(b.p[1], [1, 0, 0]) && eq(b.p[3], [0, 0, 1]) && eq(b.t, [1, 0]), 'k/d ونقطة فريق القاتل');
  ok(log[3] === undefined || log[3].length === 0, 'تفريغ سجل الضحية'); }
{ const b = R.newBoard([1, 2, 3, 4]), log = {};
  R.recordHit(log, 3, 1, 100); R.recordHit(log, 3, 2, 103);
  const r = R.resolveDeath(b, log, 3, teamOf, 104);
  ok(r.killer === 2 && eq(r.assists, [1]), 'مهاجمان: القاتل الأخير والأول مساعد');
  ok(eq(b.p[2], [1, 0, 0]) && eq(b.p[1], [0, 1, 0]), 'k للقاتل و a للمساعد'); }
{ const b = R.newBoard([1, 2, 3, 4]), log = {};
  R.recordHit(log, 3, 1, 100); R.recordHit(log, 3, 2, 109);
  const r = R.resolveDeath(b, log, 3, teamOf, 109.5);
  ok(r.killer === 2 && eq(r.assists, []), 'مهاجم خارج النافذة (9ث) لا يُحتسب'); }
{ const b = R.newBoard([1, 2, 3, 4]), log = {};
  const r = R.resolveDeath(b, log, 3, teamOf, 50);
  ok(r.killer === null && eq(r.assists, []), 'بلا مهاجمين: قاتل null');
  ok(eq(b.t, [0, 0]) && eq(b.p[3], [0, 0, 1]), 'لا نقطة فريق، وd الضحية +1'); }
{ const b = R.newBoard([1, 2, 3, 4]), log = {};
  R.recordHit(log, 3, 1, 100); R.recordHit(log, 3, 2, 101); R.recordHit(log, 3, 1, 102); R.recordHit(log, 3, 2, 103);
  R.recordHit(log, 3, 1, 104);
  const r = R.resolveDeath(b, log, 3, teamOf, 105);
  ok(r.killer === 1 && eq(r.assists, [2]), 'ضربات متكررة من نفس المهاجم تُحتسب مرة');
  ok(b.p[2][1] === 1 && b.p[1][1] === 0, 'المساعدة مرة واحدة فقط'); }

console.log('checkEnd');
ok(R.checkEnd({p: {}, t: [3, 4]}, 100) === null, 'null أثناء اللعب');
ok(eq(R.checkEnd({p: {}, t: [15, 4]}, 100), {win: 0, reason: 'score'}), '15 نقطة للفريق 0');
ok(eq(R.checkEnd({p: {}, t: [4, 15]}, 100), {win: 1, reason: 'score'}), '15 نقطة للفريق 1');
ok(eq(R.checkEnd({p: {}, t: [5, 3]}, 480), {win: 0, reason: 'time'}), 'انتهاء الوقت بفائز');
ok(eq(R.checkEnd({p: {}, t: [4, 4]}, 480), {win: -1, reason: 'time'}), 'انتهاء الوقت بتعادل');

console.log('rewardOf / personalScore');
ok(eq(R.rewardOf(3, 2, true, 300), {c: 20 + 45 + 14 + 40, xp: 30 + 60 + 20 + 50}), 'فوز');
ok(eq(R.rewardOf(3, 2, false, 300), {c: 79, xp: 110}), 'خسارة');
ok(eq(R.rewardOf(9, 9, true, 59), {c: 0, xp: 0}), 'أقل من 60ث ← صفر');
ok(R.personalScore(3, 2) === 400, 'personalScore = k*100 + a*50');

console.log('spawnFor / hpState');
ok(eq(R.spawnFor('island', 0, 0), {x: -2400, z: -450, yaw: -1.5708}), 'spawnFor(island,0,0)');
ok(eq(R.spawnFor('island', 1, 5), R.MP_MAPS.island.spawns[1][1]), 'التفاف الفهرس');
ok(R.MP_MAPS.island.spawns.every(t => t.length === 4 && t.every(s => Math.abs(s.x) <= R.MP_MAPS.island.limit
  && Math.abs(s.z) <= R.MP_MAPS.island.limit)), 'كل المواضع ضمن limit');
ok(R.hpState(0, 100) === 'dead' && R.hpState(-5, 100) === 'dead', 'dead');
ok(R.hpState(29, 100) === 'crit' && R.hpState(30, 100) === 'low', 'crit < 30%');
ok(R.hpState(59, 100) === 'low' && R.hpState(60, 100) === 'ok', 'low < 60%');

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
