// اختبار الغرفة والسجل (server/room.js + server/rooms.js الحقيقيان، بلا ws). تشغيل: node tools/test/test_room.mjs
import {Room} from '../../server/room.js';
import {createRooms} from '../../server/rooms.js';
import {validate} from '../../shared/protocol.js';
import {spawnFor} from '../../shared/match_rules.js';
let fail = 0; const ok = (c, m, x = '') => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c ? '' : ' ' + x)); if(!c) fail++; };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const pl = (n = 'P') => ({name: n, plane: 'mig29', skin: 'gray', lvl: 1});
function mk(){
  const out = []; let now = 0;
  const io = {send: (id, m) => out.push({id, m}), now: () => now, setTimer: () => 0, clearTimer: () => {}};
  return {out, io, last: (id, t) => [...out].reverse().find(o => o.id === id && o.m.t === t), of: (id, t) => out.filter(o => o.id === id && o.m.t === t),
    clear: () => { out.length = 0; }};
}
const room = () => { const h = mk(); return {h, r: new Room({code: 'ABCD', ...h.io})}; };

console.log('انضمام + فرق متوازنة + المضيف');
{ const {h, r} = room();
  ok(r.join(1, pl('A')).ok && r.hostId === 1 && r.players.get(1).team === 0, 'الأول: مضيف وفريق 0');
  ok(r.join(2, pl('B')).ok && r.players.get(2).team === 1, 'الثاني ← فريق 1 (التوازن)');
  ok(r.join(3, pl('C')).ok && r.players.get(3).team === 0 && r.join(4, pl('D')).ok && r.players.get(4).team === 1, 'الثالث 0 والرابع 1');
  ok(!r.join(2, pl('B')).ok && r.join(2, pl('B')).code === 'bad_state', 'انضمام مكرر لنفس الاتصال ← bad_state');
  const m = h.last(3, 'room').m;
  ok(m.t === 'room' && m.code === 'ABCD' && m.state === 'lobby' && m.map === 'island' && m.host === 1 && m.you === 3, 'room: code/state/map/host/you');
  ok(m.players.length === 4 && eq(Object.keys(m.players[0]), ['id', 'name', 'plane', 'skin', 'team', 'ready', 'lvl']), 'room.players بالحقول المحدّدة');
  ok(h.last(1, 'room').m.you === 1, 'كل لاعب يستلم you الخاص به'); }

console.log('الامتلاء (8)');
{ const {r} = room(); for(let i = 1; i <= 8; i++) r.join(i, pl());
  const x = r.join(9, pl()); ok(!x.ok && x.code === 'full' && r.size === 8, 'التاسع ← full'); }

console.log('pick / team / ready');
{ const {h, r} = room(); r.join(1, pl()); r.join(2, pl()); h.clear();
  ok(r.pick(2, {plane: 'su57', skin: 'gold'}).ok && r.players.get(2).plane === 'su57' && h.of(1, 'room').length === 1, 'pick يغيّر ويبثّ room');
  ok(!r.team(2, 0).ok && r.team(2, 0).code === 'unbalanced', 'team: 1←0 يكسر التوازن ← unbalanced');
  r.join(3, pl()); r.join(4, pl()); r.join(5, pl()); r.join(6, pl());        // الفرق: 0:{1,3,5} 1:{2,4,6}
  ok(r.team(3, 0).ok, 'team لنفس الفريق ← ok بلا تغيير');
  ok(!r.team(1, 1).ok, '3|3 ← نقل واحد يعطي 2|4 ← unbalanced');
  ok(r.ready(2, true).ok && r.players.get(2).ready === true && r.ready(2, false).ok && r.players.get(2).ready === false, 'ready تبديل');
  ok(r.pick(99, {plane: 'mig29', skin: 'gray'}).code === 'bad_state', 'لاعب غير موجود ← bad_state'); }

console.log('البدء: المضيف + canStart + مواضع الظهور');
{ const {h, r} = room(); r.join(1, pl('A')); 
  ok(r.start(1).code === 'cannot_start', 'لاعب واحد ← cannot_start');
  r.join(2, pl('B'));
  ok(r.start(2).code === 'not_host', 'غير المضيف ← not_host');
  ok(r.start(1).code === 'cannot_start', 'الآخر غير جاهز ← cannot_start');
  r.ready(2, true); r.join(3, pl('C')); r.ready(3, true); h.clear();
  const s = r.start(1);
  ok(s.ok && r.state === 'play', 'بدء ناجح ← state=play');
  const st = h.last(2, 'start').m;
  ok(st.map === 'island' && st.dur === 480 && st.scoreLimit === 15, 'start: map/dur/scoreLimit');
  ok(eq(st.spawns[1], spawnFor('island', 0, 0)) && eq(st.spawns[3], spawnFor('island', 0, 1)) && eq(st.spawns[2], spawnFor('island', 1, 0)), 'المواضع بالترتيب داخل كل فريم/فريق');
  ok(h.of(1, 'start').length === 1 && h.of(2, 'start').length === 1 && h.of(3, 'start').length === 1, 'start لكل اللاعبين');
  ok(h.last(1, 'room').m.state === 'play', 'room بحالة play يُبثّ قبل start');
  ok(r.start(1).code === 'bad_state', 'بدء ثانٍ ← bad_state'); }

console.log('انضمام/تعديل أثناء اللعب');
{ const {r} = room(); r.join(1, pl()); r.join(2, pl()); r.ready(2, true); r.start(1);
  ok(r.join(3, pl()).code === 'started', 'انضمام أثناء play ← started');
  ok(r.pick(1, {plane: 'su57', skin: 'gray'}).code === 'bad_state' && r.team(1, 1).code === 'bad_state' && r.ready(1, true).code === 'bad_state', 'pick/team/ready أثناء play ← bad_state'); }

console.log('تمرير st / fire / flr للآخرين فقط');
{ const {h, r} = room(); r.join(1, pl()); r.join(2, pl()); r.join(3, pl());
  ok(r.onState(1, {t: 'st', x: 1}).code === 'bad_state', 'st بحالة lobby ← bad_state');
  r.ready(2, true); r.ready(3, true); r.start(1); h.clear();
  const msg = {t: 'st', x: 5, y: 6, z: 7, yw: 0, pt: 0, rl: 0, sp: 150, hp: 95, b: 0, g: 1};
  ok(r.onState(1, msg).ok, 'st بحالة play');
  ok(h.of(1, 'st').length === 0 && h.of(2, 'st').length === 1 && h.of(3, 'st').length === 1, 'لا يعود للمرسل');
  ok(h.last(2, 'st').m.id === 1 && h.last(2, 'st').m.x === 5 && h.last(2, 'st').m.g === 1, 'يحمل id المرسل (لا من الرسالة) وحقوله');
  const forged = {...msg, id: 3}; r.onState(1, forged); ok(h.last(2, 'st').m.id === 1, 'id مزوَّر داخل الرسالة يُستبدل بمعرّف المرسل');
  h.clear(); r.onFire(2, {t: 'fire', k: 'msl', tg: 1, x: 0, y: 0, z: 0, dx: 0, dy: 0, dz: -1});
  ok(h.of(2, 'fire').length === 0 && h.last(1, 'fire').m.id === 2 && h.last(3, 'fire').m.tg === 1, 'fire تمرير بـ id');
  h.clear(); r.onFlare(3, {t: 'flr', x: 1, y: 2, z: 3});
  ok(h.last(1, 'flr').m.id === 3 && h.of(3, 'flr').length === 0, 'flr تمرير بـ id');
  ok(r.onState(99, msg).code === 'bad_state', 'مرسل غير موجود ← bad_state'); }

console.log('المغادرة + انتقال المضيف');
{ const {h, r} = room(); r.join(1, pl('A')); r.join(2, pl('B')); r.join(3, pl('C')); h.clear();
  const l = r.leave(1);
  ok(l.ok && !l.empty && r.hostId === 2, 'غادر المضيف ← المضيف الأقدم (2)');
  ok(h.of(2, 'room').length === 1 && h.last(2, 'room').m.host === 2 && h.of(1, 'room').length === 0, 'room يُبثّ للباقين فقط');
  ok(h.of(2, 'left').length === 0, 'بحالة lobby لا left (room يكفي)');
  r.ready(3, true); r.start(2); h.clear();
  r.leave(3); ok(h.of(2, 'left').length === 1 && h.last(2, 'left').m.id === 3, 'بحالة play ← left{id} للباقين');
  ok(r.leave(2).empty && r.hostId === null, 'آخر لاعب ← empty'); ok(!r.leave(2).ok, 'مغادرة غير موجود ← ok:false'); }

console.log('السجل: إنشاء وانضمام وسريع');
{ const h = mk(); const reg = createRooms(h.io, (() => { let i = 0; return () => ((i++ * 7919) % 1000) / 1000; })());
  const mA = validate({t: 'create', v: 1, name: 'A', plane: 'mig29', skin: 'gray', lvl: 1}).msg;
  reg.handle(1, mA); const ra = reg.roomOf(1);
  ok(ra && /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{4}$/.test(ra.code) && h.last(1, 'room').m.code === ra.code, 'create ← غرفة بكود صحيح + room للمنشئ');
  reg.handle(2, validate({t: 'join', v: 1, code: ra.code.toLowerCase(), name: 'B', plane: 'su57', skin: 'gray', lvl: 3}).msg);
  ok(reg.roomOf(2) === ra && ra.size === 2 && ra.players.get(2).team === 1, 'join بالكود ← الفريق 1');
  h.clear(); reg.handle(3, validate({t: 'join', v: 1, code: 'ZZZZ', name: 'C', plane: 'mig29', skin: 'gray', lvl: 1}).msg);
  ok(h.last(3, 'err').m.code === 'no_room' && reg.roomOf(3) === null, 'كود مجهول ← err no_room');
  reg.handle(4, validate({t: 'join', v: 1, code: '', name: 'D', plane: 'mig29', skin: 'gray', lvl: 1}).msg);
  ok(reg.roomOf(4) === ra && ra.size === 3, 'انضمام سريع ← أول غرفة lobby فيها مكان');
  h.clear(); reg.handle(1, mA); ok(h.last(1, 'err').m.code === 'bad_state', 'create وأنت بغرفة ← bad_state');
  h.clear(); const r2 = reg.handle(5, {t: 'create', v: 2, name: 'E', plane: 'mig29', skin: 'gray', lvl: 1});
  ok(h.last(5, 'err').m.code === 'version' && r2.close === true && reg.roomOf(5) === null, 'إصدار مختلف ← err version + close');
  ra.ready(2, true); ra.ready(4, true); reg.handle(1, {t: 'start'});
  ok(ra.state === 'play', 'start عبر السجل');
  h.clear(); reg.handle(6, validate({t: 'join', v: 1, code: ra.code, name: 'F', plane: 'mig29', skin: 'gray', lvl: 1}).msg);
  ok(h.last(6, 'err').m.code === 'started', 'انضمام برمز غرفة بدأت ← started');
  reg.handle(7, validate({t: 'join', v: 1, code: '', name: 'G', plane: 'mig29', skin: 'gray', lvl: 1}).msg);
  ok(reg.roomOf(7) && reg.roomOf(7) !== ra && reg.count === 2, 'السريع لا يدخل غرفة play ← تُنشأ غرفة جديدة');
  h.clear(); reg.handle(8, {t: 'pick', plane: 'su57', skin: 'gray'}); ok(h.last(8, 'err').m.code === 'bad_state', 'رسالة غرفة بلا انضمام ← bad_state');
  reg.handle(9, {t: 'hit', by: 1, k: 'gun'}); reg.handle(9, {t: 'chat', k: 1}); ok(true, 'hit/chat (لاحقاً) تُتجاهل بلا خطأ'); }

console.log('السجل: حذف الغرفة الفارغة والانقطاع');
{ const h = mk(), reg = createRooms(h.io);
  reg.handle(1, {t: 'create', v: 1, name: 'A', plane: 'mig29', skin: 'gray', lvl: 1}); const code = reg.roomOf(1).code;
  reg.handle(2, {t: 'join', v: 1, code, name: 'B', plane: 'mig29', skin: 'gray', lvl: 1});
  reg.drop(1); ok(reg.find(code) && reg.find(code).hostId === 2 && reg.roomOf(1) === null, 'انقطاع المضيف ← الغرفة تبقى والمضيف 2');
  reg.handle(2, {t: 'leave'}); ok(reg.find(code) === null && reg.count === 0, 'آخر مغادر ← حذف الغرفة');
  reg.drop(55); ok(true, 'drop لاتصال بلا غرفة لا يرمي');
  const rr = createRooms(h.io, () => 0); rr.handle(1, {t: 'create', v: 1, name: 'A', plane: 'mig29', skin: 'gray', lvl: 1});
  rr.handle(2, {t: 'create', v: 1, name: 'B', plane: 'mig29', skin: 'gray', lvl: 1}); ok(rr.roomOf(1).code !== rr.roomOf(2).code, 'الكود لا يتكرر حتى مع rnd ثابت'); }

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
