// خطّافات اختبار ملفات src/match/*: تحوّل استيراداتها (three/core/state/data/jets/ui…) لنسخ وهمية، وتبقي combat.js الحقيقي.
// ما عدا ذلك يفوَّض لـ hooks.mjs (مسار combat.js/ai.js الحالي).
import {resolve as base} from './hooks.mjs';
const STUBM = new URL('./stubs_match.mjs', import.meta.url).href;
const MATCH_SPECS = new Set(['../data.js', '../jets.js', '../core.js', '../state.js', '../ui.js', '../player.js', '../i18n.js', '../input.js']);
export async function resolve(spec, ctx, next){
  const p = ctx.parentURL || '';
  if(/\/src\/match\//.test(p) && MATCH_SPECS.has(spec)) return {url: STUBM, shortCircuit: true};
  return base(spec, ctx, next);
}
