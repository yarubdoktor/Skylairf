// اختبار بروتوكول الماتش (shared/protocol.js الحقيقي). تشغيل: node tools/test/test_protocol.mjs
import * as P from '../../shared/protocol.js';
let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if(!c) fail++; };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const good = {t: 'create', v: 1, name: 'Ali', plane: 'mig29', skin: 'gray', lvl: 5};
const st = {t: 'st', x: 1.5, y: 300, z: -20, yw: 1.2, pt: 0, rl: .3, sp: 150, hp: 95, b: 0, g: 1};

console.log('ثوابت');
ok(P.PROTOCOL_VERSION === 1 && P.MAX_BYTES === 2048, 'PROTOCOL_VERSION=1 والحد 2048');
ok(P.T.create === 'create' && P.T.st === 'st' && P.T.respawn === 'respawn' && Object.isFrozen(P.T), 'T مجمّد ومفتاحه = قيمته');
ok(eq(Object.keys(P.ERR), ['bad_msg', 'version', 'no_room', 'full', 'started', 'not_host', 'cannot_start', 'bad_state', 'unbalanced']), 'ERR: تسعة رموز بالترتيب');

console.log('validate: الأساسيات');
ok(!P.validate(null).ok && !P.validate('x').ok && !P.validate([]).ok && !P.validate({}).ok, 'null/نص/مصفوفة/بلا t ← رفض');
ok(P.validate({t: 'bogus'}).code === 'bad_msg', 'نوع مجهول ← bad_msg');
ok(!P.validate({t: 'toString'}).ok && !P.validate({t: 'constructor'}).ok, 'أسماء من Object.prototype ← رفض');
ok(P.validate(good).ok && P.validate(good).msg.name === 'Ali', 'create صحيحة');
{ const r = P.validate({...good, extra: 1, hack: {a: 1}}); ok(r.ok && !('extra' in r.msg) && !('hack' in r.msg), 'الحقول الزائدة تُسقط'); }

console.log('validate: الاسم والطائرة والسكن والمستوى');
ok(P.validate({...good, name: 'A'.repeat(40)}).msg.name.length === 16, 'الاسم يُقصّ إلى 16');
ok(P.validate({...good, name: 'A\u0000B\u0007C\n'}).msg.name === 'ABC', 'محارف التحكم تُزال');
ok(Array.from(P.validate({...good, name: '😀'.repeat(20)}).msg.name).length === 16, 'القص بالنقاط الرمزية (لا ينقطع رمز مزدوج)');
ok(!P.validate({...good, name: '   '}).ok && !P.validate({...good, name: 5}).ok, 'اسم فارغ/غير نصي ← رفض');
ok(!P.validate({...good, plane: 'f35'}).ok && P.validate({...good, plane: 'su57'}).ok, 'الطائرة mig29/su57 فقط');
ok(!P.validate({...good, skin: 'Gold'}).ok && !P.validate({...good, skin: 'a'.repeat(13)}).ok && !P.validate({...good, skin: ''}).ok, 'السكن ^[a-z0-9_]{1,12}$');
ok(P.validate({...good, skin: 'a_1'}).ok, 'سكن صحيح');
ok(!P.validate({...good, lvl: 0}).ok && !P.validate({...good, lvl: 100}).ok && !P.validate({...good, lvl: 2.5}).ok && P.validate({...good, lvl: 99}).ok, 'lvl عدد صحيح 1..99');
ok(!P.validate({...good, v: '1'}).ok && P.validate({...good, v: 7}).ok, 'v عدد صحيح (عدم المطابقة يعالجها السيرفر بـ err version)');

console.log('validate: join');
const j = {t: 'join', v: 1, code: 'abcd', name: 'B', plane: 'mig29', skin: 'gray', lvl: 1};
ok(P.validate(j).msg.code === 'ABCD', 'الكود يُحوَّل لحروف كبيرة');
ok(P.validate({...j, code: ''}).ok, 'code فارغ = انضمام سريع');
ok(!P.validate({...j, code: 'ABC'}).ok && !P.validate({...j, code: 'ABCDE'}).ok && !P.validate({...j, code: 'AB0D'}).ok && !P.validate({...j, code: 'ABI1'}).ok, 'كود بطول/محارف غير مسموحة ← رفض');
ok(!P.validate({...j, code: 5}).ok, 'code غير نصي ← رفض');

console.log('validate: بقية الأنواع');
ok(P.validate({t: 'pick', plane: 'su57', skin: 'gold'}).ok && !P.validate({t: 'pick', plane: 'su57'}).ok, 'pick');
ok(P.validate({t: 'team', team: 1}).ok && !P.validate({t: 'team', team: 2}).ok && !P.validate({t: 'team', team: '1'}).ok, 'team 0/1');
ok(P.validate({t: 'ready', on: true}).ok && !P.validate({t: 'ready', on: 1}).ok, 'ready bool');
ok(P.validate({t: 'start'}).ok && P.validate({t: 'leave'}).ok && P.validate({t: 'die'}).ok, 'start/leave/die بلا حقول');
ok(P.validate(st).ok && eq(P.validate(st).msg, st), 'st صحيحة');
ok(!P.validate({...st, x: NaN}).ok && !P.validate({...st, x: Infinity}).ok && !P.validate({...st, x: 1e9}).ok, 'st: NaN/Infinity/خارج المدى ← رفض');
ok(!P.validate({...st, hp: 1.5}).ok && !P.validate({...st, hp: -1}).ok && !P.validate({...st, b: 2}).ok && !P.validate({...st, g: true}).ok, 'st: hp صحيح ≥0 وb/g بـ 0/1');
{ const {x, ...rest} = st; ok(!P.validate(rest).ok, 'st ناقصة حقلاً ← رفض'); }
const fire = {t: 'fire', k: 'msl', tg: 2, x: 1, y: 2, z: 3, dx: 0, dy: 0, dz: -1};
ok(P.validate(fire).ok && !P.validate({...fire, k: 'gun'}).ok && !P.validate({...fire, tg: undefined}).ok && !P.validate({...fire, dx: 3}).ok, 'fire: tg إلزامي وk=msl');
ok(P.validate({t: 'flr', x: 1, y: 2, z: 3}).ok && !P.validate({t: 'flr', x: 1, y: 2}).ok, 'flr');
ok(P.validate({t: 'hit', by: 2, k: 'gun'}).ok && P.validate({t: 'hit', by: 2, k: 'msl'}).ok && !P.validate({t: 'hit', by: 2, k: 'bomb'}).ok, 'hit gun/msl');
ok(P.validate({t: 'chat', k: 0}).ok && P.validate({t: 'chat', k: 5}).ok && !P.validate({t: 'chat', k: 6}).ok && !P.validate({t: 'chat', k: -1}).ok, 'chat 0..5');
ok(!P.validate({t: 'room'}).ok && !P.validate({t: 'err', code: 'x'}).ok, 'أنواع السيرفر ← العميل لا تُقبل من العميل');

console.log('encode / decode');
ok(P.decode(P.encode(st)).ok && eq(P.decode(P.encode(st)).msg, st), 'ذهاب وإياب');
ok(!P.decode('{bad').ok && P.decode('{bad').code === 'bad_msg', 'JSON تالف ← bad_msg');
ok(!P.decode('[1,2]').ok && !P.decode('"x"').ok && !P.decode('null').ok && !P.decode('{"a":1}').ok && !P.decode(5).ok, 'ليس كائناً بحقل t ← رفض');
ok(P.decode(JSON.stringify({t: 'x', p: 'a'.repeat(2000)})).ok, 'ضمن 2048 بايت ← قبول');
ok(!P.decode(JSON.stringify({t: 'x', p: 'a'.repeat(2048)})).ok, 'أكبر من 2048 بايت ← رفض');
ok(!P.decode(JSON.stringify({t: 'x', p: 'ع'.repeat(1030)})).ok, 'الحد بالبايت لا بالحروف (العربية بايتان)');

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
