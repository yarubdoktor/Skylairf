// اختبار لقطات الحالة (src/net/snapshot.js الحقيقي). تشغيل: node tools/test/test_snapshot.mjs
import {packState, createBuffer, pushSnap, sampleBuffer} from '../../src/net/snapshot.js';
let fail = 0; const ok = (c, m, x = '') => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c ? '' : ' ' + x)); if(!c) fail++; };
const near = (a, b, e = 1e-6) => Math.abs(a - b) < e;
const S = (x, extra = {}) => ({x, y: 100, z: 0, yw: 0, pt: 0, rl: 0, sp: 150, hp: 90, b: 0, g: 0, ...extra});
const D = 120;

console.log('packState');
{ const p = packState({x: 1.2345, y: 299.96, z: -0.04, yw: 1.23456, pt: -0.0004, rl: 3.14159, sp: 149.96, hp: 94.6, b: true, g: 0});
  ok(p.x === 1.2 && p.y === 300 && p.z + 0 === 0, 'x,y,z بمنزلة عشرية واحدة', JSON.stringify(p));
  ok(p.yw === 1.235 && p.pt + 0 === 0, 'yw,pt بثلاث منازل');
  ok(p.rl === 3.142 && p.sp === 150 && p.hp === 95, 'rl بثلاث، sp بمنزلة، hp صحيح');
  ok(p.b === 1 && p.g === 0, 'b/g بـ 0/1');
  ok(packState({x: 0, y: 0, z: 0, yw: 0, pt: 0, rl: 0, sp: 0, hp: -3, b: 0, g: 0}).hp === 0, 'hp لا يقل عن 0'); }

console.log('لا لقطات / لقطة واحدة');
{ const b = createBuffer(); ok(sampleBuffer(b, 1000, D) === null, 'مخزن فارغ ← null');
  pushSnap(b, S(10), 1000); const s = sampleBuffer(b, 5000, D); ok(s && s.x === 10, 'لقطة واحدة ← ثابتة'); }

console.log('الاستيفاء بين لقطتين (تأخير 120ms)');
{ const b = createBuffer(); pushSnap(b, S(0), 1000); pushSnap(b, S(100), 1100); pushSnap(b, S(200), 1200);
  let s = sampleBuffer(b, 1170, D); ok(near(s.x, 50), 'عند now=1170 ← الهدف 1050 ← x=50', s.x);
  s = sampleBuffer(b, 1250, D); ok(near(s.x, 130), 'عند now=1250 ← الهدف 1130 ← x=130', s.x);
  s = sampleBuffer(b, 1100, D); ok(s.x === 0, 'الهدف قبل أول لقطة ← أول لقطة'); }

console.log('الزاوية بأقصر قوس');
{ const b = createBuffer(); pushSnap(b, S(0, {yw: 3.0}), 1000); pushSnap(b, S(0, {yw: -3.0}), 1100);
  const s = sampleBuffer(b, 1170, D);                                              // الفرق الأقصر 0.283 عبر π (وليس 6.0 عبر 0)
  ok(near(Math.abs(s.yw), Math.PI, 1e-3), 'من 3.0 إلى -3.0 ← المنتصف عند π', s.yw);
  const b2 = createBuffer(); pushSnap(b2, S(0, {rl: -.5}), 1000); pushSnap(b2, S(0, {rl: .5}), 1100);
  ok(near(sampleBuffer(b2, 1170, D).rl, 0), 'قوس قصير عادي ← المنتصف'); }

console.log('الاستقراء عند التأخّر: أقصاه 250ms ثم تثبيت');
{ const b = createBuffer(); pushSnap(b, S(0), 1000); pushSnap(b, S(100), 1100);    // 1000م/ث
  let s = sampleBuffer(b, 1100 + D + 100, D); ok(near(s.x, 200), 'تأخّر 100ms ← x=200', s.x);
  s = sampleBuffer(b, 1100 + D + 250, D); ok(near(s.x, 350), 'تأخّر 250ms ← x=350', s.x);
  s = sampleBuffer(b, 1100 + D + 2000, D); ok(near(s.x, 350), 'تأخّر 2000ms ← مثبّت عند 350', s.x);
  ok(s.yw === 0 && s.hp === 90, 'الزوايا والـhp ثابتة عند الاستقراء'); }

console.log('حقول غير مستوفاة + أطوال + ترتيب');
{ const b = createBuffer(); pushSnap(b, S(0, {b: 0, g: 0, hp: 90}), 1000); pushSnap(b, S(100, {b: 1, g: 1, hp: 80}), 1100);
  const s = sampleBuffer(b, 1160, D); ok(s.b === 0 && s.g === 0 && s.hp === 90, 'b/g/hp من اللقطة السابقة (لا استيفاء)'); }
{ const b = createBuffer(); pushSnap(b, S(0), 1000); pushSnap(b, S(10), 1000);        // طابعان متساويان
  const s = sampleBuffer(b, 1500, D); ok(Number.isFinite(s.x), 'طابعان متساويان ← لا NaN', s.x); }
{ const b = createBuffer(); for(let i = 0; i < 500; i++) pushSnap(b, S(i), 1000 + i * 16);
  ok(b.s.length <= 64, 'المخزن محدود الحجم', b.s.length);
  const last = b.s[b.s.length - 1].t, s = sampleBuffer(b, last, D); ok(s && Number.isFinite(s.x), 'العينة بعد الحذف سليمة'); }
{ const b = createBuffer(); pushSnap(b, S(0), 1000); pushSnap(b, S(1), 1100); pushSnap(b, S(2), 5000);
  ok(b.s.length === 2 && b.s[0].t === 1100, 'اللقطات الأقدم من ثانيتين تُحذف (مع إبقاء لقطتين)', JSON.stringify(b.s.map(x => x.t))); }

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
