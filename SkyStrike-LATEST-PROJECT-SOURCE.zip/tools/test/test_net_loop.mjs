// اختبار تكاملي: يشغّل server/index.js (عملية فرعية على منفذ عشوائي) وعميلَين بـ WebSocket المدمج بـ Node 22.
// يتطلب: cd server && npm install (حزمة ws). بدونها ينهي بالرمز 2 ويطبع السبب. تشغيل: npm run test:mp:net
import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {createNetClient} from '../../src/net/client.js';
import {PROTOCOL_VERSION} from '../../shared/protocol.js';

const SERVER = new URL('../../server/', import.meta.url);
if(!existsSync(new URL('node_modules/ws', SERVER))){
  console.log('تخطّي: حزمة ws غير مثبّتة بـ server/ — نفّذ: cd server && npm install'); process.exit(2);
}
let fail = 0; const ok = (c, m, x = '') => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c ? '' : ' ' + x)); if(!c) fail++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const port = 20000 + Math.floor(Math.random() * 20000), url = 'ws://localhost:' + port;
const child = spawn(process.execPath, [new URL('index.js', SERVER).pathname], {env: {...process.env, PORT: String(port)}, stdio: ['ignore', 'pipe', 'inherit']});
await new Promise((res, rej) => { child.stdout.on('data', d => { if(String(d).includes('Sky Strike server')) res(); }); setTimeout(() => rej(new Error('server start timeout')), 8000); });
const done = code => { child.kill(); process.exit(code); };
setTimeout(() => { console.log('  ✗ مهلة الاختبار'); done(1); }, 30000).unref();

/* عميل يسجّل رسائله ويقدر ينتظر نوعاً معيناً */
async function client(){
  const c = createNetClient({url}), log = []; await c.connect(); let closed = false;
  c.on('*', m => log.push(m)); c.on('close', () => { closed = true; });
  const wait = async (t, pred = () => true, ms = 2000) => {
    const t0 = Date.now();
    for(;;){ const m = log.find(x => x.t === t && pred(x) && !x._seen); if(m){ m._seen = true; return m; }
      if(Date.now() - t0 > ms) return null; await sleep(10); }
  };
  return {c, log, wait, get closed(){ return closed; }, count: t => log.filter(m => m.t === t).length};
}
const me = (n, plane = 'mig29') => ({name: n, plane, skin: 'gray', lvl: 1});

console.log('إنشاء + انضمام + جاهزية + بدء');
const A = await client(), B = await client();
A.c.send({t: 'create', v: PROTOCOL_VERSION, ...me('Ali')});
const rA = await A.wait('room');
ok(rA && /^[A-Z2-9]{4}$/.test(rA.code) && rA.state === 'lobby' && rA.host === rA.you && rA.players.length === 1, 'create ← room بكود والمضيف أنا');
B.c.send({t: 'join', v: PROTOCOL_VERSION, code: rA.code, ...me('Bob', 'su57')});
const rB = await B.wait('room', m => m.players.length === 2);
ok(rB && rB.you !== rA.you && rB.players.find(p => p.id === rB.you).team === 1, 'join ← الثاني بالفريق 1');
const rA2 = await A.wait('room', m => m.players.length === 2); ok(!!rA2, 'المضيف يستلم room محدّثاً');
B.c.send({t: 'start'}); ok((await B.wait('err')).code === 'not_host', 'غير المضيف يبدأ ← err not_host');
A.c.send({t: 'start'}); ok((await A.wait('err')).code === 'cannot_start', 'الآخر غير جاهز ← err cannot_start');
B.c.send({t: 'ready', on: true}); await B.wait('room', m => m.players.every(p => p.id === rA.you || p.ready));
A.c.send({t: 'start'});
const sA = await A.wait('start'), sB = await B.wait('start');
ok(sA && sB && sA.map === 'island' && sA.dur === 480 && sA.scoreLimit === 15, 'start لكليهما');
ok(sA.spawns[rA.you] && sA.spawns[rB.you] && sA.spawns[rA.you].x < 0 && sA.spawns[rB.you].x > 0, 'الفريق 0 غرباً والفريق 1 شرقاً');

console.log('تمرير st للآخر فقط');
const pose = {t: 'st', x: 10.5, y: 300, z: -20, yw: 1.2, pt: .1, rl: .2, sp: 150, hp: 95, b: 0, g: 1};
A.c.send(pose); const got = await B.wait('st');
ok(got && got.id === rA.you && got.x === 10.5 && got.g === 1, 'B يستلم st من A بمعرّفه');
await sleep(150); ok(A.count('st') === 0, 'A لا يستلم st الخاص به');

console.log('أخطاء وحدود');
const R = await client(); R.c.send({t: 'start'}); ok((await R.wait('err')).code === 'bad_state', 'رسالة غرفة بلا انضمام ← bad_state');
R.c.send({t: 'nonsense'}); ok((await R.wait('err')).code === 'bad_msg', 'نوع مجهول ← bad_msg');
R.c.send({t: 'join', v: PROTOCOL_VERSION, code: 'ZZZZ', ...me('R')}); ok((await R.wait('err')).code === 'no_room', 'كود مجهول ← no_room');
R.c.send({t: 'join', v: PROTOCOL_VERSION, code: rA.code, ...me('R')}); ok((await R.wait('err')).code === 'started', 'انضمام بعد البدء ← started');
{ const V = await client(); V.c.send({t: 'create', v: 99, ...me('V')});
  ok((await V.wait('err')).code === 'version', 'إصدار مختلف ← err version'); await sleep(200); ok(V.closed, 'ثم يغلق السيرفر الاتصال'); }
{ const raw = new WebSocket(url); await new Promise(r => { raw.onopen = r; }); const got = []; raw.onmessage = e => got.push(JSON.parse(e.data));
  raw.send('{not json'); await sleep(150); ok(got.some(m => m.t === 'err' && m.code === 'bad_msg'), 'JSON تالف ← err bad_msg');
  let closed = false; raw.onclose = () => { closed = true; }; raw.send(JSON.stringify({t: 'st', p: 'a'.repeat(3000)})); await sleep(300);
  ok(closed, 'رسالة > 2048 بايت ← إغلاق الاتصال'); }

console.log('حد st (30/ثانية، الزائد يُسقط بصمت)');
{ const before = B.count('st'); for(let i = 0; i < 100; i++) A.c.send({...pose, x: i}); await sleep(500);
  const n = B.count('st') - before; ok(n >= 25 && n <= 32, 'من 100 رسالة st يمر ≈30', n);
  ok(A.count('err') === 0 || A.log.filter(m => m.t === 'err').length <= 2, 'لا أخطاء للزائد'); }

console.log('مغادرة أحدهما');
B.c.close(); const lf = await A.wait('left'); ok(lf && lf.id === rB.you, 'A يستلم left{id} لما B يغادر');
const rA3 = await A.wait('room', m => m.players.length === 1); ok(!!rA3, 'room محدّث بلاعب واحد');

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت'); done(fail ? 1 : 0);
