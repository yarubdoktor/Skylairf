/* اختبار رتل المهمة 2 (m1) على خريطة front الحقيقية (تضاريس + مباني، بلا three): تعريف m1 الفعلي + vehicleLite الحقيقي
   + محرك الأهداف. يمنع رجوع علوق الرتل ببلدة t_ridge وعدم وصول التوابع. تشغيل: node tools/test/test_convoy.mjs */
import {TERRAINS} from '../../src/theater/terrains.js';
import {mkNoise} from '../../src/noise.js';
import {makeShaper} from '../../src/theater/shape.js';
import {buildLayout} from '../../src/theater/layout.js';
import {MISSIONS} from '../../src/mission/mission_defs.js';
import {vehicleLite} from '../../src/mission/vehicle_ai.js';
import {makeBody} from '../../src/mission/friendly_ai.js';
import {convoySlots, convoyYaw} from '../../src/mission/convoy.js';
import {createRuntime, pushEvent, stepRuntime} from '../../src/mission/mission_runtime.js';
let fail = 0; const ok = (c, m, x = '') => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c ? '' : ' ' + x)); if(!c) fail++; };

const T = TERRAINS.front, S = makeShaper(T, mkNoise(T.seed)), lay = buildLayout(T, S);
const world = {H: S.H, ground: S.H, hasWater: () => true, cfg: {water: {level: 0}, hit: lay.hit}};
const sites = Object.fromEntries(S.pads.map(p => [p.id, {x: p.x, z: p.z}]));
const def = MISSIONS.find(m => m.id === 'm1'), cvd = def.entities.find(e => e.id === 'cv');
const rnd = (a, b) => a + Math.random() * (b - a);
function landPos(cx, cz, rad, tries = 80){            // نفس شروط spawn.js › landPos
  for(let i = 0; i < tries; i++){ const x = cx + rnd(-rad, rad), z = cz + rnd(-rad, rad), h = world.H(x, z);
    if(h < 5 || Math.hypot(world.H(x + 8, z) - h, world.H(x, z + 8) - h) > 5 || world.cfg.hit(x, h + 3, z)) continue;
    return {x, z, h}; } return null; }
const findLand = a => { for(const m of [1, 2, 4, 8]){ const c = landPos(a.x, a.z, a.rad * m, 120); if(c) return c; } return {x: a.x, z: a.z}; };
const anchor = p => p.site ? {x: sites[p.site].x + (p.dx || 0), z: sites[p.site].z + (p.dz || 0), rad: p.r} : {x: p.x, z: p.z, rad: p.r};

console.log('المهمة 2 (m1): الرتل يصل وجهته بلا علوق، ويكتمل هدف الإسناد');
const N = 10; let done = 0, stuck = 0, maxT = 0, minT = 1e9;
for(let n = 0; n < N; n++){
  const rt = createRuntime(def), route = cvd.route.map(p => findLand(anchor(p))), c0 = findLand(anchor(cvd.pos));
  const yaw = convoyYaw(c0, route[0]), slots = convoySlots(c0, route[0], cvd.units.length, cvd.gap), units = []; let prev = null;
  cvd.units.forEach((k, i) => { const sl = slots[i], s = i ? (landPos(sl.x, sl.z, .01, 1) || findLand({x: sl.x, z: sl.z, rad: 25})) : c0;
    const e = {kind: k, spd: cvd.speed, mid: cvd.id + (i + 1), drv: makeBody(s.x, s.z, yaw, route), follow: prev,
      g: {position: {x: s.x, y: 0, z: s.z}, rotation: {set(){}}}}; units.push(e); prev = e; });
  const X = {world, units, V: (x, y, z) => ({x, y, z}), event: id => pushEvent(rt, {type: 'entityArrived', id})};
  let t = 0, finished = false;
  for(; t < 900; t += 1 / 20){ for(const e of units) vehicleLite(e, 1 / 20, X); stepRuntime(rt, 1 / 20, null);
    if(rt.objectives.find(o => o.id === 'o3').status === 'done'){ finished = true; break; } }
  if(finished){ done++; maxT = Math.max(maxT, t); minT = Math.min(minT, t); } if(units.some(u => u.drv.stuck)) stuck++;
}
ok(done === N, 'هدف الإسناد (3 من 4 تصل) يكتمل بكل المحاولات', done + '/' + N);
ok(stuck === 0, 'لا مركبة عالقة بأي محاولة', stuck + ' محاولة');
ok(maxT <= 420, 'الزمن معقول (≤ 7 دقائق، المرجع par=520)', 'max=' + maxT.toFixed(0));
console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت'); process.exit(fail ? 1 : 0);
