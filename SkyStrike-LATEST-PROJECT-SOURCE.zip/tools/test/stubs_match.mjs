// نسخ وهمية لما تستورده ملفات src/match/* (فوق stubs.mjs المشترك مع combat.js: W و P نفس الكائنين).
import {Vec3, V} from './stubs.mjs';
export * from './stubs.mjs';
export const world = {ground: () => 0, cfg: {}, streamed: [], stream(p, force){ world.streamed.push(!!force); }};
export const PLANES = {
  mig29: {speed: 170, turn: 1.35, hp: 95, col: 1, kind: 1, fl: 3, ab: {bm: 1.6, dr: .42, rc: .2, tv: 1, ms: 1}},
  su57: {speed: 178, turn: 1.55, hp: 125, col: 2, kind: 2, fl: 5, ab: {bm: 1.45, dr: .3, rc: .12, tv: 1.3, ms: .85}}};
export const SKINS = {gray: {c: null}, gold: {c: 0xd4af37}};
export const mkJet = () => ({position: new Vec3(), rotation: {order: '', set(){}}, visible: true,
  userData: {fl: [{scale: {x: 1, y: 1, z: 1}}]}});
export const cam = {position: {copy(){}}};
export const cp = V();
export const camCfg = () => [11.5, 3.2];
export const el = {warn: {textContent: '', style: {opacity: 0}}};
export const inp = {fire: false};
