import {register} from 'node:module';
register('./hooks_match.mjs', import.meta.url);
