// اختبار عميل الشبكة (src/net/client.js الحقيقي) بـ WebSocket وهمي. تشغيل: node tools/test/test_net_client.mjs
import {createNetClient} from '../../src/net/client.js';
import {WS_URL} from '../../src/net/config.js';
let fail = 0; const ok = (c, m, x = '') => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c ? '' : ' ' + x)); if(!c) fail++; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

let last = null;
class FakeWS{
  constructor(url){ this.url = url; this.readyState = 0; this.sent = []; last = this; }
  send(s){ this.sent.push(s); }
  close(){ this.readyState = 3; if(this.onclose) this.onclose(); }
  open(){ this.readyState = 1; this.onopen(); }
  recv(s){ this.onmessage({data: s}); }
}

console.log('config');
ok(WS_URL === 'ws://localhost:2567', 'WS_URL الافتراضي ws://localhost:2567 (D1)');

console.log('connect / send / on');
{ const c = createNetClient({url: 'ws://x', WebSocketImpl: FakeWS}), p = c.connect();
  ok(last.url === 'ws://x' && c.send({t: 'leave'}) === false, 'send قبل الفتح ← false');
  last.open(); await p; ok(true, 'connect يُحلّ عند الفتح');
  ok(c.send({t: 'ready', on: true}) === true && last.sent[0] === '{"t":"ready","on":true}', 'send ← JSON');
  const got = [], all = [], cl = []; c.on('room', m => got.push(m)); c.on('*', m => all.push(m)); c.on('close', m => cl.push(m));
  last.recv('{"t":"room","code":"AB"}'); last.recv('{"t":"st","id":2}'); last.recv('{تالف'); last.recv('[1]'); last.recv('{"x":1}');
  ok(got.length === 1 && got[0].code === 'AB' && all.length === 2, 'on(type) و on("*") ويتجاهل التالف');
  last.recv(JSON.stringify({t: 'x', p: 'a'.repeat(3000)})); ok(all.length === 2, 'رسالة > 2048 بايت تُتجاهل');
  last.onmessage({data: new ArrayBuffer(4)}); ok(all.length === 2, 'رسالة ثنائية تُتجاهل');
  c.close(); ok(cl.length === 1, 'on("close") عند الإغلاق'); }

console.log('فشل الاتصال');
{ const c = createNetClient({url: 'ws://x', WebSocketImpl: FakeWS}), p = c.connect(); last.onerror(); 
  let e = null; try{ await p; }catch(x){ e = x; } ok(e !== null, 'خطأ قبل الفتح ← رفض'); }
{ const c = createNetClient({url: 'ws://x', WebSocketImpl: FakeWS}), p = c.connect(); last.close();
  let e = null; try{ await p; }catch(x){ e = x; } ok(e !== null, 'إغلاق قبل الفتح ← رفض'); }
{ class Boom{ constructor(){ throw new Error('boom'); } }
  let e = null; try{ await createNetClient({url: 'x', WebSocketImpl: Boom}).connect(); }catch(x){ e = x; } ok(e && e.message === 'boom', 'استثناء المُنشئ ← رفض'); }
{ const realST = globalThis.setTimeout; let fn = null, ms = 0;
  globalThis.setTimeout = (f, m) => { if(m === 8000){ fn = f; ms = m; return 1; } return realST(f, m); };
  const c = createNetClient({url: 'ws://x', WebSocketImpl: FakeWS}), p = c.connect(); globalThis.setTimeout = realST;
  ok(ms === 8000, 'مهلة الاتصال 8ث'); fn(); let e = null; try{ await p; }catch(x){ e = x; } ok(e && e.message === 'timeout', 'انتهاء المهلة ← رفض'); }

console.log('الإغلاق بعد النجاح لا يرفض الوعد مرة ثانية');
{ const c = createNetClient({url: 'ws://x', WebSocketImpl: FakeWS}), p = c.connect(); last.open(); await p; c.close(); await sleep(5); ok(true, 'بلا استثناء'); }

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
