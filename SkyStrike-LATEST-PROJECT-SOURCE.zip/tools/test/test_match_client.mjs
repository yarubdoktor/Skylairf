/* اختبار عميل الماتش المحلي (MP0) بـ node بنسخ وهمية للمحرك: beginMatch/dummy/session/remote_unit + combat.js الحقيقي + ai.js.
   تشغيل: node --import ./tools/test/register_match.mjs tools/test/test_match_client.mjs
   لا يغني عن التجربة بالمتصفح (الرسم والكاميرا والرادار). */
import * as S from './stubs.mjs';
import * as M from './stubs_match.mjs';
import {RESPAWN_S} from '../../shared/match_rules.js';
const {W, P, V} = S;
const combat = await import('../../src/combat.js');
const ai = await import('../../src/ai.js');
const match = await import('../../src/match/match.js');
const session = await import('../../src/match/session.js');
const ru = await import('../../src/match/remote_unit.js');

let fail = 0; const ok = (c, m, x = '') => { console.log((c ? '  ✓ ' : '  ✗ ') + m + (c ? '' : ' ' + x)); if(!c) fail++; };
const DT = 1 / 60;
const clock = {ms: 0};                                   // ساعة اصطناعية لطوابع الوصول (mp.now)
const run = (sec, f) => { for(let i = 0; i < sec / DT; i++){ clock.ms += DT * 1000; match.matchUpdate(DT); if(f) f(i); } };
function fresh(){
  W.mp = null; W.units.length = 0; W.projs.length = 0; W.flares.length = 0; W.lockE = null; W.candE = null;
  W.G = {dead: false, diff: 1, hit: false, combo: 0, ct: 0, mult: 1, kj: 0, kg: 0, score: 0, coins: 0, xp: 0, t: 0, deadT: 0};
  Object.assign(P, {hp: 95, maxhp: 95, msl: 0, flr: 0, yaw: 0, pitch: 1, roll: 1, speed: 170, cur: 10});
  P.g.position.set(0, 300, 0); P.g.visible = true; M.el.warn.textContent = '';
}
const cfg = {local: true, map: 'island', plane: 'mig29', skin: 'gray', team: 0, id: 1, name: 'Pilot1', spawn: {x: -2400, z: -450, yaw: -1.5708}, now: () => clock.ms};

console.log('1) بدء الماتش المحلي');
fresh(); match.beginMatch(cfg);
const mp = W.mp, dm = W.units[0];
ok(mp && mp.local && mp.id === 1 && mp.team === 0 && mp.limit === 3200 && mp.map === 'island', 'W.mp بالحقول الأساسية');
ok(mp.dur === 480 && mp.scoreLimit === 15 && mp.left === 480 && mp.respawnT === 0, 'dur/scoreLimit/left/respawnT');
ok(JSON.stringify(mp.sb) === JSON.stringify({p: {1: [0, 0, 0], 2: [0, 0, 0]}, t: [0, 0]}), 'لوحة النتائج');
ok(W.units.length === 1 && dm.remote && dm.pid === 2 && dm.kind === 'remote' && dm.air === true, 'الوهمي أُضيف كوحدة بعيدة');
ok(dm.side === 'enemy' && dm.team === 1 && dm.plane === 'su57' && dm.max === 125 && dm.unarmed === true, 'جهة الخصم والطائرة');

console.log('2) حركة الطيار الوهمي (دائرة 900م، 150م/ث)');
let maxErr = 0, minY = 1e9, sp = 0;
run(12, i => { const p = dm.g.position; maxErr = Math.max(maxErr, Math.abs(Math.hypot(p.x, p.z) - 900)); minY = Math.min(minY, p.y);
  if(i > 30) sp = Math.max(sp, dm.vel.length()); });
ok(maxErr < 1, 'نصف القطر 900 ± 1م', maxErr.toFixed(2));
ok(minY >= 300, 'الارتفاع ≥ 300م', minY);
ok(Math.abs(sp - 150) < 15, 'السرعة المقدّرة ≈150م/ث', sp.toFixed(1));
ok(dm.hp === 125 && W.units.includes(dm), 'لا يتضرر ولا يُحذف');

console.log('3) صاروخ الوهمي يضرب اللاعب');
fresh(); match.beginMatch(cfg);
let fired = null; run(8.2, () => { if(!fired && W.projs.length) fired = W.projs[0]; });
ok(fired && fired.mis && fired.pid === 2 && fired.dmg === 83 && fired.side === 'enemy' && fired.owner === 'e', 'fire ← قذيفة صاروخ (pid=2, dmg=83)');
ok(fired && fired.target === P && fired.speed === 480 && fired.turn === 2.8 && fired.life === 6, 'tg=أنا ← target:P');
const hits = []; W.mp.onHit = (pid, k) => hits.push([pid, k]);
let t0 = 0; while(W.projs.length && t0++ < 600){ combat.projectilesUpdate(DT); match.matchUpdate(DT); }
ok(P.hp === 95 - 83, 'الصحة نقصت 83', P.hp);
ok(hits.length === 1 && hits[0][0] === 2 && hits[0][1] === 'msl', 'onHit(2,"msl") استُدعي مرة');

console.log('4) الموت وإعادة الظهور');
fresh(); match.beginMatch(cfg); P.hp = 95; P.msl = 0; P.flr = 0;
combat.die();
ok(W.G.dead === true && W.mp.respawnT === RESPAWN_S, 'die() ← dead + respawnT=5');
run(2, () => {});
ok(W.mp.respawnT > 2.9 && W.mp.respawnT < 3.1 && M.el.warn.textContent === 'mp_respawn', 'العدّاد ينقص ويظهر النص', W.mp.respawnT);
run(3.2, () => {});
ok(W.G.dead === false && W.mp.respawnT === 0, 'عاد حياً بعد 5ث');
ok(P.hp === P.maxhp && P.msl === 7 && P.flr === 3 && P.g.visible === true, 'صحة/صواريخ/مشاعل كاملة');
const pp = P.g.position;
ok(pp.x === -2400 && pp.z === -450 && Math.abs(pp.y - 170) < 1e-9 && P.yaw === -1.5708 && P.pitch === 0 && P.roll === 0, 'موضع الفريق 0 وy=170 (D10)');
ok(M.world.streamed.length >= 1 && M.el.warn.textContent === '', 'world.stream(…,true) والتحذير مُسح');

console.log('5) الوحدة البعيدة: ضرر بصري فقط وتمرير الحلفاء');
fresh(); match.beginMatch(cfg);
const d2 = W.units[0]; d2.g.position.set(0, 300, -100);
const bullet = (z) => combat.shoot({owner: 'p', side: 'player', pos: V(0, 300, z), dir: V(0, 0, -1), speed: 750, dmg: 10});
bullet(0); for(let i = 0; i < 30; i++) combat.projectilesUpdate(DT);
ok(d2.hp === 125 && W.units.includes(d2) && W.projs.length === 0, 'رصاصة اللاعب تصيب الوهمي بلا تغيير hp ولا حذف');
const ally = ru.addRemoteUnit({id: 7, name: 'A', team: 0, plane: 'mig29', skin: 'gray'}, {x: 0, y: 300, z: -400, yw: 0, pt: 0, rl: 0});
d2.g.position.set(500, 300, 0);
ok(ally.side === 'ally', 'نفس الفريق ← ally');
bullet(0); for(let i = 0; i < 70; i++) combat.projectilesUpdate(DT);
ok(ally.hp === 95 && W.projs.length === 1, 'رصاصة اللاعب تمر عبر الحليف (لم تُستهلك ولم تضرّه)');
ru.removeRemoteUnit(7); ok(!W.units.includes(ally), 'removeRemoteUnit');

console.log('6) ai.js يتخطى الوحدات البعيدة');
fresh(); match.beginMatch(cfg);
const r = W.units[0]; r.vel.set(1, 2, 3); r.lp = undefined; r.hp = 10;
ai.enemiesUpdate(DT);
ok(r.vel.x === 1 && r.vel.y === 2 && r.vel.z === 3 && r.lp === undefined, 'ai لم يعدّل vel/lp');

console.log('7) respawn لطيار آخر + نهاية الماتش');
fresh(); match.beginMatch(cfg);
ru.removeRemoteUnit(2); ok(W.units.length === 0, 'حذف الوحدة (kill لاحقاً)');
session.handleServerMsg({t: 'respawn', id: 2, x: 2400, z: 150, yaw: 1.5708});
ok(W.units.length === 1 && W.units[0].pid === 2 && W.units[0].g.position.x === 2400, 'respawn لآخر ← إعادة إضافة الوحدة');
session.handleServerMsg({t: 'bogus'}); session.handleServerMsg(null); ok(true, 'رسالة مجهولة/فارغة تُتجاهل');
let shown = null; match.endMatch(true, {show: s => shown = s});
ok(W.mp === null && shown === 'lobby', 'endMatch ← W.mp=null والعودة للوبي');
match.matchUpdate(DT); ok(true, 'matchUpdate بلا ماتش لا يفعل شيئاً');

console.log('8) ماتش أونلاين (MP1): مواضع الظهور والجهات ولقطاتي st');
{ fresh(); const sent = [];
  const players = [{id: 1, name: 'Me', team: 0, plane: 'mig29', skin: 'gray'}, {id: 5, name: 'Foe', team: 1, plane: 'su57', skin: 'gray'},
    {id: 6, name: 'Pal', team: 0, plane: 'mig29', skin: 'gray'}];
  const spawns = {1: {x: -2400, z: -450, yaw: -1.5708}, 5: {x: 2400, z: -450, yaw: 1.5708}, 6: {x: -2400, z: -150, yaw: -1.5708}};
  match.beginMatch({local: false, map: 'island', plane: 'mig29', skin: 'gray', team: 0, id: 1, name: 'Me', spawn: spawns[1], spawns,
    players, dur: 480, scoreLimit: 15, now: () => clock.ms, transport: {send: m => sent.push(m)}});
  const mp = W.mp, foe = ru.remoteOf(5), pal = ru.remoteOf(6);
  ok(!mp.local && W.units.length === 2 && !ru.remoteOf(1), 'وحدات بعيدة للآخرين فقط (لا لي)');
  ok(foe.side === 'enemy' && pal.side === 'ally' && foe.plane === 'su57' && foe.team === 1, 'جهة الطيار البعيد نسبةً لفريقي (D4)');
  ok(foe.g.position.x === 2400 && foe.g.position.z === -450 && foe.g.position.y === 170 && pal.g.position.x === -2400, 'مواضع الظهور من spawns وy بمعادلة D10');
  ok(Object.keys(mp.players).length === 3 && mp.players[5].name === 'Foe' && eq0(Object.keys(mp.sb.p)), 'W.mp.players ولوحة النتائج لكل اللاعبين');
  function eq0(k){ return JSON.stringify(k) === JSON.stringify(['1', '5', '6']); }

  P.g.position.set(100.26, 400.04, -50); Object.assign(P, {yaw: 1.2345, pitch: .1, roll: -.2, cur: 150.04, hp: 95, bk: 0});
  M.inp.fire = false; mp.sendT = 0; run(2, null);
  const sts = sent.filter(m => m.t === 'st');
  ok(sts.length >= 29 && sts.length <= 31, 'st بمعدل 15Hz (≈30 خلال ثانيتين)', sts.length);
  ok(JSON.stringify(sts[0]) === JSON.stringify({t: 'st', x: 100.3, y: 400, z: -50, yw: 1.235, pt: .1, rl: -.2, sp: 150, hp: 95, b: 0, g: 0}), 'حقول st بالتقريب المحدّد', JSON.stringify(sts[0]));
  P.bk = .8; M.inp.fire = true; sent.length = 0; run(.2, null);
  ok(sent.length && sent[sent.length - 1].b === 1 && sent[sent.length - 1].g === 1, 'b من P.bk (>0.3) وg من inp.fire');
  P.bk = 0; M.inp.fire = false;
  W.G.dead = true; sent.length = 0; run(1, null); ok(sent.length === 0, 'لا st وأنا ميت');
  W.G.dead = false; mp.respawnT = 3; run(1, null); ok(sent.length === 0, 'لا st أثناء انتظار الإعادة'); mp.respawnT = 0;

  console.log('   استقبال st: المخزن + الاستيفاء بتأخير 120ms');
  const t0 = clock.ms;
  for(let i = 0; i <= 10; i++){ clock.ms = t0 + i * 66; session.handleServerMsg({t: 'st', id: 5, x: 1000 + i * 10, y: 300, z: 0, yw: 0, pt: 0, rl: 0, sp: 150, hp: 120, b: 1, g: 0}); }
  const posAt = tt => { clock.ms = tt; match.matchUpdate(DT); return foe.g.position.x; };
  const xa = posAt(t0 + 330);                                // الهدف = t0+210 ← بين اللقطة 3 (198) و4 (264)
  ok(xa > 1030 && xa < 1040, 'العرض متأخر 120ms ومستوفى بين لقطتين', xa);
  const xb = posAt(t0 + 340); ok(xb > xa, 'يتقدّم بسلاسة بين الإطارات', xa + ' → ' + xb);
  ok(foe.hp === 120 && foe.bkT === 1, 'hp من st فوراً وb يضبط لهب المحرك');
  ok(W.mp.players[5].name === 'Foe' && foe.vel.x > 0, 'السرعة المقدّرة موجبة (لمؤشر التصويب)');
  clock.ms = t0 + 5000; match.matchUpdate(DT); const xc = foe.g.position.x;
  ok(Math.abs(xc - (1100 + 250 * 10 / 66)) < 1e-6, 'تأخّر الوصول ← استقراء 250ms بسرعة آخر لقطتين ثم تثبيت', xc);
  clock.ms = t0 + 9000; match.matchUpdate(DT); ok(foe.g.position.x === xc, 'ثابت بعد ذلك');
  session.handleServerMsg({t: 'st', id: 1, x: 9, y: 9, z: 9, yw: 0, pt: 0, rl: 0, sp: 1, hp: 1, b: 0, g: 0}); ok(W.units.length === 2, 'st بمعرّفي أتجاهله');
  session.handleServerMsg({t: 'st', id: 77, x: 9, y: 9, z: 9, yw: 0, pt: 0, rl: 0, sp: 1, hp: 1, b: 0, g: 0}); ok(W.units.length === 2, 'st لمجهول لا يرمي');

  console.log('   مغادرة طيار وتمرير room/start/err للمعالجات');
  session.handleServerMsg({t: 'left', id: 5}); ok(!ru.remoteOf(5) && !W.mp.players[5] && W.units.length === 1, 'left ← إزالة الوحدة وبيانات اللاعب');
  session.handleServerMsg({t: 'left', id: 5}); ok(W.units.length === 1, 'left مكرر لا يرمي');
  const hs = []; session.setHandlers({room: m => hs.push(['room', m.code]), start: m => hs.push(['start', m.map]), err: m => hs.push(['err', m.code])});
  const keep = W.mp; W.mp = null;
  session.handleServerMsg({t: 'room', code: 'AB12'}); session.handleServerMsg({t: 'start', map: 'island'}); session.handleServerMsg({t: 'err', code: 'full'});
  ok(JSON.stringify(hs) === '[["room","AB12"],["start","island"],["err","full"]]', 'room/start/err تُمرَّر للمعالجات بلا W.mp');
  session.handleServerMsg({t: 'st', id: 5, x: 1}); ok(true, 'st بلا ماتش لا يرمي'); W.mp = keep;
  session.setHandlers({room: null, start: null, err: null}); }

console.log('9) المحلي لا يرسل st');
{ fresh(); const sent = []; match.beginMatch({...cfg}); W.mp.transport = {send: m => sent.push(m)}; run(1, null);
  ok(sent.filter(m => m.t === 'st').length === 0, 'الوضع المحلي (MP0) لا يرسل st'); }

console.log(fail ? `\n${fail} فشل` : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
