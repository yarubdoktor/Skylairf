/* نسخة اختبار فقط: تهيئة ملف الحفظ لفتح كامل المحتوى لاختبار نماذج الطائرات والأسلحة.
   لا يُضمّن هذا الملف في النسخ العادية؛ يُستورد فقط في حزمة ALL-UNLOCKED-TEST. */
import {S, save} from './save.js';
import {PLANES, SKINS} from './data.js';
import {MISSIONS} from './mission/mission_defs.js';

// جميع الطائرات متاحة ومطوّرة إلى الحد الأقصى.
for (const id of Object.keys(PLANES)) S.pl[id] = 10;
S.sel = Object.keys(PLANES).includes(S.sel) ? S.sel : 'mig29';

// جميع منظومات الأسلحة متاحة وبأقصى مستوى.
for (const id of ['gun','msl','bvr','multi','bomb','agm','arm']) S[id] = 10;

// رصيد اختبار كبير لتجربة الشراء والترقيات دون نفاد الموارد.
S.coins = 99999999;
S.gems = 99999999;

// فتح جميع الألوان لكل الطائرات.
S.sko = S.sko || {};
S.sk = S.sk || {};
for (const id of Object.keys(PLANES)) {
  for (const skin of Object.keys(SKINS)) S.sko[id + ':' + skin] = 1;
  if (!SKINS[S.sk[id]]) S.sk[id] = 'gold';
}

// فتح الحملة كاملة مع إبقاء سجل النجوم والإنجازات مكتملًا لأغراض الاختبار.
S.ms = S.ms || {};
for (const mission of MISSIONS) {
  const prev = S.ms[mission.id] || {};
  S.ms[mission.id] = {
    stars: 3,
    best: Math.max(100000, prev.best || 0),
    bt: prev.bt || 1,
    n: Math.max(1, prev.n || 0),
    done: true
  };
}
S.cp = MISSIONS.length;

// رفع المستوى إلى رتبة عالية دون تفعيل مكافآت متكررة.
S.xp = Math.max(S.xp || 0, 60 * 35 * 35);
S.lvr = Math.max(S.lvr || 0, 36);

// تحميل العتاد الافتراضي بأقوى الخيارات لتسهيل الاختبار.
S.load = Object.assign({}, S.load, {aa:'bvr', ag:'agm', wing:1, diff:1});
save();
