/* واجهات المهمات داخل القائمة (HTML): العمليات · الإحاطة · التقييم · السجل + بطاقات اللوبي.
   المنطق (نجوم، تقدّم، إحاطة، تقرير) بملفات صرفة بـ src/mission/. هنا الرسم فقط. h = أدوات من menu.js */
import './menu_ms.css';
import {S} from './save.js';
import {t} from './i18n.js';
import {esc} from './util.js';
import {PLANES,loginInfo} from './data.js';
import {MISSIONS} from './mission/mission_defs.js';
import {summary,isUnlocked,nextIndex} from './mission/progress.js';
import {briefOf} from './mission/briefing.js';
import {normalizeLoad, AA_OPTS, AG_OPTS} from './mission/loadout.js';
import {fmtTime} from './mission/mission_hud.js';
import {ART} from './art.js';

export const stars = (n, max = 3) =>
  `<span class="stars">${Array.from({length:max}, (_, i) => `<i class="${i < n ? 'on' : ''}">★</i>`).join('')}</span>`;
const entry = m => S.ms[m.id] || {stars:0, best:0, bt:0, n:0, done:false};
const lines = s => esc(s).replace(/\n/g, '<br>');
const starText = (k, b) => t('st_'+k, {t:fmtTime(b.par)});

export function createMsViews(h){
  const {ic, plain, pimg, maps} = h;
  const MARK = {done:'✔', failed:'✖', open:'◇'}, opt = o => o.optional ? ' <small>('+t('ms_opt')+')</small>' : '';
  const missionCard = (m, i, mapList) => {
    const e = entry(m), open = isUnlocked(S.ms, MISSIONS, i), map = mapList.find(x => x.id === m.map);
    const art = (map && map.img) || ART.campaign?.['c'+((i%6)+1)] || '';
    const progress = Math.max(0, Math.min(100, (e.stars/3)*100));
    const reward = m.reward || {c:0,g:0,xp:0};
    return `<article class="op-card ${open?'':'locked'} ${e.done?'completed':''}">
      <div class="op-art">${art?`<img src="${art}" alt="">`:''}<span class="op-number">OPERATION ${String(i+1).padStart(2,'0')}</span>
        <span class="op-status">${e.done?'COMPLETED':open?'AVAILABLE':'LOCKED'}</span><span class="op-gradient"></span>
        <div class="op-art-title"><small>${plain(t('map_'+m.map))}</small><b class="tx">${t(m.title)}</b></div></div>
      <div class="op-details"><div class="op-meta"><span>◈ ${plain(t('map_'+m.map))}</span><span>★ ${e.stars}/3</span><span>🎯 ${m.objectives.length} أهداف</span></div>
        <p class="tx">${open?t(m.id+'d'):t('ops_locked')}</p>
        <div class="op-foot"><div class="op-reward"><small>مكافأة المهمة</small><b>+${reward.c||0} 🪙 ${reward.g?`· +${reward.g} 💎`:''}</b></div>
          <button data-a="brief" data-i="${i}" ${open?'':'disabled'}>${open?(e.done?'مراجعة المهمة':'تفاصيل العملية'):'🔒 مغلقة'}</button></div>
        <div class="op-stars"><i><b style="width:${progress}%"></b></i>${stars(e.stars)}</div></div></article>`;
  };
  const loginCard = () => { const lg = loginInfo();
    return `<div class="card"><div class="grow"><b class="tx">${t('loginT')}</b><small class="tx">${t('loginS',
      {d:lg.day, c:lg.coins, g:lg.gems ? ' +'+lg.gems+'💎' : ''})}</small></div>
      <button data-a="login" ${lg.can ? '' : 'disabled'}>${lg.can ? t('claim') : t('done')}</button></div>`; };
  const ops = () => { const sm = summary(S.ms, MISSIONS), mapList = maps();
    const pct = sm.total ? Math.round(sm.done/sm.total*100) : 0;
    return `<section class="ops-hub"><div class="ops-command"><div><span class="ops-kicker">FLIGHT COMMAND / OPERATIONS</span><h3>مركز العمليات</h3><p>اختر مهمتك التالية، راجع التهديدات، وانطلق لتنفيذ المهمة.</p></div><div class="ops-progress"><b>${sm.done}<small> / ${sm.total}</small></b><span>عمليات مكتملة</span><i><em style="width:${pct}%"></em></i><small>${pct}% من الحملة</small></div></div>
      <div class="ops-login">${loginCard()}</div><div class="ops-section-head"><div><small>MISSION CONTROL</small><b>سجل العمليات</b></div><span>${sm.stars} / ${sm.maxStars} ★</span></div>
      <div class="ops-grid">${MISSIONS.map((m,i)=>missionCard(m,i,mapList)).join('')}</div></section>`; };


  const brief = (i, PREV) => { const m = MISSIONS[i], b = briefOf(m), pl = PLANES[S.sel];
    const mp = maps().find(x => x.id === m.map), grad = mp ? mp.grad : '',
      img = `<img data-mi="${m.map}" src="${mp && mp.img || ''}" alt="" ${mp && mp.img ? '' : 'hidden'}>`;
    const objs = b.objectives.map(o => `
      <li class="tx">${t(o.text)}${opt(o)}</li>`).join('');
    const thr = b.threats.map(x => `<span class="chip tx">${x.n}× ${t('th_'+x.kind)}</span>`).join('');
    const sts = b.starKeys.map(k => `<li class="tx">★ ${starText(k, b)}</li>`).join('');
    const e = entry(m);
    return `<section class="briefing-premium">
      <header class="briefing-hero"><div class="briefing-backdrop" style="background:${grad}">${img}</div><div class="briefing-shade"></div><div class="briefing-hero-copy"><small>FLIGHT COMMAND / MISSION BRIEF</small><h2 class="tx">${t(m.title)}</h2><span>◈ ${plain(t('map_'+m.map))} · ${t('bf_side')}</span><div class="briefing-stars">${stars(e.stars)}</div></div><div class="briefing-index">OP ${String(i+1).padStart(2,'0')}</div></header>
      <section class="briefing-order"><div class="briefing-label"><small>COMMANDER'S ORDERS</small><b>${t('bf_order')}</b></div><p class="bf-order tx">${lines(t(b.order))}</p></section>
      <div class="briefing-two"><section class="briefing-panel"><header><small>PRIMARY OBJECTIVES</small><b>🎯 ${t('bf_obj')}</b></header><ul class="bf-list">${objs}</ul></section><section class="briefing-panel threat-panel"><header><small>HOSTILE INTELLIGENCE</small><b>⚠ ${t('bf_threat')}</b></header><div class="bf-chips">${thr}</div><p class="tx">${t('bf_roe_body')}</p></section></div>
      <section class="briefing-panel briefing-stars-panel"><header><small>MISSION PERFORMANCE</small><b>★ ${t('bf_stars')}</b></header><ul class="bf-list">${sts}</ul></section>
      <section class="briefing-loadout"><header><div><small>READY ROOM / AIRCRAFT</small><b>${t('bf_plane')}</b></div><button data-a="scr" data-i="hangar">تغيير الطائرة ↗</button></header><div class="briefing-aircraft"><img class="bf-pl" src="${pimg(PREV, S.sel)}" alt=""><b>${pl.n}</b><span>ACTIVE AIRCRAFT</span></div><div class="briefing-load-title">${t('ld_title')}</div>${loadoutPanel()}</section>
      <section class="briefing-reward"><div><small>MISSION REWARD</small><b>🏅 ${t('bf_reward')}</b></div><strong>+${b.reward.c} 🪙${b.reward.g ? ' · +'+b.reward.g+' 💎' : ''}</strong><span>+${b.reward.xp} XP</span></section></section>`;
  };
  function loadoutPanel(){
    const L = normalizeLoad(S.load);
    const chip = (a, i, on, lab) =>
      `<button data-a="${a}" data-i="${i}" class="chip ${on?'on':''}">${lab}</button>`;
    const aa = AA_OPTS.map(k => chip('ldaa', k, L.aa===k, t('w_'+k))).join('');
    const ag = AG_OPTS.map(k => {
      const locked = k!=='bomb' && !(S[k]>0);
      return `<button data-a="ldag" data-i="${k}" class="chip ${L.ag===k?'on':''}" ${locked?'disabled':''}>${t('w_'+k)}</button>`;
    }).join('');
    const diffs = [0,1,2].map(d => chip('lddiff', d, L.diff===d, t('diff_'+d))).join('');
    const wing = chip('ldwing', L.wing?0:1, !!L.wing, t('ld_wing')+': '+(L.wing?t('ld_on'):t('ld_off')));
    return `<div class="bf-load">
      <div class="tx"><small>${t('ld_aa')}</small><div class="bf-chips">${aa}</div></div>
      <div class="tx"><small>${t('ld_ag')}</small><div class="bf-chips">${ag}</div></div>
      <div class="tx"><small>${t('ld_diff')}</small><div class="bf-chips">${diffs}</div></div>
      <div class="bf-chips">${wing}</div>
      <small class="tx">C · ${t('cas_call')}</small>
    </div>`;
  }

  const money = r => '+'+r.c+'🪙'+(r.g ? ' +'+r.g+'💎' : '')+' · +'+r.xp+' XP';
  const row = (k, v, cls = '') => `<div class="db-r ${cls}"><span class="tx">${t(k)}</span><b>${v}</b></div>`;
  const debrief = d => { const sc = d.score, r = d.reward;
    const title = d.quit ? 'db_quit' : d.win ? 'db_win' : 'db_fail';
    const objs = d.rows.map(o => `
      <li class="st-${o.status} tx">${MARK[o.status]} ${t(o.text)}${opt(o)}</li>`).join('');
    const crit = d.criteria.map(c => `
      <li class="${c.ok ? 'ok' : 'no'} tx">${c.ok ? '★' : '☆'} ${starText(c.k, {par:d.par})}</li>`).join('');
    const rw = d.win ? `<div class="card">
      <div class="grow"><b class="tx">${t('db_reward')} · ${t(r.first ? 'db_first' : 'db_repeat')}</b>
      <small>${money(r)}${r.newStars ? ' · '+t('db_newstars', {n:r.newStars}) : ''}</small></div></div>` : '';
    const chip = (txt) => `<span class="chip tx">${txt}</span>`, sg = n => n > 0 ? '+'+n : n;
    const scoreRows = [['db_s_combat', sc.combat], ['db_s_win', sc.win], ['db_s_time', sc.time], ['db_s_hp', sc.hp],
      ['db_s_ally', sc.ally]].filter(([k, v], i) => i === 0 || v)
      .map(([k, v]) => row(k, k === 'db_s_combat' ? v : sg(v), v < 0 ? 'neg' : '')).join('');
    return `<section class="debrief-premium ${d.win?'mission-success':'mission-unsuccess'}">
      <header class="debrief-hero"><small>FLIGHT REPORT / AFTER ACTION</small><b class="tx">${t(title)}</b><em>${t(d.title)}</em>${stars(d.stars)}<span>${d.win?'MISSION ACCOMPLISHED':'MISSION NOT COMPLETED'}</span></header>
      <div class="sec tx">${t('db_obj')}</div><ul class="bf-list db-obj">${objs}</ul>
      <div class="sec tx">${t('db_stars')}</div><ul class="bf-list db-crit">${crit}</ul>
      <div class="sec tx">${t('db_score')}</div>
        <div class="db-sc">${scoreRows}
      ${row('db_total', sc.total, 'tot')}</div>
      <div class="db-m">${chip(t('db_time')+' '+fmtTime(d.t))}${chip(t('db_kills', {a:d.kj, g:d.kg}))}
      ${d.allyLost ? chip(t('db_ally', {n:d.allyLost})) : ''}${d.loot ? chip(t('db_battle')+' '+d.loot) : ''}</div>
      ${rw}${d.lvUp ? `<div class="card info"><b class="tx">${d.lvUp}</b></div>` : ''}
      <div class="db-btn"><button data-a="mission" data-i="${d.idx}">${t('db_retry')}</button>
      ${d.next >= 0 ? `<button data-a="brief" data-i="${d.next}">${t('db_next')}</button>` : ''}
      <button data-a="scr" data-i="ops">${t('db_back')}</button></div></section>`;
  };

  const record = () => { const sm = summary(S.ms, MISSIONS), runs = (S.st && S.st.n) | 0;
    const rows = MISSIONS.map((m,i) => { const e = entry(m);
      return `<article class="record-mission ${e.done?'cleared':'pending'}"><div class="record-number">${String(i+1).padStart(2,'0')}</div><div class="record-main"><b class="tx">${t(m.title)}</b><small class="tx">${e.done ? t('rc_time')+' '+fmtTime(e.bt)+' · ' : t('rc_none')+' · '}${t('rc_tries')} ${e.n}</small><div class="record-stars">${stars(e.stars)}</div></div><div class="record-best"><small>BEST SCORE</small><b>${e.best||'—'}</b><span>${e.done?'CLEARED':'NOT CLEARED'}</span></div></article>`; }).join('');
    return `<section class="pilot-record"><header class="record-hero"><small>SKY STRIKE / FLIGHT LOG</small><h3>سجل الطيار</h3><p>ملف الأداء والعمليات المنفذة خلال مسيرتك الجوية</p><div class="record-total"><b>${runs}</b><span>إجمالي الطلعات الجوية</span></div></header>
      <div class="record-kpis"><article><small>MISSIONS CLEARED</small><b>${sm.done}<em>/${sm.total}</em></b><span>عمليات مكتملة</span></article><article><small>CAMPAIGN STARS</small><b>${sm.stars}<em>/${sm.maxStars}</em></b><span>نجوم الحملة</span></article><article><small>TOP SCORE</small><b>${sm.best}</b><span>أفضل نتيجة</span></article><article><small>FLIGHT AVERAGE</small><b>${runs ? Math.round(sm.done/runs*100) : 0}%</b><span>معدل الإنجاز</span></article></div>
      <div class="record-section-head"><div><small>OPERATION HISTORY</small><b>أرشيف المهمات</b></div><span>${sm.done} CLEARED</span></div><div class="record-list">${rows}</div></section>`; };


  /* بطاقات اللوبي: العملية التالية + ملخص السجل (تحل مكان المهام اليومية والترتيب) */
  const nextCard = PREV => { const i = nextIndex(S.ms, MISSIONS), m = MISSIONS[i], e = entry(m);
    return `<button class="lb-event" data-a="brief" data-i="${i}"><img src="${pimg(PREV, S.sel)}" alt=""><div>
      <span class="tag">${t(e.done ? 'ops_open' : 'ops_new')}</span><b class="tx">${t(m.title)}</b>
      <small class="tx">${plain(t('map_'+m.map))}</small>${stars(e.stars)}</div></button>`; };
  const miniRecord = () => { const sm = summary(S.ms, MISSIONS);
    const r = (k, v) => `<div class="rk"><span class="tx">${t(k)}</span><b>${v}</b></div>`;
    return `<button class="lb-rank" data-a="scr" data-i="record">
      <div class="rk-h">${ic('trophy')}<b class="tx">${t('recT')}</b></div>
      ${r('rc_done', sm.done+' / '+sm.total)}${r('rc_stars', sm.stars+' / '+sm.maxStars)}
      ${r('rc_best', sm.best)}</button>`; };
  return {ops, brief, debrief, record, nextCard, miniRecord};
}
