/* الطيارون البعيدون بالماتش: كل طيار وحدة بـ W.units بالحقل remote:true (يتخطاها ai.js ولا يتأذى hp محلياً).
   الموضع/الدوران يأتي من لقطات st (setRemotePose) وتُطبَّق بـ updateRemotes كل فريم. */
import {PLANES, SKINS} from '../data.js';
import {mkJet} from '../jets.js';
import {scene, V} from '../core.js';
import {W} from '../state.js';
import {removeEnemy} from '../combat.js';
import {teamSide, INTERP_DELAY_MS} from '../../shared/match_rules.js';
import {createBuffer, pushSnap, sampleBuffer} from '../net/snapshot.js';

const _v = V();
export const remoteOf = pid => W.units.find(u => u.remote && u.pid === pid) || null;

/* player = {id, name, team, plane, skin} · pose = {x, y, z, yw, pt, rl, hp?} */
export function addRemoteUnit(player, pose){
  if(remoteOf(player.id)) removeRemoteUnit(player.id);
  const pl = PLANES[player.plane] || PLANES.mig29, sk = SKINS[player.skin] || SKINS.gray;
  const g = mkJet(pl.kind, pl.col, true, sk.c); g.rotation.order = 'YXZ';
  g.position.set(pose.x, pose.y, pose.z); g.rotation.set(pose.pt || 0, pose.yw || 0, pose.rl || 0);
  const e = {kind: 'remote', remote: true, pid: player.id, name: player.name, team: player.team, plane: player.plane,
    g, hp: pose.hp ?? pl.hp, max: pl.hp, r: 9, pts: 0, air: true, side: teamSide(W.mp.team, player.team),
    unarmed: true, vel: V(), yaw: pose.yw || 0, cd: 0, mcd: 0, bk: 0, bkT: 0, buf: createBuffer(), acc: 0};
  scene.add(g); W.units.push(e); return e;
}
export function removeRemoteUnit(pid){ const e = remoteOf(pid); if(e) removeEnemy(e); }

/* لقطة st جديدة: تدخل مخزن اللقطات (طابع الوصول المحلي mp.now) وتُعرض بـ updateRemotes بتأخير INTERP_DELAY_MS */
export function setRemotePose(pid, snap){
  const e = remoteOf(pid); if(!e) return;
  pushSnap(e.buf, snap, W.mp.now()); if(snap.hp != null) e.hp = snap.hp;
}

export function updateRemotes(dt){
  const now = W.mp ? W.mp.now() : 0;
  for(const e of W.units){
    if(!e.remote) continue;
    e.acc += dt;
    const s = sampleBuffer(e.buf, now, INTERP_DELAY_MS), p = e.g.position;
    if(s){
      _v.set(s.x, s.y, s.z);
      e.vel.copy(_v).sub(p).divideScalar(Math.max(e.acc, .001));     // السرعة يقرؤها مؤشر التصويب leadUpdate
      p.copy(_v); e.acc = 0; e.g.rotation.set(s.pt, s.yw, s.rl); e.yaw = s.yw; e.bkT = s.b ? 1 : 0;
    }
    e.bk += (e.bkT - e.bk) * Math.min(1, dt * 3);
    for(const f of (e.g.userData.fl || [])){        // لهب المحرك بنفس مقياس P.bk
      f.scale.z = .6 + e.bk * 1.4 + Math.random() * .25; f.scale.x = f.scale.y = .8 + e.bk * .3;
    }
  }
}
