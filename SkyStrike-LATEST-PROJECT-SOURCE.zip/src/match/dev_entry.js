/* مدخل تطوير الأونلاين (MP1، بلا واجهة لوبي — اللوبي بـ MP4أ): /?mp=create&autostart=2 و /?mp=join&code=XXXX
   create: ينشئ غرفة ويعرض كودها، ويرسل start تلقائياً عند بلوغ autostart لاعبين. join: ينضم ويرسل ready تلقائياً
   (بدونها يرفض السيرفر البدء: canStart). أول room يصل يحدّد هويتي (you). */
import {S} from '../save.js';
import {skinOf, level} from '../data.js';
import {$} from '../util.js';
import {t} from '../i18n.js';
import {banner} from '../ui.js';
import {PROTOCOL_VERSION} from '../../shared/protocol.js';
import {WS_URL} from '../net/config.js';
import {createNetClient} from '../net/client.js';
import {handleServerMsg, setHandlers} from './session.js';

/* شاشة التحميل كلوحة نص (لافتة banner داخل #hud المخفي بالقائمة) */
const say = txt => { $('#lt').textContent = txt; $('#load').classList.add('on'); };
const hideSoon = () => setTimeout(() => $('#load').classList.remove('on'), 3000);

/* q = URLSearchParams · deps = {startMatch} */
export async function devOnline(q, deps){
  const mode = q.get('mp'), auto = Math.max(2, parseInt(q.get('autostart'), 10) || 0);
  const net = createNetClient({url: WS_URL});
  const id = S.sel, me = {name: S.name, plane: id, skin: skinOf(id), lvl: Math.min(99, Math.max(1, level() | 0))};
  say(t('mp_conn'));
  try{ await net.connect(); }catch(e){
    say(t('mp_offline')); banner(t('mp_offline'), 'warn'); hideSoon(); return;
  }
  let last = null, sent = false, shown = false;
  setHandlers({
    err: m => { say(t('mp_err_' + m.code)); hideSoon(); },
    room: m => {
      last = m;
      if(mode === 'create' && !shown){
        shown = true; console.log('room', m.code); banner(t('mp_code') + ': ' + m.code, 'info');
      }
      if(m.state === 'lobby') say(t('mp_code') + ': ' + m.code + ' · ' + m.players.length + ' — ' + t('mp_wait'));
      if(sent || m.state !== 'lobby') return;
      if(mode === 'join'){ sent = true; net.send({t: 'ready', on: true}); }
      else if(m.host === m.you && m.players.length >= auto && m.players.every(p => p.id === m.host || p.ready)){
        sent = true; net.send({t: 'start'});
      }
    },
    start: m => {
      if(!last) return; const mine = last.players.find(p => p.id === last.you); if(!mine) return;
      $('#load').classList.remove('on');
      deps.startMatch({map: m.map, plane: mine.plane, skin: mine.skin, team: mine.team, id: mine.id, name: mine.name,
        spawn: m.spawns[mine.id], spawns: m.spawns, dur: m.dur, scoreLimit: m.scoreLimit,
        players: last.players, transport: net});
    }});
  net.on('*', handleServerMsg);
  net.on('close', () => console.log('net closed'));
  net.send(mode === 'join' ? {t: 'join', v: PROTOCOL_VERSION, code: (q.get('code') || '').toUpperCase(), ...me}
    : {t: 'create', v: PROTOCOL_VERSION, ...me});
}
