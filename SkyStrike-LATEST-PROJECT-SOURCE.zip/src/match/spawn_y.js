/* ارتفاع الظهور (D10): نفس معادلة startGame بالضبط. السيرفر يرسل x,z,yaw فقط والعميل يحسب y. */
import {world} from '../core.js';

export function spawnY(x, z){
  let gy = 0; for(let d = 0; d <= 1400; d += 200) gy = Math.max(gy, world.ground(x, z - d));
  return Math.min(gy + 170, 500);
}
