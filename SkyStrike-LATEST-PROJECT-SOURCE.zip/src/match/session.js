/* المدخل الوحيد لرسائل السيرفر (القسم 6 من AI_PLAN.md). بالوضع المحلي يغذّيه loopback والطيار الوهمي.
   يعالج: room · start · err (قبل الماتش وأثناءه، عبر معالجات setHandlers) · st · fire · respawn · left.
   بقية الأنواع تُضاف بالبنود اللاحقة (الافتراضي: تجاهل). */
import {PLANES} from '../data.js';
import {cam, world, V} from '../core.js';
import {W, P} from '../state.js';
import {el, banner} from '../ui.js';
import {t} from '../i18n.js';
import {shoot} from '../combat.js';
import {cp, camCfg} from '../player.js';
import {DMG, MSL_AMMO} from '../../shared/match_rules.js';
import {addRemoteUnit, removeRemoteUnit, setRemotePose, remoteOf} from './remote_unit.js';
import {spawnY} from './spawn_y.js';

/* معالجات ما قبل الماتش (لا W.mp بعد): يضبطها مدخل التطوير الآن، واللوبي بـ MP4أ */
const H = {room: null, start: null, err: null};
export const setHandlers = h => Object.assign(H, h);

export function handleServerMsg(msg){
  if(!msg) return;
  if(msg.t === 'room'){ if(H.room) H.room(msg); return; }
  if(msg.t === 'start'){ if(H.start) H.start(msg); return; }
  if(msg.t === 'err'){ if(H.err) H.err(msg); banner(t('mp_err_' + msg.code), 'warn'); return; }
  const mp = W.mp; if(!mp) return;
  switch(msg.t){
    case 'st': if(msg.id !== mp.id) setRemotePose(msg.id, msg); break;
    case 'fire': onFire(mp, msg); break;
    case 'respawn': if(msg.id === mp.id) respawnMe(mp, msg); else respawnOther(mp, msg); break;
    case 'left': onLeft(mp, msg); break;
    default: break;
  }
}

/* طيار غادر: تُزال وحدته وتظهر لافتة باسمه */
function onLeft(mp, m){
  const p = mp.players[m.id]; removeRemoteUnit(m.id); delete mp.players[m.id];
  if(p) banner(t('mp_left', {n: p.name}), 'info');
}

/* صاروخ طيار بعيد: tg = معرّف الهدف (أنا ← target:P، وإلا الوحدة البعيدة المطابقة) */
function onFire(mp, m){
  const u = remoteOf(m.id); if(!u || m.k !== 'msl') return;
  const target = m.tg === mp.id ? P : remoteOf(m.tg);
  shoot({owner: u.side === 'ally' ? 'a' : 'e', side: u.side, pos: V(m.x, m.y, m.z), dir: V(m.dx, m.dy, m.dz),
    speed: 480, dmg: DMG.msl, mis: true, turn: 2.8, life: 6, target, pid: m.id});
}

/* ظهور اللاعب المحلي: صحة وذخيرة ومشاعل كاملة + موضع/اتجاه + الكاميرا (كما startGame) */
function respawnMe(mp, m){
  const G = W.G, pl = PLANES[mp.plane], y = spawnY(m.x, m.z);
  G.dead = false; G.deadT = 0; P.hp = P.maxhp; P.msl = MSL_AMMO; P.flr = pl.fl;
  Object.assign(P, {yaw: m.yaw, pitch: 0, roll: 0, wr: 0, wp: 0, gl: 1, sx: 0, sy: 0, en: 1, cur: P.speed,
    bk: 0, gcd: 0});
  P.g.position.set(m.x, y, m.z); P.g.visible = true;
  const [cd0, ch0] = camCfg(); cp.set(m.x + Math.sin(m.yaw) * cd0, y + ch0, m.z + Math.cos(m.yaw) * cd0);
  cam.position.copy(cp); world.stream(P.g.position, true);
  mp.respawnT = 0; el.warn.textContent = ''; el.warn.style.opacity = 0;
}

/* ظهور طيار آخر: تُعاد إضافة وحدته (حُذفت عند kill) */
function respawnOther(mp, m){
  const pl = mp.players[m.id]; if(!pl) return;
  addRemoteUnit(pl, {x: m.x, y: spawnY(m.x, m.z), z: m.z, yw: m.yaw, pt: 0, rl: 0, hp: PLANES[pl.plane].hp});
}
