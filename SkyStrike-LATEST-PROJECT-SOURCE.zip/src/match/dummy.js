/* الطيار الوهمي (MP0): يدور 900م حول (0,0) بـ 150م/ث ويولّد لقطات st ورسائل fire بنفس شكل بروتوكول القسم 6
   ويمرّرها لـ handleServerMsg. لا يموت ولا يتضرر. يرسل لقطة كل فريم (ليبقى الحركة والسرعة سلسَين قبل مخزن MP1). */
import {PLANES} from '../data.js';
import {world} from '../core.js';
import {W, P} from '../state.js';
import {handleServerMsg} from './session.js';
import {addRemoteUnit} from './remote_unit.js';

const ID = 2, R = 900, SPEED = 150, OM = SPEED / R;
const r1 = v => Math.round(v * 10) / 10, r3 = v => Math.round(v * 1000) / 1000;
let D = null;

function pose(){
  const a = D.t * OM, x = R * Math.cos(a), z = R * Math.sin(a);
  const y = Math.max(world.ground(x, z) + 200, 300), yw = Math.atan2(Math.sin(a), -Math.cos(a));
  return {x: r1(x), y: r1(y), z: r1(z), yw: r3(yw), pt: 0, rl: .5, sp: SPEED, hp: PLANES.su57.hp, b: 0,
    g: (D.t % 5) < 1.5 ? 1 : 0};
}

export function startDummy(){
  D = {t: 0, fireT: 8, p: {id: ID, name: 'Dummy', team: 1, plane: 'su57', skin: 'gray'}};
  W.mp.players[ID] = D.p; addRemoteUnit(D.p, pose());
}
export function stopDummy(){ D = null; }

export function dummyUpdate(dt){
  if(!D) return;
  D.t += dt; const s = pose(); handleServerMsg({t: 'st', id: ID, ...s});
  D.fireT -= dt; if(D.fireT > 0) return;
  D.fireT = 8;
  const pp = P.g.position, dx = pp.x - s.x, dy = pp.y - s.y, dz = pp.z - s.z, d = Math.hypot(dx, dy, dz);
  if(d < 1500) handleServerMsg({t: 'fire', id: ID, k: 'msl', tg: W.mp.id, x: s.x, y: s.y, z: s.z,
    dx: dx / d, dy: dy / d, dz: dz / d});
}
