/* مدير الماتش: ينشئ W.mp (null بالفردي والحملة) ويحدّثه كل فريم. الشبكة لاحقاً (MP1) عبر transport؛
   بالوضع المحلي (MP0) يلعب loopback دور السيرفر (إعادة الظهور) والطيار الوهمي dummy.js. */
import {W, P} from '../state.js';
import {t} from '../i18n.js';
import {el} from '../ui.js';
import {inp} from '../input.js';
import {MP_MAPS, SCORE_LIMIT, TIME_LIMIT_S, RESPAWN_S, SEND_HZ, newBoard, spawnFor} from '../../shared/match_rules.js';
import {packState} from '../net/snapshot.js';
import {handleServerMsg} from './session.js';
import {updateRemotes} from './remote_unit.js';
import {startDummy, stopDummy, dummyUpdate} from './dummy.js';
import {addRemoteUnit} from './remote_unit.js';
import {spawnY} from './spawn_y.js';

/* loopback: يحاكي ردّ السيرفر محلياً. die ← respawn بعد RESPAWN_S ثانية بموضع الفريق 0 */
const loop = {q: [],
  send(m){
    if(m.t !== 'die') return;
    const s = spawnFor(W.mp.map, 0, 0);
    loop.q.push({at: RESPAWN_S, msg: {t: 'respawn', id: W.mp.id, x: s.x, z: s.z, yaw: s.yaw}});
  },
  tick(dt){
    for(let i = loop.q.length - 1; i >= 0; i--){
      const o = loop.q[i]; o.at -= dt; if(o.at > 0) continue;
      loop.q.splice(i, 1); handleServerMsg(o.msg);
    }
  }};

export function beginMatch(cfg){
  const dur = cfg.dur || TIME_LIMIT_S;
  const ids = cfg.players ? cfg.players.map(p => p.id) : cfg.local ? [cfg.id, 2] : [cfg.id];
  loop.q.length = 0;
  const mp = W.mp = {id: cfg.id, team: cfg.team, name: cfg.name, map: cfg.map, plane: cfg.plane,
    limit: MP_MAPS[cfg.map].limit, local: !!cfg.local, transport: cfg.local ? loop : (cfg.transport || null),
    now: cfg.now || (() => performance.now()),           // ساعة طوابع الوصول (ms)؛ الاختبارات تحقن ساعة اصطناعية
    players: {}, left: dur, dur, scoreLimit: cfg.scoreLimit || SCORE_LIMIT, sb: newBoard(ids), respawnT: 0, sendT: 0,
    onHit(pid, k){ mp.transport.send({t: 'hit', by: pid, k}); },
    onDie(){ mp.respawnT = RESPAWN_S; mp.transport.send({t: 'die'}); }};
  mp.players[cfg.id] = {id: cfg.id, name: cfg.name, team: cfg.team, plane: cfg.plane, skin: cfg.skin};
  if(mp.local) startDummy();
  for(const p of (cfg.players || [])){          // أونلاين: بقية الطيارين عند مواضع ظهورهم (D10: y يحسبها العميل)
    mp.players[p.id] = p; const sp = cfg.spawns && cfg.spawns[p.id];
    if(p.id !== cfg.id && sp) addRemoteUnit(p, {x: sp.x, y: spawnY(sp.x, sp.z), z: sp.z, yw: sp.yaw, pt: 0, rl: 0});
  }
}

/* لقطتي st كل 1/SEND_HZ ثانية وأنا حي (أونلاين فقط؛ المحلي لا سيرفر له) */
function sendState(dt, mp){
  mp.sendT -= dt; if(mp.sendT > 0) return;
  mp.sendT += 1 / SEND_HZ; if(mp.sendT < 0) mp.sendT = 0;
  const p = P.g.position;
  mp.transport.send({t: 'st', ...packState({x: p.x, y: p.y, z: p.z, yw: P.yaw, pt: P.pitch, rl: P.roll, sp: P.cur,
    hp: P.hp, b: P.bk > .3, g: inp.fire})});
}

export function matchUpdate(dt){
  const mp = W.mp; if(!mp) return;
  mp.left = Math.max(0, mp.left - dt);
  if(mp.local){ loop.tick(dt); dummyUpdate(dt); }
  updateRemotes(dt);
  if(!mp.local && mp.transport && !W.G.dead && mp.respawnT <= 0) sendState(dt, mp);
  if(mp.respawnT > 0){                      // ميت بانتظار الظهور
    mp.respawnT = Math.max(0, mp.respawnT - dt);
    if(mp.respawnT > 0){
      el.warn.textContent = t('mp_respawn', {s: Math.ceil(mp.respawnT)}); el.warn.style.opacity = 1;
    }
  }
}

/* نهاية الماتش (يستدعيها finish بعد التنظيف العام): تفكيك الحالة والعودة للوبي */
export function endMatch(quit, menu){
  stopDummy(); loop.q.length = 0; W.mp = null;
  el.warn.textContent = ''; el.warn.style.opacity = 0;
  menu.show('lobby');
}
