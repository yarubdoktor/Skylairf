/* نقطة الدخول. كل شي موزّع على الملفات (انظر جدول الهيكل بـ README). */
import './lobby.css';
import './test_unlock.js'; // نسخة اختبار مستقلة: فتح جميع المحتويات
import {boot} from './game.js';
import {initBrandIcons} from './icons.js';

initBrandIcons();   // أيقونات الهوية بدل إيموجي النظام (v25)
boot();
