/* القتال: الطلقات والصواريخ والقنابل، الانفجارات، الضرر، القتل، المشاعل. */
import * as THREE from 'three';
import {$,clamp,rnd} from './util.js';
import {t} from './i18n.js';
import {sfx,setEngine} from './audio.js';
import {mkMsl,mkBomb,BULLET_GEO,BULLET_P,BULLET_E} from './jets.js';
import {scene,world,fx,V,vib,panOf,dirOfTo} from './core.js';
import {Q} from './quality.js';
import {W,P,shadow} from './state.js';
import {banner} from './ui.js';
import {pushEvent} from './mission/mission_runtime.js';
import {segDist2} from './collide.js';
import {isHostile,hitMul,sideOf,FRIENDLY_FIRE} from './mission/factions.js';

const _a = V(), _b = V(), _o = V();       // _o = موضع الطلقة قبل الحركة (للتصادم بالمسار)

export function boom(pos,r=12){
  const d = pos.distanceTo(P.g.position);
  if(r < 12){ fx.glow(pos.x,pos.y,pos.z,0xffe9a0,r*1.4,r*3.5,.18); return; }
  const big = r >= 22; sfx('boom',clamp(1-d/1500,.15,1),big,panOf(pos));
  fx.explode(pos,r); W.shake = Math.max(W.shake,clamp(1-d/700,0,1)*(big?1.6:1)); if(big && d < 500) vib(40);
}
/* o.side: جهة صاحب الطلقة ('player'|'ally'|'enemy'). بدونها تُشتق من owner ('p' لاعب، غيره عدو) كما قبل v26.3.2 */
export const projSide = o => o.side || (o.owner === 'p' ? 'player' : 'enemy');
export function shoot(o){
  const side = projSide(o), foe = side === 'enemy'; let mesh;
  if(o.bomb) mesh = mkBomb(); else if(o.mis) mesh = mkMsl(foe, o.bvr?'bvr':(o.arm?'arm':(o.agm?'agm':'std')));
  else { mesh = new THREE.Mesh(BULLET_GEO,foe ? BULLET_E : BULLET_P); mesh.scale.set(1,1,7); }
  mesh.position.copy(o.pos); scene.add(mesh);
  if(side !== 'player') sfx(o.mis?'emsl':'efire',clamp(1-o.pos.distanceTo(P.g.position)/900,0,1),false,panOf(o.pos));
  W.projs.push({mesh,dir:o.dir.clone().normalize(),speed:o.speed,dmg:o.dmg,owner:o.owner,side,mis:!!o.mis,bomb:!!o.bomb,
    pid:o.pid||null,bvr:!!o.bvr,agm:!!o.agm,arm:!!o.arm,
    target:o.target||null,turn:o.turn||2.4,vy:0,life:o.life||(o.bomb?14:o.mis?7:2.2)});
}

/* ---------- اللاعب: ضرر / موت ---------- */
export function die(){ const G = W.G; if(G.dead) return; G.dead = true; G.deadT = 1.8; boom(P.g.position,30); P.g.visible = false; shadow.visible = false; setEngine(0); vib(200); if(W.mp) W.mp.onDie(); }
export function hurt(d){
  const G = W.G; if(G.dead || W.tut) return; G.hit = true; P.hp -= d; sfx('hit'); W.shake = Math.max(W.shake,.6); vib(30);
  { const pp = P.g.position; for(let i=0;i<9;i++){ const s = rnd(30,70);                         // شرر عند إصابة طائرتك
      fx.glow(pp.x+rnd(-2.5,2.5),pp.y+rnd(-1,1.5),pp.z+rnd(-2.5,2.5), i%2?0xffd060:0xff7020, 1.8,.3, rnd(.25,.6), rnd(-1,1)*s,rnd(-.3,1)*s,rnd(-1,1)*s, 1, 70); }
    fx.smk(pp.x,pp.y,pp.z,0x222222,2,9,1.2,0,3,0,.7); }
  const f = $('#fl'); f.style.opacity = .35; setTimeout(() => f.style.opacity = 0,120); if(P.hp <= 0) die();
}

/* ---------- الأعداء: إزالة / قتل ---------- */
export function removeEnemy(e){ scene.remove(e.g); const i = W.units.indexOf(e); if(i >= 0) W.units.splice(i,1); if(W.lockE === e) W.lockE = null; if(W.candE === e){ W.candE = null; W.lockT = 0; } }
/* by = جهة القاتل. مكافآت اللاعب (نقاط/كومبو/عملات) فقط لو قتل معادياً؛ قتل حليف بنيرانه = عقوبة (FRIENDLY_FIRE) */
export function kill(e,by = 'player'){
  const G = W.G;
  if(e.air && !e.remote) startWreck(e); else { boom(e.g.position,e.air ? (e.kind === 'bomber' ? 26 : 22) : 16); removeEnemy(e); }
  if(by === 'player' && isHostile(by,sideOf(e))){
    if(e.air) G.kj++; else G.kg++;
    G.combo++; G.ct = 4; G.mult = Math.min(5,1+Math.floor(G.combo/3));
    G.score += Math.round(e.pts*G.mult); G.coins += Math.round(e.pts/8); G.xp += Math.round(e.pts/5);
  } else if(by === 'player' && sideOf(e) === 'ally'){
    G.ff = (G.ff||0)+1; G.combo = 0; G.mult = 1; G.score = Math.max(0,G.score-FRIENDLY_FIRE.killPenalty);
    banner(t('ffKill'), 'warn'); sfx('alarm');
  }
  if(sideOf(e) === 'ally') G.al = (G.al||0)+1;                       // خسائر صديقة (للتقييم)
  if(G.ms && e.mid) pushEvent(G.ms,{type:'entityDead',id:e.mid,by});   // الحدث يقرأه mission_bridge
}
/* إصابة وحدة بطلقة جهتها ps: يرجع true لو تأثّرت. نيران صديقة من اللاعب = ضرر مخفّض + تحذير مُخفَّف التكرار */
function hitUnit(e,dmg,ps){
  if(e.remote) return isHostile(ps,sideOf(e));      // طيار بعيد: تأثير بصري فقط (الضرر بيد الضحية)
  const k = hitMul(ps,sideOf(e)); if(!k) return false;
  const G = W.G; e.hp -= dmg*k;
  if(k < 1 && (G.t||0)-(G.ffT ?? -9) > FRIENDLY_FIRE.warnEvery){ G.ffT = G.t||0; banner(t('ffWarn'), 'warn'); }
  if(e.hp <= 0) kill(e,ps);
  return true;
}
/* تنظيف كل الكيانات (بداية/نهاية مهمة). المصفوفات تُفرَّغ بالمكان لأن باقي الملفات تقرأها من W */
export function clearEntities(){
  const G = W.G;
  for(const e of W.units) scene.remove(e.g); for(const p of W.projs) scene.remove(p.mesh);
  for(const w of wrecks) scene.remove(w.g); wrecks.length = 0;
  W.units.length = 0; W.projs.length = 0; W.flares.length = 0; W.lockE = null; W.candE = null; W.lockT = 0;
}

/* ---------- سقوط الطائرات المصابة: تشتعل وتدور وتهوي ثم تنفجر عند الأرض ---------- */
const wrecks = [], _wv = V(), _wt = V();
function startWreck(e){
  const pos = e.g.position, d = pos.distanceTo(P.g.position), vol = clamp(1-d/1500,.15,1);
  fx.explode(pos,9); sfx('boom',vol*.75,false,panOf(pos)); if(d < 1400) sfx('fall',vol,false,panOf(pos));      // ضربة قاتلة في الجو
  const i = W.units.indexOf(e); if(i >= 0) W.units.splice(i,1);                                                  // خارج الأهداف/الاصطدام، لكن الجسم يبقى يسقط
  if(W.lockE === e) W.lockE = null; if(W.candE === e){ W.candE = null; W.lockT = 0; }
  dirOfTo(e.g,_wv); const heli = e.kind === 'heli', spd = clamp(e.sp || 90,heli ? 0 : 40,230);
  wrecks.push({g:e.g,v:_wv.clone().multiplyScalar(spd*(heli ? .3 : .85)),t:0,roll:0,spin:(Math.random()<.5?-1:1)*rnd(heli ? 5 : 2.5,heli ? 8 : 5),
    acc:0,big:e.kind === 'bomber',kind:e.kind});
}
function wrecksUpdate(dt){
  for(let i = wrecks.length-1; i >= 0; i--){
    const w = wrecks[i], g = w.g, p = g.position; w.t += dt;
    w.v.y -= (w.kind === 'heli' ? 55 : 38)*dt; w.v.x *= 1-.04*dt; w.v.z *= 1-.04*dt;
    p.addScaledVector(w.v,dt);
    w.roll += w.spin*dt; _wt.copy(p).sub(w.v); g.lookAt(_wt); g.rotateZ(w.roll);       // الأنف باتجاه السقوط + دوران حول المحور
    w.acc += dt; let n = 0;
    while(w.acc >= .03 && n < 3){ w.acc -= .03; n++;
      fx.glow(p.x+rnd(-1.5,1.5),p.y+rnd(-.5,1),p.z+rnd(-1.5,1.5),Math.random()<.5?0xff5010:0xffa030,5+Math.random()*4,1,.3,0,2,0,.9);
      fx.smk(p.x,p.y,p.z,Math.random()<.5?0x121212:0x262626,3.5,15+Math.random()*6,2.4,rnd(-1,1),2,rnd(-1,1),.85); }
    if(Math.random() < dt*7) fx.glow(p.x,p.y,p.z,0xffe080,1.6,.3,rnd(.4,.9),rnd(-1,1)*40,rnd(0,1)*30,rnd(-1,1)*40,1,90);
    if(p.y <= world.ground(p.x,p.z)+2 || w.t > 7){                                    // ارتطام: انفجار كبير
      p.y = Math.max(p.y,world.ground(p.x,p.z)+1); boom(p,w.big ? 30 : 24); fx.debris(p,10,rnd(50,100));
      scene.remove(g); wrecks.splice(i,1); }
  }
}

/* ---------- تحديث الطلقات والمشاعل ---------- */
export function projectilesUpdate(dt){
  wrecksUpdate(dt);
  const pos = P.g.position, G = W.G, units = W.units, projs = W.projs, flares = W.flares;
  for(let pi=projs.length-1;pi>=0;pi--){
    const p = projs[pi], mp = p.mesh.position, ps = projSide(p), tg = p.target;
    if(p.mis){
      if(tg && tg !== P && tg.fl > 0 && G.diff >= 4 && tg.g.position.distanceToSquared(mp) < 280*280
        && Math.random() < dt*Math.min(2,(G.diff-3)*.4)){           // الهدف يطلق مشعلاً فيضيع الصاروخ
        const tp = tg.g.position; tg.fl--; p.target = null;
        sfx('flare',clamp(1-tp.distanceTo(pos)/900,0,1),false,panOf(tp));
        for(let k=0;k<3;k++) fx.glow(tp.x+rnd(-6,6),tp.y+rnd(-6,2),tp.z+rnd(-6,6),0xffb060,5,2,.5,0,0,0,.95); }
      if(p.target && p.target !== P){          // صاروخ موجّه نحو وحدة (لاعب أو حليف أو عدو)
        if(units.includes(p.target)){
          _a.copy(p.target.g.position).sub(mp).normalize(); p.dir.lerp(_a,Math.min(1,dt*p.turn)).normalize(); } }
      else if(ps === 'enemy' || p.target === P){    // صاروخ عدو (أو موجّه للاعب): يتتبع اللاعب أو أقرب مشعل
        let tp = pos, bs = 360*360;
        for(const f of flares){ const d2 = f.p.distanceToSquared(mp); if(d2 < bs){ bs = d2; tp = f.p; } }
        const turn = dt*p.turn*(tp === pos ? P.ms : 1);                     // التخفّي: أضعف تتبعاً للاعب
        _a.copy(tp).sub(mp).normalize(); p.dir.lerp(_a,Math.min(1,turn)).normalize(); }
      // ذيل صاروخ سينمائي: نواة بيضاء، لهب ملوّن، شرر متقطع ودخان رمادي متدرّج
      const tx = mp.x-p.dir.x*3.2, ty = mp.y-p.dir.y*3.2, tz = mp.z-p.dir.z*3.2;
      fx.glow(tx,ty,tz,0xffffff,3.8+Math.random()*1.4,.65,.075,0,0,0,1);
      fx.glow(mp.x-p.dir.x*5.8,mp.y-p.dir.y*5.8,mp.z-p.dir.z*5.8,p.bvr?0x65ffe0:(p.arm?0xff4930:0xff7a22),6+Math.random()*2.8,1.0,.2,0,0,0,.88);
      fx.glow(mp.x-p.dir.x*7.2,mp.y-p.dir.y*7.2,mp.z-p.dir.z*7.2,p.bvr?0x35cfae:(p.arm?0xd92e20:0xe94a12),3.2,1.1,.24,0,0,0,.62);
      p.fxT = (p.fxT || 0)-dt;
      if(p.fxT <= 0){
        p.fxT = Q.fx >= 260 ? .055 : .09;
        const sv = p.speed*.12;
        fx.glow(tx+rnd(-.35,.35),ty+rnd(-.35,.35),tz+rnd(-.35,.35),p.bvr?0x9bffe8:0xffd18a,1.8,.25,.22,
          -p.dir.x*sv+rnd(-5,5),-p.dir.y*sv+rnd(-3,4),-p.dir.z*sv+rnd(-5,5),.95,35);
      }
      { const sp = Q.fx >= 260 ? 10 : 17; p.tr = (p.tr || 0)+p.speed*dt; let n = 0;
        while(p.tr >= sp && n < 3){ p.tr -= sp; n++; const b = 3+p.tr;
          fx.smk(mp.x-p.dir.x*b+rnd(-.55,.55),mp.y-p.dir.y*b+rnd(-.55,.55),mp.z-p.dir.z*b+rnd(-.55,.55),
            n%2?0x777b80:0x9a9a96,2.2,8.5+Math.random()*3.5,2.45,
            -p.dir.x*rnd(1,3)+rnd(-.8,.8),1.5,-p.dir.z*rnd(1,3)+rnd(-.8,.8),.58); } }
      if(ps === 'enemy' && !G.dead){                        // صاروخ عدو يقترب منك: هسيس يشتد كلما قرب
        const dd = mp.distanceTo(pos);
        if(dd < 480){ p.wt = (p.wt || 0)-dt; if(p.wt <= 0){ p.wt = .2; sfx('mslpass',clamp(1-dd/480,.15,1),false,panOf(mp)); } } }
    }
    _o.copy(mp); mp.addScaledVector(p.dir,p.speed*dt);
    if(p.bomb){ p.vy -= 75*dt; mp.y += p.vy*dt; _b.copy(mp).addScaledVector(p.dir,p.speed); _b.y += p.vy; p.mesh.lookAt(_b); }
    else { _b.copy(mp).add(p.dir); p.mesh.lookAt(_b); }
    p.life -= dt;
    const gh = world.ground(mp.x,mp.z), wl = world.cfg && world.cfg.water ? world.cfg.water.level : null, onG = mp.y < gh; let wat = false;
    let dead = p.life <= 0 || onG, boomed = false;   // boomed: انفجرت عند الإصابة
    if(!dead){
      for(const e of units){                    // تتأثر حسب hitMul (معادٍ كامل · حليف: نيران صديقة من اللاعب فقط)
        if(!hitMul(ps,sideOf(e))) continue;
        if(e.remote && !isHostile(ps,sideOf(e))) continue;           // قذائف الفريق الواحد تمر عبر الحلفاء
        const ep = e.g.position, hr = e.r+(e.air?0:2);
        if(segDist2(_o.x,_o.y,_o.z,mp.x,mp.y,mp.z,ep.x,ep.y,ep.z) < hr*hr){
          dead = true; boomed = true; boom(mp,p.mis?16:3); hitUnit(e, p.arm && (e.kind==='sam'||e.kind==='depot') ? p.dmg*1.6 : p.dmg, ps); break; } }
      if(!dead && isHostile(ps,'player') && !G.dead && segDist2(_o.x,_o.y,_o.z,mp.x,mp.y,mp.z,pos.x,pos.y,pos.z) < 49){
        hurt(p.dmg); if(W.mp && p.pid) W.mp.onHit(p.pid, p.mis ? 'msl' : 'gun'); dead = true; boomed = true; boom(mp,p.mis?12:4); }
      if(!dead && p.mis && ps === 'enemy'){
        for(const f of flares){ if(f.p.distanceToSquared(mp) < 100){ dead = true; break; } } }
      if(!dead && ps !== 'enemy' && !p.mis && !p.bomb){          // رصاص اللاعب/الحلفاء يسقط صواريخ المعادي
        for(const q of projs){ if(q.mis && isHostile(ps,projSide(q)) && segDist2(_o.x,_o.y,_o.z,mp.x,mp.y,mp.z,
        q.mesh.position.x,q.mesh.position.y,q.mesh.position.z) < 20){
          q.life = 0; dead = true;
          fx.flak(mp.x,mp.y,mp.z,5.5);
          for(let k=0;k<4;k++) fx.glow(mp.x+rnd(-2,2),mp.y+rnd(-2,2),mp.z+rnd(-2,2),k%2?0xffd28a:0xff6330,
            2.2,.25,.22,rnd(-35,35),rnd(-18,28),rnd(-35,35),.95,45);
          break;
        } } }

    }
    if(!dead && wl !== null && mp.y < wl){ dead = true; wat = true; }          // سقطت على سطح الماء
    if(dead){
      if(!p.mis && !p.bomb && !boomed && (onG || wat)) impactFx(mp,gh,wl,onG && !(wl !== null && gh < wl) && !wat);
      if(p.mis && !boomed) boom(mp,12);
      if(p.bomb){ boom(mp,26); for(const e of units.slice()){ const dd = e.g.position.distanceTo(mp);
        if(dd < 36) hitUnit(e,p.dmg*(1-dd/48),ps); } }
      scene.remove(p.mesh); projs.splice(pi,1);
    }
  }
}
/* أثر الرصاص: غبار وشرر على الأرض · رذاذ أبيض على الماء. صوت محدود التكرار حتى لا يزدحم */
let impT = 0;
function impactFx(mp,gh,wl,dirt){
  const water = wl !== null && (gh < wl || !dirt), y = water ? wl : gh;
  if(water){
    fx.glow(mp.x,y+1,mp.z,0xd8f0ff,2.2,.5,.25,rnd(-4,4),rnd(28,48),rnd(-4,4),.8,110);
    fx.smk(mp.x,y+1,mp.z,0xeaf6ff,2,9,.9,rnd(-2,2),10,rnd(-2,2),.55);
  } else {
    fx.smk(mp.x,y+.5,mp.z,0x8a7a62,2,9,1.1,rnd(-3,3),5,rnd(-3,3),.6);
    fx.glow(mp.x,y+.5,mp.z,0xffc060,2,.4,.18,rnd(-12,12),rnd(8,26),rnd(-12,12),.9,80);
  }
  const now = W.G.t || 0, d = mp.distanceTo(P.g.position);
  if(now-impT > .12 && d < 800){ impT = now; sfx(water ? 'splash' : 'impact',clamp(1-d/800,.1,1),false,panOf(mp)); }
}
export function flaresUpdate(dt){
  const flares = W.flares;
  for(let i=flares.length-1;i>=0;i--){
    const f = flares[i]; f.life -= dt; if(f.life <= 0){ flares.splice(i,1); continue; }
    f.v.y -= 9*dt; f.p.addScaledVector(f.v,dt); f.v.multiplyScalar(1-dt*.5);
    fx.glow(f.p.x,f.p.y,f.p.z,0xfff4d0,6+Math.random()*3,2,.1,0,0,0,1);                    // نواة بيضاء ساطعة
    fx.glow(f.p.x,f.p.y,f.p.z,0xff9a40,16+Math.random()*5,5,.3,0,0,0,.55);                // هالة برتقالية
    f.sm = (f.sm || 0)+dt; while(f.sm >= .035){ f.sm -= .035; fx.smk(f.p.x,f.p.y,f.p.z,0xf2f2f2,2.5,11,2.5,rnd(-1,1),1,rnd(-1,1),.55); }
    if(Math.random() < dt*10) fx.glow(f.p.x,f.p.y,f.p.z,0xffe080,1.4,.3,rnd(.3,.7),rnd(-1,1)*25,rnd(-1,1)*20,rnd(-1,1)*25,1,60);
  }
}
