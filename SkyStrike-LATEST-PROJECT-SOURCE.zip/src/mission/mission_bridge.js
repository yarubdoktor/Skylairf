/* جسر المهمة بالمحرك: يبدأ المهمة (إنشاء الكيانات + آلة الحالات) ويحدّثها كل فريم ويحوّل مخرجاتها لحالة اللعبة.
   المنطق نفسه بـ mission_runtime.js (صرف)؛ هنا فقط الربط بالمحرك (HUD، صوت، تعزيزات، لاسلكي، نهاية). */
import {createRuntime, pushEvent, stepRuntime} from './mission_runtime.js';
import {resolveRuntime} from './mission_resolve.js';
import {spawnEntities, spawnList} from './entities.js';
import {makeSnap, updateMarks} from './mission_snap.js';
import {showComm, showBrief, clearComms} from './comms_ui.js';
import {W, P} from '../state.js';
import {world} from '../core.js';
import {banner} from '../ui.js';
import {t} from '../i18n.js';
import {sfx, radioSay} from '../audio.js';
import {getLang} from '../i18n.js';
import {splitBrief} from './comms.js';
import {kill} from '../combat.js';
import {fx} from '../core.js';
import {S} from '../save.js';
import {normalizeLoad, diffMul} from './loadout.js';
import {addAir} from '../spawn.js';
import {V} from '../core.js';
import {canCall, pickCasTargets, CAS_CD} from './support.js';
import {wingSlot} from './wingman.js';

const ST = {placed:null, start:null, markT:0};

export function beginMission(def){
  const G = W.G; G.ms = createRuntime(def);
  const L = normalizeLoad(S.load);
  G.load = L;
  const dm = diffMul(L.diff);
  // صعوبة اللاعب تُضاعف صعوبة المهمة الأساسية
  G.diff = Math.max(1, Math.round(def.difficulty * dm.ai));
  G.casCd = 0; G.casMarks = [];
  const spawn = world.cfg.spawn || {x:0, z:0, yaw:0};
  ST.start = {x:spawn.x, z:spawn.z, yaw:spawn.yaw || 0, sites:world.cfg.sites}; ST.markT = 0;
  ST.placed = spawnEntities(def, ST.start).placed;
  // تطبيق مضاعف الصحة على الأعداء
  for(const e of W.units){
    if(e.side === 'enemy'){
      e.hp = Math.round(e.hp * dm.hp); e.max = e.hp;
    }
  }
  // wingman
  if(L.wing){
    const slot = wingSlot(P.g.position.x, P.g.position.y, P.g.position.z, P.yaw || 0);
    const wm = addAir('jet', V(slot.x, Math.max(slot.y, world.ground(slot.x, slot.z)+80), slot.z), G.diff, 'ally');
    wm.wingman = true; wm.mid = 'wing1';
    G.wingman = wm;
  } else G.wingman = null;
  resolveRuntime(G.ms, ST.start, ST.placed);
  clearComms(); showBrief(t(def.intro), t(def.title)); radioSay('mod', splitBrief(t(def.intro)).body, getLang());
}

/** طلب إسناد: يعلّم أهدافاً أرضية قريبة ويُلحق ضرراً خفيفاً بعد تأخير قصير (ضربة من خارج الشاشة) */
export function requestCAS(){
  const G = W.G;
  if(!canCall(G)) { banner(t('cas_cd'), 'warn'); return false; }
  const targets = pickCasTargets(W.units, P.g.position, 3);
  if(!targets.length){ banner(t('cas_none'), 'warn'); return false; }
  G.casCd = CAS_CD;
  G.casMarks = targets.map(e => e);
  showComm('gnd', 'cas_ack', 4); sfx('radio'); radioSay('gnd', t('cas_ack'), getLang());
  // ضربة متأخرة
  G.casT = 2.2;
  G.casList = targets;
  banner(t('cas_call'), 'ok');
  return true;
}

/** تحديث المرافقة: تبقى خلف اللاعب وتشتبك مع أقرب عدو */
function wingUpdate(dt){
  const G = W.G, wm = G.wingman;
  if(!wm || wm.hp <= 0){ G.wingman = null; return; }
  const pp = P.g.position;
  const slot = wingSlot(pp.x, pp.y, pp.z, P.yaw || 0);
  const wp = wm.g.position;
  const dx = slot.x - wp.x, dy = slot.y - wp.y, dz = slot.z - wp.z;
  const dist = Math.sqrt(dx*dx+dy*dy+dz*dz);
  // اقترب من التشكيل
  if(dist > 40){
    const sp = Math.min(160, 40 + dist * 0.35);
    wp.x += (dx/dist) * sp * dt;
    wp.y += (dy/dist) * sp * dt;
    wp.z += (dz/dist) * sp * dt;
  }
  // هدف: أقرب عدو جوي أو أي عدو
  let best = null, bd = 1600;
  for(const e of W.units){
    if(!e || e.hp <= 0 || e.side === 'ally' || e.side === 'player') continue;
    const d = e.g.position.distanceTo(wp);
    if(d < bd){ bd = d; best = e; }
  }
  if(best && bd < 1200){
    wm.target = best;
    // يوجّه المجسم نحو الهدف
    try{ wm.g.lookAt(best.g.position); }catch(err){}
  }
}

export function casUpdate(dt){
  const G = W.G; if(!G) return;
  if(G.casCd > 0) G.casCd -= dt;
  if(G.casT > 0){
    G.casT -= dt;
    if(G.casT <= 0 && G.casList){
      for(const e of G.casList){
        if(!e || e.hp <= 0) continue;
        const pos = e.g.position;
        fx.explode(pos, 22);
        e.hp -= Math.max(55, (e.max || 100) * 0.55);
        if(e.hp <= 0) kill(e, 'ally');
      }
      G.casList = null; G.casMarks = [];
      sfx('boom', 0.6, true);
    }
  }
}
/* تعزيزات محفّز: d/a تُقاس من موضع اللاعب الآن (ما لم يكن at:'start') */
function reinforce(list){
  const p = P.g.position, frame = {x:p.x, z:p.z, yaw:P.yaw, start:ST.start, sites:ST.start.sites};
  try{ spawnList(list, W.G.ms.def.difficulty, frame, ST.placed); }
  catch(err){ console.error('mission reinforce failed:', err); }       // لا نجمّد اللعبة بسبب تعريف تعزيز خاطئ
}
function onOutput(o){
  const G = W.G;
  if(o.type === 'objective'){
    if(o.status === 'done' || o.status === 'active') sfx('lock');
    if(o.status === 'failed') sfx('alarm');
    return;
  }
  if(o.type === 'spawn'){ reinforce(o.list); return; }
  if(o.type === 'comm'){ showComm(o.from, o.text, o.hold); sfx('radio'); radioSay(o.from, t(o.text), getLang()); return; }
  if(o.type !== 'end') return;
  if(o.result === 'won'){ G.win = true; G.wait = 2.8; banner(t('ms_win'), 'win'); sfx('win'); }
  else {                                   // الفشل بسبب الموت يُنهى بمساره الحالي (G.deadT)
    banner(t('ms_fail'), 'fail'); if(!G.dead){ G.win = false; G.wait = 2.5; sfx('alarm'); }
  }
}
export function missionUpdate(dt){
  casUpdate(dt);
  wingUpdate(dt);
  const G = W.G, ms = G.ms; if(!ms) return;
  if(G.dead && !ms.deadSent){ ms.deadSent = true; pushEvent(ms, {type:'playerDead'}); }
  const snap = makeSnap(); G.snap = snap;
  for(const o of stepRuntime(ms, dt, snap)) onOutput(o);
  ST.markT -= dt; if(ST.markT <= 0){ ST.markT = .25; updateMarks(ms, snap); }
}
