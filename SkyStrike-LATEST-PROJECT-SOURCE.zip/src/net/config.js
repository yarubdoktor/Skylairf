/* عنوان السيرفر (D1): للإنتاج wss:// فقط (WebView أندرويد يمنع ws://)، وws://localhost للتطوير بالمتصفح فقط. */
export const WS_URL = (import.meta.env && import.meta.env.VITE_WS_URL) || 'ws://localhost:2567';
