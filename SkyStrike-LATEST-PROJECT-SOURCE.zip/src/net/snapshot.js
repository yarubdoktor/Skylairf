/* لقطات الحالة (صرف: بلا DOM ولا three). الطيار البعيد يُعرض متأخراً INTERP_DELAY_MS بين أقرب لقطتين
   (طابع الوصول المحلي)، والزاوية بأقصر قوس، والاستقراء عند التأخّر أقصاه EXTRAP_MS ثم تثبيت. */
const EXTRAP_MS = 250, KEEP_MS = 2000, KEEP_N = 64;
const r1 = v => Math.round(v * 10) / 10, r3 = v => Math.round(v * 1000) / 1000;
const bit = v => v ? 1 : 0;
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

/* pose = {x,y,z,yw,pt,rl,sp,hp,b,g} بقيم خام ← حقول st بالتقريب المحدّد بالقسم 6 */
export function packState(p){
  return {x: r1(p.x), y: r1(p.y), z: r1(p.z), yw: r3(p.yw), pt: r3(p.pt), rl: r3(p.rl),
    sp: r1(p.sp), hp: Math.max(0, Math.round(p.hp)), b: bit(p.b), g: bit(p.g)};
}

export const createBuffer = () => ({s: []});

/* snap = حقول st (x,y,z,yw,pt,rl,sp,hp,b,g)، nowMs = طابع الوصول المحلي */
export function pushSnap(buf, snap, nowMs){
  const s = buf.s;
  s.push({t: nowMs, x: snap.x, y: snap.y, z: snap.z, yw: snap.yw, pt: snap.pt, rl: snap.rl,
    sp: snap.sp, hp: snap.hp, b: snap.b, g: snap.g});
  while(s.length > KEEP_N || (s.length > 2 && nowMs - s[0].t > KEEP_MS)) s.shift();
}

const pick = (a, o) => ({x: o.x, y: o.y, z: o.z, yw: o.yw, pt: o.pt, rl: o.rl, sp: a.sp, hp: a.hp, b: a.b, g: a.g});

/* ← حالة العرض عند (nowMs - delayMs) أو null إن لم تصل لقطة بعد */
export function sampleBuffer(buf, nowMs, delayMs){
  const s = buf.s, n = s.length; if(!n) return null;
  const tt = nowMs - delayMs, last = s[n - 1];
  if(n === 1 || tt <= s[0].t) return pick(s[0], s[0]);
  if(tt >= last.t){                                          // تأخّر الوصول: استقراء محدود ثم تثبيت
    const p = s[n - 2], span = last.t - p.t, e = Math.min(tt - last.t, EXTRAP_MS);
    if(span <= 0 || e <= 0) return pick(last, last);
    const k = e / span;
    return pick(last, {x: last.x + (last.x - p.x) * k, y: last.y + (last.y - p.y) * k, z: last.z + (last.z - p.z) * k,
      yw: last.yw, pt: last.pt, rl: last.rl});
  }
  let i = 0; while(i < n - 2 && s[i + 1].t <= tt) i++;       // s[i].t <= tt < s[i+1].t
  const a = s[i], b = s[i + 1], span = b.t - a.t, f = span > 0 ? (tt - a.t) / span : 1;
  const L = (u, v) => u + (v - u) * f, A = (u, v) => u + wrap(v - u) * f;
  return pick(a, {x: L(a.x, b.x), y: L(a.y, b.y), z: L(a.z, b.z),
    yw: A(a.yw, b.yw), pt: A(a.pt, b.pt), rl: A(a.rl, b.rl)});
}
