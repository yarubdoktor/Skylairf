/* عميل الشبكة: WebSocket خام (D1). createNetClient({url, WebSocketImpl}) ← {connect, send, on, close}.
   on(type, fn): نوع رسالة السيرفر (t)، أو '*' لكل الرسائل، أو 'close' عند إغلاق الاتصال. */
import {encode, decode} from '../../shared/protocol.js';

const TIMEOUT_MS = 8000;

export function createNetClient({url, WebSocketImpl = globalThis.WebSocket} = {}){
  let ws = null; const hs = {};
  const emit = (type, m) => { for(const f of (hs[type] || [])) f(m); };
  return {
    /* Promise: يُحلّ عند الفتح، ويُرفض عند الفشل أو بعد 8ث */
    connect(){
      return new Promise((res, rej) => {
        let done = false;
        const fail = e => { if(done) return; done = true; clearTimeout(h); try{ ws && ws.close(); }catch(x){} rej(e); };
        const h = setTimeout(() => fail(new Error('timeout')), TIMEOUT_MS);
        try{ ws = new WebSocketImpl(url); }catch(e){ fail(e); return; }
        ws.onopen = () => { if(done) return; done = true; clearTimeout(h); res(); };
        ws.onerror = () => fail(new Error('connect'));
        ws.onclose = () => { if(!done) fail(new Error('closed')); else emit('close', {t: 'close'}); };
        ws.onmessage = ev => {
          const r = decode(typeof ev.data === 'string' ? ev.data : '');
          if(!r.ok) return; emit(r.msg.t, r.msg); emit('*', r.msg);
        };
      });
    },
    send(msg){ if(!ws || ws.readyState !== 1) return false; ws.send(encode(msg)); return true; },
    on(type, fn){ (hs[type] || (hs[type] = [])).push(fn); },
    close(){ if(ws){ try{ ws.close(); }catch(e){} } }};
}
