/* صور الواجهة الاحترافية (اختيارية بالكامل).
   ضع الصورة بالمجلد بالاسم المطلوب وتظهر تلقائياً بعد البناء؛ لو الصورة غير موجودة تبقى الواجهة القديمة (معاينة المحرك / إيموجي / بدون صورة).
   المقاسات والأسماء بالتفصيل: brand/ART_SPEC.md  ،  والفحص: python3 tools/check_art.py
     src/assets/planes/<id>.webp            mig29 · su57                  (اللون الافتراضي؛ f35.webp قديمة ومحفوظة بلا استعمال)
     src/assets/planes/<id>_<skin>.webp     مثال: mig29_crimson.webp         (اختياري لكل لون)
     src/assets/weapons/<key>.webp          gun · msl · multi · bomb
   بدون أي استيراد من three → آمن للاختبار. glob يقرأ الموجود فقط (مجلد فاضي = {}). */
const keyed = g => { const o = {}; for(const p in g) o[p.split('/').pop().replace(/\.\w+$/,'')] = g[p]; return o; };
export const ART = {
  planes:   keyed(import.meta.glob('./assets/planes/*.{webp,png,jpg}',   {eager:true, query:'?url', import:'default'})),
  weapons:  keyed(import.meta.glob('./assets/weapons/*.{webp,png,jpg}',  {eager:true, query:'?url', import:'default'})),
  campaign: keyed(import.meta.glob('./assets/campaign/*.{webp,png,jpg}', {eager:true, query:'?url', import:'default'})),
  ui:       keyed(import.meta.glob('./assets/ui/*.{webp,png,jpg}',       {eager:true, query:'?url', import:'default'}))    // avatar · rank_r1 … rank_r5
};
// صورة الطائرة: صورة اللون الخاص إن وُجدت، وإلا صورة الافتراضي (فقط لو اللون الحالي افتراضي)، وإلا '' (فيرجع لمعاينة المحرك اللي تُظهر اللون)
export const planeArt = (id,skin) => ART.planes[id+'_'+skin] || (skin === 'gray' ? ART.planes[id] : '') || '';
