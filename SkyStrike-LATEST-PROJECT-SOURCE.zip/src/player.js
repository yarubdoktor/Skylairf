/* اللاعب: التحكم بالطيران، القفل، الأسلحة، الكاميرا. الحالة نفسها (P) بـ state.js. */
import {clamp,wrap,rnd,VH} from './util.js';
import {S} from './save.js';
import {PLANES,gunDmg,mslDmg,mulDmg,bombDmg,bvrDmg,agmDmg,armDmg} from './data.js';
import {Q} from './quality.js';
import {WT} from './jets.js';
import {t} from './i18n.js';
import {sfx,setEngine} from './audio.js';
import {requestCAS} from './mission/mission_bridge.js';
import {cam,world,fx,renderer,V,dirOfTo} from './core.js';
import {W,P,shadow,FW} from './state.js';
import {inp} from './input.js';
import {el,banner} from './ui.js';
import {shoot,die} from './combat.js';
import {stepPro,FM} from './flight.js';
import {isHostile,sideOf,colorOf} from './mission/factions.js';

const _a = V(), _b = V(), _c = V();
export const cp = V(0,170,930);          // موضع الكاميرا المُلاحق (يُعاد ضبطه بـ startGame)
// زاوية الكاميرا (S.cam): [المسافة خلف الطائرة، الارتفاع] — 0 قريبة (الافتراضي) ، 1 متوسطة ، 2 بعيدة (القديمة)
const CAMS = [[10.6,5.0],[15.4,6.0],[20.8,7.3]];   // v25.2: أقرب (القريبة كانت 16.5 وصارت 11.5)
export const camCfg = () => CAMS[S.cam] || CAMS[0];
const LOCK_T = .55;                      // M13+: قفل أسرع
const LOCK_T_GND = .28;                  // قفل أرضي أسرع بكثير
const LOCK_CONE = .72;                   // مخروط أوسع (كان ~0.8)
const LOCK_CONE_GND = .42;               // أوسع جداً للأرض

/* النمط «كلاسيك» (S.fm = 0): نموذج v25.2 القديم بالضبط */
function flyClassic(dt,boosting){
  const dz = v => Math.abs(v)<.12 ? 0 : (v-Math.sign(v)*.12)/.88, tx = dz(inp.x), ty = dz(inp.y);
  P.sx += (tx*Math.abs(tx)*.35+tx*.65-P.sx)*Math.min(1,dt*5); P.sy += (ty*Math.abs(ty)*.35+ty*.65-P.sy)*Math.min(1,dt*5);
  // M13+: استجابة أنعم + مساعدة استقرار عند السرعة العالية
  const soft = S.assist ? 0.85 : 1.0;
  const rate = P.turn*.65*S.sens*soft*(boosting ? P.tv : 1);
  P.yaw -= P.sx*rate*dt; P.pitch = clamp(P.pitch-(S.invY ? -P.sy : P.sy)*rate*.62*dt,-1,1);
  // استقرار تلقائي أقوى عند ترك العصا (يسهّل التصويب على الأرض)
  if(Math.abs(P.sy) < .08) P.pitch *= 1-Math.min(1,dt*(S.assist ? 1.2 : .7));
  if(Math.abs(P.sx) < .08) P.roll *= 1-Math.min(1,dt*(S.assist ? .9 : .5));
  P.roll += (-P.sx-P.roll)*Math.min(1,dt*4);
}

export function playerUpdate(dt){
  const G = W.G, enemies = W.units, flares = W.flares, pos = P.g.position, fw = FW;
  const boosting = inp.boost && P.en > .05;
  if(S.fm) stepPro(P,inp,{sens:S.sens,invY:S.invY},dt,boosting); else flyClassic(dt,boosting);
  // مساعد تفادي الأرض
  const gh = world.ground(pos.x,pos.z), alt = pos.y-gh, vy = Math.sin(P.pitch)*P.cur, thr = 45+Math.max(0,-vy);
  G.pull = false;
  if(S.assist && alt < thr && P.pitch < .45){ P.pitch += (.45-P.pitch)*clamp(1-alt/thr,0,1)*dt*4.2; G.pull = vy < -4 || alt < 40; }
  P.g.rotation.set(P.pitch,P.yaw,P.roll); dirOfTo(P.g,fw);
  P.en = clamp(P.en+(boosting?-P.dr:P.rc)*dt,0,1);
  const ef = S.fm ? clamp(1-.22*Math.sin(P.pitch),.8,1.2) : 1;      // الطاقة: الصعود يبطّئ والغطس يسرّع (احترافي فقط)
  P.cur += ((boosting?P.speed*P.bm:P.speed)*ef-P.cur)*Math.min(1,dt*1.8); P.bk = clamp((P.cur/P.speed/ef-1)/(P.bm-1),0,1);
  pos.addScaledVector(fw,P.cur*dt); pos.y = Math.min(pos.y,world.cfg.ceil || 520);
  if(pos.y < world.ground(pos.x,pos.z)+2.5){ die(); return; }
  if(world.cfg.hit && world.cfg.hit(pos.x,pos.y,pos.z)){ die(); return; }
  const lim = W.mp ? W.mp.limit : world.cfg.limit;           // حدود الخريطة: تحذير + دوران إجباري نحو المركز
  G.outT = (G.outT || 0)-dt;
  if(lim && Math.max(Math.abs(pos.x),Math.abs(pos.z)) > lim){
    if(G.outT <= 0){ banner(t('outMap'), 'warn'); sfx('alarm'); G.outT = 2; }
    P.yaw += clamp(wrap(Math.atan2(pos.x,pos.z)-P.yaw),-1.3*dt,1.3*dt);
  }
  world.stream(pos,false);
  // ظل الطائرة
  const al2 = pos.y-world.ground(pos.x,pos.z); shadow.visible = true; shadow.position.set(pos.x,pos.y-al2+.7,pos.z);
  const ss = 14+al2*.03; shadow.scale.set(ss,1,ss); shadow.material.opacity = .38*(1-clamp(al2/420,0,1));
  // القفل
  // M13+: قفل أسهل — أولوية أرضية عند النظر للأسفل + مخروط أوسع + مساعدة توجيه
  let lock = null, best = -1;
  const lookDown = P.pitch < -0.12;
  for(const e of enemies){ if(!isHostile('player',sideOf(e))) continue;
    _a.copy(e.g.position).sub(pos); const d = _a.length(); if(d < 1800 && d > 1){
      const nd = fw.dot(_a)/d;
      const isGnd = !!(e.ground || e.kind==='depot' || e.kind==='sam' || e.kind==='flak' || e.kind==='tank' || e.kind==='apc' || e.kind==='truck' || e.kind==='turret');
      const cone = isGnd ? LOCK_CONE_GND : LOCK_CONE;
      if(nd < cone) continue;
      let score = nd + (e === W.candE ? .06 : 0);
      if(isGnd && lookDown) score += .18;           // أولوية أهداف أرضية عند الغطس
      if(isGnd) score += .05;
      if(score > best){ best = score; lock = e; W.lockDist = d; }
    } }
  if(lock !== W.candE){ W.candE = lock; W.lockT = 0; } else if(lock) W.lockT += dt;
  const needT = (lock && (lock.ground || lock.kind==='depot' || lock.kind==='sam' || lock.kind==='flak' || lock.kind==='tank' || lock.kind==='apc' || lock.kind==='truck' || lock.kind==='turret')) ? LOCK_T_GND : LOCK_T;
  const full = !!lock && W.lockT >= needT;
  el.lk.style.opacity = lock ? 1 : 0; el.lk.textContent = full ? t('lock') : t('locking');
  if(full && lock !== W.lockE) sfx('lock'); W.lockE = full ? lock : null;
  // مساعدة توجيه ناعمة نحو الهدف المقفل (لا تلغي تحكم اللاعب)
  if(S.assist && lock && W.lockT > 0.05){
    _a.copy(lock.g.position).sub(pos).normalize();
    // الأمام = (-sin yaw, -cos yaw) بترتيب YXZ، فاتجاه الهدف = atan2(-x,-z) (كان atan2(x,z) = معكوس 180° ويدفع الطائرة بعيداً عن العدو)
    const dy = wrap(Math.atan2(-_a.x, -_a.z) - P.yaw);
    const pitWant = Math.asin(clamp(_a.y, -0.95, 0.95));
    const pitErr = pitWant - P.pitch;
    // كلما حرّك اللاعب العصا ضعفت المساعدة، فيقدر دائماً يتجاوزها ويلفّ عن الهدف
    const k = (full ? 1.6 : 0.9) * dt * (1 - .8*Math.min(1, Math.hypot(P.sx, P.sy)));
    P.yaw += clamp(dy, -0.9, 0.9) * k * 0.55;
    P.pitch = clamp(P.pitch + clamp(pitErr, -0.7, 0.7) * k * 0.45, -1, 1);
  }
  // الأسلحة
  P.gcd -= dt;
  if(inp.fire && P.gcd <= 0){ P.gcd = .09; sfx('gun'); _a.set(1,0,0).applyEuler(P.g.rotation);
    for(const s of [-1,1]){ _b.copy(pos).addScaledVector(_a,s*2.2).addScaledVector(fw,6); shoot({owner:'p',pos:_b,dir:fw,speed:750,dmg:gunDmg()}); } }
  // M11: حسب العتاد المختار (S.load.aa) + قفل بعيد لـ BVR
  if(inp.msl && !inp.msP){
    const preferBvr = (S.load && S.load.aa === 'bvr') || ((W.lockDist||0) > 480);
    if(preferBvr && P.bvr > 0){
      P.bvr--; sfx('msl'); _b.copy(pos).addScaledVector(fw,6); _b.y -= 1.5;
      shoot({owner:'p',pos:_b,dir:fw,speed:520,dmg:bvrDmg(),mis:true,target:W.lockE,turn:1.8,life:10,bvr:true});
    } else if(P.msl > 0 && (!W.mp || W.lockE)){      // بالماتش: لا صاروخ بلا قفل كامل
      P.msl--; sfx('msl'); _b.copy(pos).addScaledVector(fw,6); _b.y -= 1.5;
      shoot({owner:'p',pos:_b,dir:fw,speed:480,dmg:mslDmg(),mis:true,target:W.lockE,turn:2.8,life:6});
    }
  }
  inp.msP = inp.msl;
  if(inp.mul && !inp.mulP && P.mul > 0 && S.multi > 0){ P.mul--; sfx('msl'); _a.set(1,0,0).applyEuler(P.g.rotation);
    const cs = enemies.filter(e => isHostile('player',sideOf(e))).map(e => { const to = e.g.position.clone().sub(pos), dd = to.length(); return {e,dd,dt:fw.dot(to.normalize())}; }).filter(c => c.dt > .6 && c.dd < 1600).sort((a,b) => b.dt-a.dt).slice(0,3);
    for(let i=0;i<3;i++){ const tg = cs[i] ? cs[i].e : (cs[0] ? cs[0].e : null);
      _b.copy(pos).addScaledVector(fw,6).addScaledVector(_a,(i-1)*2); _b.y -= 1.5; _c.copy(fw).addScaledVector(_a,(i-1)*.14);
      shoot({owner:'p',pos:_b,dir:_c,speed:440,dmg:mulDmg(),mis:true,target:tg}); } }
  inp.mulP = inp.mul;
  // M11/M13+: BMB حسب العتاد · مع مساعدة: أقرب هدف أرضي أمامك إن لم يُقفل
  if(inp.bmb && !inp.bmbP){
    let tgt = W.lockE;
    if(!tgt && S.assist){
      let bd = 900, best = null;
      for(const e of enemies){ if(!isHostile('player',sideOf(e))) continue;
        const isG = !!(e.ground || e.kind==='depot' || e.kind==='sam' || e.kind==='flak' || e.kind==='tank' || e.kind==='apc' || e.kind==='truck');
        if(!isG) continue;
        _a.copy(e.g.position).sub(pos); const d = _a.length(); if(d < bd && d > 20 && fw.dot(_a)/d > .35){ bd = d; best = e; }
      }
      tgt = best;
    }
    const groundT = tgt && (tgt.ground || tgt.kind === 'depot' || tgt.kind === 'sam' || tgt.kind === 'flak');
    const isRadar = tgt && (tgt.kind === 'sam' || (tgt.kind === 'depot' && (tgt.tt===1 || tgt.tt===3)));
    const prefer = (S.load && S.load.ag) || 'bomb';
    if((prefer==='arm' || isRadar) && P.arm > 0 && (S.arm|0) > 0){
      P.arm--; sfx('msl'); _b.copy(pos).addScaledVector(fw,4); _b.y -= 1.5;
      shoot({owner:'p',pos:_b,dir:fw,speed:420,dmg:armDmg(),mis:true,target:tgt,turn:2.2,life:9,arm:true});
    } else if((prefer==='agm' || groundT) && P.agm > 0 && (S.agm|0) > 0){
      P.agm--; sfx('msl'); _b.copy(pos).addScaledVector(fw,4); _b.y -= 1.5;
      shoot({owner:'p',pos:_b,dir:fw,speed:400,dmg:agmDmg(),mis:true,target:tgt,turn:2.0,life:8,agm:true});
    } else if(P.bmb > 0 && S.bomb > 0){
      P.bmb--; sfx('bomb'); _b.copy(pos); _b.y -= 2;
      shoot({owner:'p',pos:_b,dir:fw,speed:P.cur*.9,dmg:bombDmg(),bomb:true});
    }
  }
  inp.bmbP = inp.bmb;
  if(inp.flr && !inp.flrP && P.flr > 0){ P.flr--; sfx('flare');
    for(let i=0;i<3;i++){ const f = {p:pos.clone().addScaledVector(fw,-6),v:V(rnd(-20,20),rnd(-12,4),rnd(-20,20)).addScaledVector(fw,P.cur*.35),life:3.6}; flares.push(f); }
    { const b = pos.clone().addScaledVector(fw,-6); fx.glow(b.x,b.y,b.z,0xffffff,12,3,.16,0,0,0,1);                       // وميض إطلاق المشاعل + شرر
      for(let i=0;i<8;i++) fx.glow(b.x,b.y,b.z,0xffd080,1.6,.3,rnd(.3,.7),rnd(-1,1)*45,rnd(-1,1)*35,rnd(-1,1)*45,1,60); } }
  inp.flrP = inp.flr;
  if(inp.cas && !inp.casP) requestCAS();
  inp.casP = inp.cas;
  if(P.bk > .35 && (P.bkP || 0) <= .35){                          // كسر حاجز الصوت: حلقتا بخار تتمددان حول الطائرة + وميض
    const rt = V(1,0,0).applyEuler(P.g.rotation), up = V(0,1,0).applyEuler(P.g.rotation), c0 = pos.clone().addScaledVector(fw,7);
    fx.glow(c0.x,c0.y,c0.z,0xdff0ff,9,2,.16,0,0,0,.9); W.shake = Math.max(W.shake,.5);
    const ring = (R,sp,dl) => fx.later(dl,() => { for(let i=0;i<26;i++){ const a = i/26*Math.PI*2, ca = Math.cos(a), sa = Math.sin(a), cc = pos.clone().addScaledVector(fw,7);
      const dx = rt.x*ca+up.x*sa, dy = rt.y*ca+up.y*sa, dz = rt.z*ca+up.z*sa;
      fx.smk(cc.x+dx*R,cc.y+dy*R,cc.z+dz*R,0xf4f8ff,2.4,7,.85,dx*sp,dy*sp,dz*sp,.55); } });
    ring(4.5,60,0); ring(7,85,.07);
  }
  P.bkP = P.bk;
  for(const f of P.g.userData.fl){ f.scale.z = .6+P.bk*1.4+Math.random()*.25; f.scale.x = f.scale.y = .8+P.bk*.3; }
  if(P.bk > .3 && Math.random() < dt*30){ _a.set(2.2,0,6).applyEuler(P.g.rotation); fx.smk(pos.x+_a.x,pos.y+_a.y,pos.z+_a.z,0xffffff,1.2,5,.9,0,0,0,.25);
    _a.set(-2.2,0,6).applyEuler(P.g.rotation); fx.smk(pos.x+_a.x,pos.y+_a.y,pos.z+_a.z,0xffffff,1.2,5,.9,0,0,0,.25); }
  if(Q.fx >= 260 && ((S.fm ? P.gl > 4.2 : Math.abs(P.sx) > .5) || P.bk > .5) && Math.random() < dt*45){     // خطوط بخار من أطراف الأجنحة
    const w = WT[PLANES[S.sel].kind]; for(const s of [-1,1]){ _a.set(s*w.x,w.y,w.z).applyEuler(P.g.rotation); fx.smk(pos.x+_a.x,pos.y+_a.y,pos.z+_a.z,0xffffff,.8,3.2,.7,0,0,0,.3); } }
  // أضرار الطائرة: دخان يزداد سواداً كلما قلّت الصحة ← نار وشرر تحت 30٪ + اهتزاز وطقطقة
  if(!G.dead && P.hp < P.maxhp*.7){
    const hf = clamp(P.hp/P.maxhp,0,1), sev = clamp((.7-hf)/.7,0,1);
    P.dmT = (P.dmT || 0)-dt;
    if(P.dmT <= 0){ P.dmT = .07-sev*.04;
      _a.set(rnd(-.7,.7),.3,5.5).applyEuler(P.g.rotation);
      fx.smk(pos.x+_a.x,pos.y+_a.y,pos.z+_a.z,sev > .55 ? 0x0c0c0c : (sev > .25 ? 0x2e2e2e : 0x808080),1.6,6+sev*9,1.4+sev*1.4,0,3,0,.7); }
    if(hf < .3){
      _a.set(rnd(-.8,.8),.1,5.8).applyEuler(P.g.rotation);
      fx.glow(pos.x+_a.x,pos.y+_a.y,pos.z+_a.z,Math.random() < .5 ? 0xff4a10 : 0xffa030,3.2+Math.random()*2,.8,.22,0,0,0,.9);
      if(Math.random() < dt*7) fx.glow(pos.x+_a.x,pos.y+_a.y,pos.z+_a.z,0xffe080,1.4,.3,rnd(.3,.7),rnd(-1,1)*30,rnd(0,1)*25,rnd(-1,1)*30,1,80);
      W.shake = Math.max(W.shake,.1*(1-hf/.3));
      P.dsT = (P.dsT || 0)-dt; if(P.dsT <= 0){ P.dsT = 1.1+Math.random()*.8; sfx('dmg'); } }
  }
  setEngine(P.cur/P.speed,P.bk);
  if(P.hp < P.maxhp*.3 && G.t%1 < dt) sfx('warn');
}

export function cameraUpdate(dt){
  const G = W.G, pos = P.g.position;
  if(!G.dead){ const [cd,ch] = camCfg(); _a.set(S.fm ? P.roll*1.1 : 0,ch,0).applyEuler(P.g.rotation); _b.copy(pos).addScaledVector(FW,-(cd+P.bk*3)).add(_a); cp.lerp(_b,Math.min(1,dt*(S.fm ? 4.5 : 5))); }
  cam.position.copy(cp); _a.copy(pos).addScaledVector(FW,40); cam.lookAt(_a); cam.rotateZ(P.roll*(S.fm ? .5 : .35));
  if(S.fm && P.gl > 5.5) W.shake = Math.max(W.shake,(P.gl-5.5)*.05);        // اهتزاز خفيف تحت G عالي
  W.shake *= Math.max(0,1-dt*4); if(W.shake > .02) cam.position.add(_c.set(rnd(-1,1),rnd(-1,1),rnd(-1,1)).multiplyScalar(W.shake*1.2));
  const fv = 65+P.bk*14+(S.fm ? clamp((P.cur/P.speed-1)*10,-3,6) : 0); if(Math.abs(cam.fov-fv) > .1){ cam.fov += (fv-cam.fov)*Math.min(1,dt*4); cam.updateProjectionMatrix(); fx.setScale(VH()*renderer.getPixelRatio(),cam.fov); }
}
