/* مشهد استوديو معاينة الطائرة (بند #3): إضاءة ثلاثية + أرضية لامعة تعكس الطائرة + ظل تلامس + شعاع ضوء + غبار.
   مشهد مستقل عن مشهد اللعبة (لا يلمس العالم). الانعكاس: نسخة مقلوبة تحت أرضية شبه شفافة (يُعطَّل بجودة lite/low). */
import * as THREE from 'three';
import {world} from './core.js';
import {softTex} from './fx.js';
import {Q} from './quality.js';

export const FLOOR_Y = -5.5;
const BG = 0x070d18;
const radial = (inner, outer) => {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const x = c.getContext('2d'),
    g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, inner);
  g.addColorStop(1, outer);
  x.fillStyle = g;
  x.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
};

export function buildStage() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(BG);
  scene.fog = new THREE.Fog(BG, 45, 110);
  if (world.envTex) scene.environment = world.envTex;
  scene.add(new THREE.HemisphereLight(0xbcd6ff, 0x1a1c24, 1.3));
  const key = new THREE.DirectionalLight(0xffc48a, 3.4),
    rim = new THREE.DirectionalLight(0x6fb4ff, 3.2),
    top = new THREE.SpotLight(0xdfeaff, 1100, 70, 0.55, 0.8, 2);
  key.position.set(12, 14, 9);
  rim.position.set(-14, 6, -12);
  top.position.set(0, 30, 0);
  scene.add(key, rim, top, top.target);

  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(34, 64).rotateX(-Math.PI / 2),
    new THREE.MeshStandardMaterial({
      color: 0x0c131e,
      metalness: 0.85,
      roughness: 0.3,
      transparent: true,
      opacity: 0.86,
      envMapIntensity: 0.7
    })
  );
  floor.position.y = FLOOR_Y;
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0x9fd8ff,
    transparent: true,
    opacity: 0.55,
    blending: THREE.AdditiveBlending,
    depthWrite: false
  });
  const ring = new THREE.Mesh(new THREE.RingGeometry(13.6, 13.85, 96).rotateX(-Math.PI / 2), ringMat),
    ring2 = new THREE.Mesh(new THREE.RingGeometry(18, 18.08, 96).rotateX(-Math.PI / 2), ringMat.clone());
  ring.position.y = ring2.position.y = FLOOR_Y + 0.02;
  ring2.material.opacity = 0.22;
  const shadow = new THREE.Mesh(
    new THREE.PlaneGeometry(26, 26).rotateX(-Math.PI / 2),
    new THREE.MeshBasicMaterial({
      map: radial('rgba(0,0,0,.85)', 'rgba(0,0,0,0)'),
      transparent: true,
      depthWrite: false
    })
  );
  shadow.position.y = FLOOR_Y + 0.04;
  const shaft = new THREE.Mesh(
    new THREE.ConeGeometry(10, 36, 32, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0x9fc4ff,
      transparent: true,
      opacity: 0.06,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    })
  );
  shaft.position.y = FLOOR_Y + 18;
  const halo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: softTex,
      color: 0x2c5a98,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false
    })
  );
  halo.scale.setScalar(150);
  scene.add(floor, ring, ring2, shadow, shaft, halo);

  const N = Q.name === 'lite' ? 36 : 80,
    pos = new Float32Array(N * 3),
    seed = new Float32Array(N);
  for (let i = 0; i < N; i++) {
    const a = Math.random() * 6.283,
      r = 4 + Math.random() * 14;
    pos.set([Math.cos(a) * r, FLOOR_Y + Math.random() * 22, Math.sin(a) * r], i * 3);
    seed[i] = Math.random() * 6.283;
  }
  const dg = new THREE.BufferGeometry();
  dg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  scene.add(
    new THREE.Points(
      dg,
      new THREE.PointsMaterial({
        map: softTex,
        size: 0.45,
        color: 0xbcd6ff,
        transparent: true,
        opacity: 0.45,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      })
    )
  );

  const mirrorOn = Q.name !== 'lite' && Q.name !== 'low';
  let jet = null,
    mir = null,
    t = 0;
  return {
    scene,
    setJet(j) {
      if (jet) scene.remove(jet);
      if (mir) scene.remove(mir);
      jet = j;
      mir = null;
      scene.add(j);
      if (mirrorOn) {
        mir = j.clone(true);
        mir.scale.y = -1;
        scene.add(mir);
      }
    },
    update(dt, cp) {
      t += dt;
      const bob = Math.sin(t * 0.9) * 0.1;
      if (jet) jet.position.y = bob;
      if (mir) mir.position.y = 2 * FLOOR_Y - bob;
      const L = Math.hypot(cp.x, cp.y, cp.z) || 1;
      halo.position.set((-cp.x / L) * 60, (-cp.y / L) * 60 + 6, (-cp.z / L) * 60); // دائماً خلف الطائرة
      ring.material.opacity = 0.45 + Math.sin(t * 1.6) * 0.12;
      const p = dg.attributes.position;
      for (let i = 0; i < N; i++) {
        let y = p.getY(i) + dt * (0.35 + 0.2 * Math.sin(seed[i] + t));
        if (y > FLOOR_Y + 22) y = FLOOR_Y;
        p.setY(i, y);
        p.setX(i, p.getX(i) + Math.sin(t * 0.5 + seed[i]) * dt * 0.25);
      }
      p.needsUpdate = true;
    }
  };
}
