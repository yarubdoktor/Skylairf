/* شاشة المنيو الداخلية: الحملة (v26.2.24، بند #18 — نُقلت حرفياً من menu.js). */
import {S} from '../save.js';
import {CAMPAIGN} from '../campaign.js';
import {t} from '../i18n.js';
import {ART} from '../art.js';
import {plain} from './common.js';

export const campaignSheet = () =>
  `<button class="pill tx" data-a="scr" data-i="enemies">${t('enemiesBtn')}</button> <div class="chip tx">${t('campProg', {a: Math.min(S.cp | 0, CAMPAIGN.length), b: CAMPAIGN.length})}</div><div class="grid g2">${CAMPAIGN.map(
    (c, i) => {
      const open = i <= (S.cp | 0),
        done = i < (S.cp | 0);
      const im = ART.campaign[c.id];
      return `<div class="card ms ${im ? 'hasimg' : ''} ${open ? '' : 'lk'}">${im ? `<div class="cim"><img src="${im}" alt=""></div>` : ''}<div class="grow"><b class="tx">${i + 1}. ${t(c.id + 't')} ${done ? '✅' : ''}</b><small class="tx">${t(c.id + 'd')}</small><small class="tx">${plain(t('map_' + c.map))} · ${plain(t(c.op ? 'opn_' + c.op : 'mode_' + c.mode))} · ${t('reward')} ${c.c}🪙${c.g ? ' +' + c.g + '💎' : ''}</small></div><button data-a="camp" data-i="${i}" ${open ? '' : 'disabled'}>${open ? (done ? t('campAgain') : t('campPlay')) : '🔒'}</button></div>`;
    }
  ).join('')}</div>`;
