/* شاشة المنيو الداخلية: الأسلحة + المهام اليومية (v26.2.24، بند #18 — نُقلت حرفياً من menu.js). */
import {S} from '../save.js';
import {MAXL, wCost, WPN, weekDaysLeft, loginInfo} from '../data.js';
import {t} from '../i18n.js';
import {ART} from '../art.js';
import {wd} from './common.js';

export const weaponsSheet = () =>
  `<div class="grid g2">${Object.entries(WPN)
    .map(([k, w]) => {
      const lv = S[k],
        cost = lv ? wCost(lv) : w.price;
      const im = ART.weapons[k];
      return `<div class="card wc ${im ? 'hasimg' : ''} ${lv ? '' : 'lk'}">${im ? `<div class="wim"><img src="${im}" alt=""></div>` : ''}<div><b class="tx">${im ? '' : w.ic + ' '}${t('w_' + k)}</b> <em>${lv ? t('lvl') + ' ' + lv : t('locked')}</em><small class="tx">${wd[k](lv || 1)}</small></div><button data-a="upw" data-i="${k}" ${lv >= MAXL || S.coins < cost ? 'disabled' : ''}>${lv ? (lv >= MAXL ? t('max') : t('upg') + ' ' + cost + '🪙') : t('buy') + ' ' + cost + '🪙'}</button></div>`;
    })
    .join('')}</div>`;

export const missionsSheet = () => {
  const lg = loginInfo(),
    wl = S.wk.l;
  const row = (x, i, act) => {
    const pr = Math.min(x.p, x.n);
    return `<div class="card"><div class="grow"><b class="tx">${t('m_' + x.k, {n: x.n})}</b><small>${pr} / ${x.n} · ${t('reward')} ${x.r}🪙${x.g ? ' +' + x.g + '💎' : ''}</small><i class="sb"><b style="width:${(pr / x.n) * 100}%"></b></i></div><button data-a="${act}" data-i="${i}" ${x.c || x.p < x.n ? 'disabled' : ''}>${x.c ? t('done') : t('claim')}</button></div>`;
  };
  return `<div class="grid g2"><div class="card"><div class="grow"><b class="tx">${t('loginT')}</b><small class="tx">${t('loginS', {d: lg.day, c: lg.coins, g: lg.gems ? ' +' + lg.gems + '💎' : ''})}</small></div><button data-a="login" ${lg.can ? '' : 'disabled'}>${lg.can ? t('claim') : t('done')}</button></div></div>
  <div class="sec tx">${t('dailyT')}</div><div class="grid g2">${S.mis.l.map((x, i) => row(x, i, 'clm')).join('')}</div>
  <div class="sec tx">${t('wkT')} <small>· ${t('wkReset', {d: weekDaysLeft()})}</small></div><div class="grid g2">${wl.map((x, i) => row(x, i, 'clmw')).join('')}
  <div class="card info"><div><b class="tx">${t('earnT')}</b><small class="dr">${t('earnB')}</small></div></div></div>`;
};
