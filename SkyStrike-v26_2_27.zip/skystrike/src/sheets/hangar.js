/* شاشة المنيو الداخلية: الهنجر + الألوان/السكنات (v26.2.24، بند #18 — نُقلت حرفياً من menu.js). */
import {S} from '../save.js';
import {PLANES, stats, MAXL, upCost, SKINS, skinOf, skinOwned} from '../data.js';
import {t} from '../i18n.js';
import {bar, pimg} from './common.js';

export const hangarSheet = PREV =>
  `<div class="grid g1">${Object.entries(PLANES)
    .map(([id, p]) => {
      const lv = S.pl[id],
        st = lv ? stats(id) : {speed: p.speed, turn: p.turn, hp: p.hp};
      return (
        `<div class="pc ${S.sel === id ? 'sel' : ''}"><div class="im ${lv ? '' : 'lk'}"><img src="${pimg(PREV, id)}" alt=""><span>🔒</span></div><div class="pb"><div class="inf"><b class="tx">${p.n}</b>${lv ? `<em>${t('lvl')} ${lv}</em>` : ''}<p class="tx">${t('d_' + id)}</p><p class="tx hint">⚡ ${t('ab_' + id)}</p>
  <div class="st">${[
    ['SPD', st.speed, 280],
    ['TURN', st.turn, 2.3],
    ['HP', st.hp, 300]
  ]
    .map(([k, v, m]) => `<span>${k}</span>${bar(v, m)}<em>${Math.round(v * (k === 'TURN' ? 10 : 1))}</em>`)
    .join('')}</div>
  <p class="tx hint">${lv ? (S.sel === id ? t('usedNow') : t('tapUse')) : t('unlockHow', {p: p.price})}</p></div>
  <div class="acts">` +
        (lv
          ? `<button data-a="sel" data-i="${id}" ${S.sel === id ? 'disabled' : ''}>${t('use')}</button><button data-a="upl" data-i="${id}" class="alt" ${lv >= MAXL || S.coins < upCost(lv, id) ? 'disabled' : ''}>${t('upg')} ${lv >= MAXL ? t('max') : upCost(lv, id) + '🪙'}</button><button data-a="skn" data-i="${id}" class="alt" aria-label="${t('skinsT')}">🎨</button>`
          : `<button data-a="buy" data-i="${id}" ${S.coins < p.price ? 'disabled' : ''}>${t('buy')} ${p.price}🪙</button>`) +
        `</div></div></div>`
      );
    })
    .join('')}</div>`;

export const skinsSheet = () => {
  const id = S.sel,
    cur = skinOf(id);
  return `<div class="chip tx">${PLANES[id].n} · 💎 ${S.gems | 0}</div><div class="grid g2">${Object.entries(SKINS)
    .map(([k, sn]) => {
      const own = skinOwned(id, k);
      return `<div class="card"><b class="tx"><i class="sw" style="background:#${sn.sw.toString(16).padStart(6, '0')}"></i>${t('sk_' + k)}</b>${own ? `<button data-a="skuse" data-i="${k}" ${cur === k ? 'disabled' : ''}>${cur === k ? t('skOn') : t('use')}</button>` : `<button data-a="skbuy" data-i="${k}" ${(S.gems | 0) < sn.g ? 'disabled' : ''}>${t('buy')} ${sn.g}💎</button>`}</div>`;
    })
    .join('')}</div>`;
};
