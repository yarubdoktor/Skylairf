/* شاشة المنيو الداخلية: الإعدادات (v26.2.24، بند #18 — نُقلت حرفياً من menu.js). */
import {S} from '../save.js';
import {t} from '../i18n.js';
import {ic} from '../menu_icons.js';

export const settingsSheet = () => {
  const qs = [
    ['auto', 'qAuto'],
    ['lite', 'qLite'],
    ['low', 'qLow'],
    ['med', 'qMed'],
    ['high', 'qHigh']
  ];
  const sw = (a, on, label) =>
    `<button class="srow" data-a="${a}" role="switch" aria-checked="${on ? 'true' : 'false'}"><span class="tx">${label}</span><i class="swt ${on ? 'on' : ''}"><b></b></i></button>`;
  const seg = (a, items, cur) =>
    `<div class="seg">${items.map(([v, lb]) => `<button data-a="${a}" data-i="${v}" class="${String(cur) === String(v) ? 'on' : ''}">${lb}</button>`).join('')}</div>`;
  const grp = (icon, title, body) =>
    `<section class="sgrp"><h3>${ic(icon)}<span class="tx">${title}</span></h3>${body}</section>`;
  const lab = (txt, body) => `<div class="slab"><span class="tx">${txt}</span>${body}</div>`;
  const sp = Math.max(0, Math.min(100, ((S.sens - 0.5) / 1.1) * 100));
  return (
    `<div class="sgs">` +
    grp(
      'monitor',
      t('sgGfx'),
      lab(
        t('sQual'),
        seg(
          'q',
          qs.map(q => [q[0], t(q[1])]),
          S.q
        )
      ) +
        lab(
          t('sCam'),
          seg(
            'cam',
            [0, 1, 2].map(k => [k, t('cam' + k)]),
            S.cam | 0
          )
        ) +
        sw('fps', S.fps, t('sFps'))
    ) +
    grp(
      'vol',
      t('sgSnd'),
      sw('snd', S.snd, t('sSnd')) + sw('mus', S.mus, t('sMus')) + sw('vib', S.vib, t('sVib'))
    ) +
    grp(
      'pad',
      t('sgCtl'),
      lab(
        t('sFm'),
        seg(
          'fm',
          [
            [0, t('fm0')],
            [1, t('fm1')]
          ],
          S.fm | 0
        )
      ) +
        `<div class="srow static"><span class="tx">${t('sSens')}</span><div class="stp"><button data-a="sens" data-i="-1" aria-label="-">−</button><i class="sbar"><b style="width:${sp}%"></b></i><span class="sv">${S.sens.toFixed(1)}</span><button data-a="sens" data-i="1" aria-label="+">+</button></div></div>` +
        `<div class="srow static"><span class="tx">${t('sSensY')}</span><div class="stp"><button data-a="sensY" data-i="-1" aria-label="-">−</button><i class="sbar"><b style="width:${Math.max(0, Math.min(100, ((S.sensY - 0.5) / 1.1) * 100))}%"></b></i><span class="sv">${S.sensY.toFixed(1)}</span><button data-a="sensY" data-i="1" aria-label="+">+</button></div></div>` +
        lab(
          t('sAim'),
          seg(
            'aim',
            [0, 1, 2].map(k => [k, t('aim' + k)]),
            S.aim | 0
          )
        ) +
        sw('shk', S.shk !== 0, t('sShk')) +
        sw('assist', S.assist, t('sAssist')) +
        sw('tilt', S.tilt, t('sTilt')) +
        (S.tilt
          ? lab(
              t('sTiltR'),
              seg(
                'tiltR',
                [0, 1, 2].map(k => [k, t('tiltR' + k)]),
                S.tiltR | 0
              )
            )
          : '') +
        sw('ct', S.ct, t('sCt')) +
        sw('tiltInv', S.tiltInv, t('sTiltInv')) +
        sw('invY', S.invY, t('sInvY'))
    ) +
    grp(
      'gear',
      t('sgGame'),
      sw('tutOn', !S.tut, t('sTut')) +
        lab(
          t('sLang'),
          seg(
            'lang',
            [
              ['ar', 'العربية'],
              ['en', 'English']
            ],
            S.lang
          )
        )
    ) +
    `</div>`
  );
};
