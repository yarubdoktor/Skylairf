/* شاشة المنيو الداخلية: الخرائط ونمط اللعب (يأخذ api وحالة التحضير) (v26.2.24، بند #18 — نُقلت حرفياً من menu.js). */
import {S} from '../save.js';
import {MODES} from '../data.js';
import {t} from '../i18n.js';
import {modeArt} from '../art.js';
import {ic} from '../menu_icons.js';
import {plain} from './common.js';

export const setupSheet = ({api, busy}) =>
  () => `<div class="sec tx">${t('secMode')}</div><div class="grid g3 modes">${MODES.map(k => {
  const im = modeArt(k),
    MI = {survive: 'bolt', assault: 'target', defend: 'shield'},
    MG = {
      survive: 'linear-gradient(135deg,#0f3b66,#1b78b0)',
      assault: 'linear-gradient(135deg,#5a1d0a,#d9632a)',
      defend: 'linear-gradient(135deg,#123a2e,#2f9f78)'
    };
  return `<button class="modec ${S.mode === k ? 'sel' : ''}" data-a="mode" data-i="${k}"><div class="mimg2" style="background:${MG[k]}">${im ? `<img src="${im}" alt="">` : ic(MI[k])}</div><b class="tx">${plain(t('mode_' + k))}</b><small class="tx">${t('tg_' + k)}</small>${S.mode === k ? '<em>✓</em>' : ''}</button>`;
}).join('')}</div>
  <p class="mdesc tx">${t('md_' + S.mode)}</p>
  <div class="sec tx">${t('secMap')}${busy() ? ` <small>· ${t('prepMaps')}</small>` : ''}</div>
  <div class="grid g3 maps">${api
    .maps()
    .map(
      m =>
        `<button class="mapc ${S.map === m.id ? 'sel' : ''}" data-a="map" data-i="${m.id}"><div class="mimg" style="background:${m.grad}"><img data-mi="${m.id}" src="${m.img || ''}" alt="" ${m.img ? '' : 'hidden'}></div><b class="tx">${t('map_' + m.id)}</b>${S.map === m.id ? `<em>✓</em>` : ''}</button>`
    )
    .join('')}</div>`;
