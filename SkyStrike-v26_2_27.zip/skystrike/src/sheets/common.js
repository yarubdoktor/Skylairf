/* مساعدات مشتركة بين شاشات المنيو (v26.2.24، بند #18): أفاتار/رتبة/أشرطة/ترتيب/تكلفة. دوال صرفة. */
import {S} from '../save.js';
import {rankKey, BOTS, skinOf} from '../data.js';
import {t} from '../i18n.js';
import {ART, planeArt} from '../art.js';

export const avatar = (l, pct, cls = '') => {
  const img = ART.ui && ART.ui.avatar;
  return `<div class="av ${cls} ${rankKey(l)}" style="--p:${pct}"><div class="avi">${img ? `<img src="${img}" alt="">` : '<span>🧑‍✈️</span>'}</div><em class="lvb">${l}</em></div>`;
};
export const rb = (l, c = '') => {
  const im = ART.ui && ART.ui['rank_' + rankKey(l)];
  return im ? `<img class="rb ${c}" src="${im}" alt="">` : '';
};
export const plain = s => s.replace(/^[^\p{L}\p{N}]+/u, '').replace(/\s*\(.*\)\s*$/, '');
export const bar = (v, m) => `<i class="sb"><b style="width:${Math.min(100, (v / m) * 100)}%"></b></i>`;
export const wd = {
  gun: l => t('wd_gun', {d: 6 + 3 * l}),
  msl: l => t('wd_msl', {d: 50 + 25 * l, n: 3 + l}),
  multi: l => t('wd_multi', {d: 30 + 14 * l, n: 1 + l}),
  bomb: l => t('wd_bomb', {d: 90 + 40 * l, n: 3 + 2 * l})
};
export const nextLv = l => 60 * l * l;
export const baseLv = l => 60 * (l - 1) * (l - 1);
export const ranks = n =>
  BOTS.map(b => ({n: b[0], s: b[1], l: b[2]}))
    .concat(S.scores.map(s => ({...s, me: 1})))
    .sort((a, b) => b.s - a.s)
    .slice(0, n);

export const pimg = (PREV, id) => planeArt(id, skinOf(id)) || PREV[id] || ''; // صورة احترافية إن وُجدت، وإلا معاينة المحرك
