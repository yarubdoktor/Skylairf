/* شاشة المنيو الداخلية: الملف الشخصي + الترتيب (v26.2.24، بند #18 — نُقلت حرفياً من menu.js). */
import {clamp, esc} from '../util.js';
import {S} from '../save.js';
import {lvReward, PLANES, level, rankKey, avgCoins} from '../data.js';
import {t} from '../i18n.js';
import {ic} from '../menu_icons.js';
import {avatar, rb, plain, nextLv, baseLv, ranks} from './common.js';

export const profileSheet = () => {
  const l = level(),
    lo = baseLv(l),
    hi = nextLv(l),
    pct = clamp(((S.xp - lo) / (hi - lo)) * 100, 0, 100),
    best = S.scores.length ? S.scores[0].s : 0,
    own = Object.keys(S.pl).length;
  return `<div class="prof">${avatar(l, pct, 'big')}<div class="pf-in"><label class="tx">${t('pName')}</label><input id="pname" type="text" maxlength="16" value="${esc(S.name)}" autocomplete="off" spellcheck="false"></div></div>
  <div class="card col"><div class="pf-lv"><b>${rb(l, 'lg')}Lv ${l} · ${t(rankKey(l))}</b><span>${S.xp} / ${hi} ${t('xp')}</span></div><i class="xpb big"><b style="width:${pct}%"></b></i></div>
  <div class="card info"><div><b class="tx">🎁 ${t('lvRwT')}</b><small class="dr">${[1, 2, 3]
    .map(k => {
      const r = lvReward(l + k);
      return `Lv ${l + k}: +${r.c}🪙${r.g ? ' +' + r.g + '💎' : ''}${r.sk ? ' 🎨 ' + t('sk_' + r.sk) : ''}`;
    })
    .join('<br>')}</small></div></div>
  <div class="grid g2"><div class="card"><b class="tx">🪙 ${t('pCoins')}</b><em>${S.coins}</em></div><div class="card"><b class="tx">🏆 ${t('pBest')}</b><em>${best | 0}</em></div>
  <div class="card"><b class="tx">✈️ ${t('pPlanes')}</b><em>${own} / ${Object.keys(PLANES).length}</em></div><div class="card"><b class="tx">🎯 ${t('dailyT')}</b><em>${S.mis.l.filter(x => x.c).length} / ${S.mis.l.length}</em></div>
  <div class="card"><b class="tx">📊 ${t('pAvg')}</b><em>${avgCoins()}🪙</em></div><div class="card"><b class="tx">🛫 ${t('pRuns')}</b><em>${(S.st && S.st.n) | 0}</em></div></div>`;
};

export const rankingSheet = () => {
  const full = ranks(9999),
    me = full.findIndex(r => r.me),
    nm = r => esc(r.n || S.name);
  const pod = (r, i) =>
    r
      ? `<div class="pod p${i + 1} ${r.me ? 'me' : ''}"><div class="pm">${['👑', '🥈', '🥉'][i]}</div><div class="pa ${rankKey(r.l | 0)}">${esc((r.n || S.name).trim().charAt(0).toUpperCase())}</div><b class="tx">${nm(r)}</b><small>${rb(r.l | 0, 'md')}Lv ${r.l | 0}</small><strong>${r.s | 0}</strong><div class="pst"><i>${i + 1}</i></div></div>`
      : '<div class="pod"></div>';
  const row = (r, i) =>
    `<div class="rw ${r.me ? 'me' : ''}"><i class="rn">${i + 1}</i><span class="tx">${nm(r)}</span><small class="${rankKey(r.l | 0)}">${rb(r.l | 0)}Lv ${r.l | 0} · ${plain(t(rankKey(r.l | 0)))}</small><b>${r.s | 0}</b></div>`;
  return `<div class="rk-top"><span class="tx">${ic('trophy')} ${t('rkSeason')}</span><small>${t('localRank')}</small></div>
  <div class="podium">${pod(full[1], 1)}${pod(full[0], 0)}${pod(full[2], 2)}</div>
  <div class="rws">${full
    .slice(3, 15)
    .map((r, i) => row(r, i + 3))
    .join('')}</div>
  ${me >= 15 ? `<div class="rws you"><div class="rk-you tx">${t('rkYou')}</div>${row(full[me], me)}</div>` : ''}`;
};
