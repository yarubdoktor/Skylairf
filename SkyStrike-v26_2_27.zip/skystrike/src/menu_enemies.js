/* شاشة معلومات الأعداء: بطاقة لكل سفينة بصورتها وأرقامها (من ships.js).
   دالة صرفة: t و ART تُمرَّران كمعاملات فتُختبر بـ node بدون DOM. تُستدعى من menu.js › sheets.enemies. */
import {SHIPS, SHIP_TYPES} from './ships.js';

export function shipCard(k, t, img) {
  const s = SHIPS[k];
  const stats = s.unarmed
    ? t('shStatsU', {hp: s.hp, len: s.len, pts: s.pts})
    : t('shStats', {hp: s.hp, len: s.len, range: s.gun.range, pts: s.pts});
  const pic = img ? `<div class="cim"><img src="${img}" alt=""></div>` : '';
  return (
    `<div class="card ms ${img ? 'hasimg' : ''}">${pic}<div class="grow"><b class="tx">${t('shn_' + k)}</b>` +
    `<small class="tx">${t('shd_' + k)}</small><small class="tx">${stats}</small></div></div>`
  );
}

export const enemiesSheet = (t, ART) =>
  `<div class="chip tx">${t('enemiesHint')}</div>` +
  `<div class="grid g2">${SHIP_TYPES.map(k => shipCard(k, t, ART.ships[k])).join('')}</div>`;
