/* الواجهة أثناء اللعب: HUD النصي، مربع القفل، مؤشر التصويب (Lead)، أسهم خارج الشاشة. (الرادار صار بـ radar.js) */
import {$, clamp, VW, VH} from './util.js';
import {S} from './save.js';
import {t} from './i18n.js';
import {sfx, setIntensity} from './audio.js';
import {cam, ind, ix, V} from './core.js';
import {W, P} from './state.js';
import {el} from './ui.js';
import {radarUpdate} from './radar.js';

const _a = V(),
  _b = V(),
  _c = V();

export function hudUpdate(dt) {
  const G = W.G,
    candE = W.candE,
    lockE = W.lockE,
    enemies = W.enemies,
    projs = W.projs;
  if (candE && !G.dead) {
    _a.copy(candE.g.position).project(cam);
    if (_a.z < 1) {
      const c = lockE ? '#ff4d5e' : '#ffd24d';
      el.lkb.style.display = 'block';
      el.lkb.style.left = (_a.x * 0.5 + 0.5) * VW() + 'px';
      el.lkb.style.top = (-_a.y * 0.5 + 0.5) * VH() + 'px';
      el.lkb.style.borderColor = c;
      el.lkb.style.color = c;
      el.lkb.style.borderStyle = lockE ? 'solid' : 'dashed';
      el.lkb.textContent = (W.lockDist | 0) + 'm';
    } else el.lkb.style.display = 'none';
  } else el.lkb.style.display = 'none';
  leadUpdate();
  indUpdate();
  radarUpdate(dt);
  G.hudT -= dt;
  if (G.hudT > 0) return;
  G.hudT = 0.09;
  const pos = P.g.position,
    lbl = S.mode === 'assault' ? 'STAGE' : 'WAVE';
  el.hp.style.width = Math.max(0, (P.hp / P.maxhp) * 100) + '%';
  el.sc.textContent = G.score;
  el.cmb.textContent = G.mult > 1 ? `${t('combo')} ×${G.mult}` : '';
  el.st.innerHTML = `${G.op && G.op.progress ? G.op.progress() : lbl + ' ' + G.wave + (G.camp ? '/' + G.camp.c.goal : '')} · MSL ${P.msl}${S.multi ? ` · MUL ${P.mul}` : ''}${S.bomb ? ` · BMB ${P.bmb}` : ''} · FLR ${P.flr}<br>ALT ${pos.y | 0} m · ${(P.cur * 3.2) | 0} km/h${S.fm ? ` · ${P.gl.toFixed(1)}G` : ''}<br>BOOST ${(P.en * 100) | 0}%`;
  if (G.boss) {
    el.bossw.style.display = 'block';
    el.bossb.style.width = Math.max(0, (G.boss.hp / G.boss.max) * 100) + '%';
  } else el.bossw.style.display = 'none';
  if (S.mode === 'defend') el.baseb.style.width = Math.max(0, G.base) + '%';
  let warn = '',
    mis = false;
  for (const p of projs)
    if (p.owner === 'e' && p.mis && p.mesh.position.distanceToSquared(pos) < 1000 * 1000) {
      mis = true;
      break;
    }
  if (mis && !G.dead) {
    warn = t('missile');
    if (G.t - (G.alT ?? -9) > 1) {
      sfx('alarm');
      G.alT = G.t;
    }
  } else if (G.pull && !G.dead) warn = t('pullUp');
  el.warn.textContent = warn;
  el.warn.style.opacity = warn ? 1 : 0;
  setIntensity(clamp(enemies.length / 8 + (G.boss ? 0.4 : 0) + (P.hp < P.maxhp * 0.3 ? 0.2 : 0), 0, 1));
  if (el.fps.style.display !== 'none') el.fps.style.display = S.fps ? 'block' : 'none';
}

/* ---------- مؤشر التصويب (Lead) ---------- */
function leadUpdate() {
  const ld = el.ld,
    candE = W.candE,
    lockDist = W.lockDist;
  if (W.G.dead || !candE || !candE.vel || lockDist > 1000) {
    ld.style.display = 'none';
    return;
  }
  const ep = candE.g.position,
    pp = P.g.position;
  let tt = lockDist / 750;
  for (let k = 0; k < 2; k++) {
    _c.copy(ep).addScaledVector(candE.vel, tt);
    tt = _c.distanceTo(pp) / 750;
  }
  _c.copy(ep).addScaledVector(candE.vel, tt).project(cam);
  if (_c.z >= 1) {
    ld.style.display = 'none';
    return;
  }
  ld.style.display = 'block';
  ld.style.left = (_c.x * 0.5 + 0.5) * VW() + 'px';
  ld.style.top = (-_c.y * 0.5 + 0.5) * VH() + 'px';
}

/* ---------- أسهم الأعداء خارج الشاشة + تنبيه الصواريخ القادمة ---------- */
function indUpdate() {
  const G = W.G;
  const Wd = ind.width,
    H = ind.height;
  ix.clearRect(0, 0, Wd, H);
  if (G.dead) return;
  const cx0 = Wd / 2,
    cy0 = H / 2,
    rx = Wd / 2 - 34,
    ry = H / 2 - 34,
    inv = cam.matrixWorldInverse,
    pp = P.g.position,
    pulse = 0.55 + 0.45 * Math.sin(G.t * 14);
  const mark = (p, col, sz, alpha, ring) => {
    _a.copy(p).applyMatrix4(inv);
    const n = _b.copy(p).project(cam);
    if (_a.z < 0 && Math.abs(n.x) < 0.94 && Math.abs(n.y) < 0.9) {
      if (ring) {
        ix.globalAlpha = alpha;
        ix.strokeStyle = col;
        ix.lineWidth = 2.5;
        ix.beginPath();
        ix.arc((n.x * 0.5 + 0.5) * Wd, (-n.y * 0.5 + 0.5) * H, sz, 0, 6.283);
        ix.stroke();
      }
      return;
    }
    let dx = _a.x,
      dy = -_a.y;
    const m = Math.hypot(dx, dy);
    if (m < 1e-3) {
      dx = 0;
      dy = 1;
    } else {
      dx /= m;
      dy /= m;
    }
    const k = 1 / Math.max(Math.abs(dx) / rx, Math.abs(dy) / ry);
    ix.save();
    ix.translate(cx0 + dx * k, cy0 + dy * k);
    ix.rotate(Math.atan2(dy, dx));
    ix.globalAlpha = alpha;
    ix.fillStyle = col;
    ix.strokeStyle = '#000a';
    ix.lineWidth = 1.5;
    ix.beginPath();
    ix.moveTo(sz, 0);
    ix.lineTo(-sz * 0.7, sz * 0.75);
    ix.lineTo(-sz * 0.35, 0);
    ix.lineTo(-sz * 0.7, -sz * 0.75);
    ix.closePath();
    ix.fill();
    ix.stroke();
    ix.restore();
  };
  for (const e of W.enemies) {
    if (!e.air) continue;
    const d = e.g.position.distanceTo(pp);
    mark(e.g.position, e.kind === 'boss' ? '#ff2bd6' : '#ff3b3b', 9 + clamp(1 - d / 1800, 0, 1) * 8, 0.85, false);
  }
  for (const p of W.projs) {
    if (p.owner !== 'e' || !p.mis) continue;
    if (p.mesh.position.distanceToSquared(pp) > 1300 * 1300) continue;
    mark(p.mesh.position, '#ffd24d', 14, pulse, true);
  }
  ix.globalAlpha = 1;
}
