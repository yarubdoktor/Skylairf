/* نافذة معاينة الطائرة 360° (بند #3): استوديو سينمائي كامل الشاشة على نفس renderer اللعبة.
   سحب = تدوير بقصور ذاتي · قرصة = تكبير · ترك = دوران تلقائي · زر = عرض الأسلحة · أسهم = تبديل الطائرة.
   اللعبة نفسها متوقفة (نحن باللوبي)، فلا حاجة لسياق WebGL ثانٍ. حلقة الرسم تعمل فقط والنافذة مفتوحة. */
import * as THREE from 'three';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
import {renderer} from './core.js';
import {createFX} from './fx.js';
import {mkJet} from './jets.js';
import {PLANES, SKINS, skinOf, stats} from './data.js';
import {S} from './save.js';
import {Q} from './quality.js';
import {t} from './i18n.js';
import {VW, VH, FL} from './util.js';
import {tickSkins} from './skins/apply.js';
import {buildStage} from './hangar_scene.js';
import {createShow} from './hangar_show.js';
import * as HM from './hangar_math.js';

const {newOrbit, orbitDrag, orbitRelease, orbitPinch, orbitStep, orbitPos, introK, INTRO, norm} = HM;
const DIST = 31;
let open = null, // الجلسة الحالية (واحدة فقط)
  kit = null; // المشهد + الجسيمات + العرض: يُبنى مرة وتُعاد استعماله (لا تسرّب عند كل فتح)

const hex = n => '#' + (n ?? 0x9099a5).toString(16).padStart(6, '0');
function panelHtml(id) {
  const p = PLANES[id],
    own = !!S.pl[id],
    st = own ? stats(id) : {speed: p.speed, turn: p.turn, hp: p.hp},
    sk = skinOf(id),
    bar = (k, v, m, f) =>
      `<span>${k}</span><i class="sb"><b style="width:${norm(v, m) * 100}%"></b></i><em>${Math.round(v * f)}</em>`;
  return `<b class="hg-n">${p.n}</b><p class="hg-d">${t('d_' + id)}</p>
    <div class="st">${bar('SPD', st.speed, 280, 1)}${bar('TURN', st.turn, 2.3, 10)}${bar('HP', st.hp, 300, 1)}</div>
    <div class="hg-sk"><i style="background:${hex(SKINS[sk].sw)}"></i>${t('sk_' + sk)}
    ${own ? '' : `<em>🔒 💰 ${p.price}</em>`}</div>`;
}

function mkComposer(sc, cm) {
  if (!Q.bloom) return null;
  try {
    const c = new EffectComposer(renderer);
    c.addPass(new RenderPass(sc, cm));
    c.addPass(new UnrealBloomPass(new THREE.Vector2(VW() / 2, VH() / 2), 0.55, 0.7, 0.82));
    c.addPass(new OutputPass());
    c.setPixelRatio(renderer.getPixelRatio());
    c.setSize(VW(), VH());
    return c;
  } catch (e) {
    return null; // بلا بلوم: التوهج الجمعي من الجسيمات يكفي
  }
}

export function openHangar(startId, onClose) {
  if (open) return;
  const ids = Object.keys(PLANES);
  let idx = Math.max(0, ids.indexOf(startId)),
    introT = 0,
    raf = 0,
    last = performance.now();
  if (!kit) {
    const stage = buildStage(),
      f = createFX(stage.scene);
    kit = {st: stage, fx: f, show: createShow(stage.scene, f)};
  }
  const {st, fx, show} = kit,
    cm = new THREE.PerspectiveCamera(34, VW() / VH(), 0.5, 300),
    orbit = newOrbit(),
    comp = mkComposer(st.scene, cm),
    ptr = new Map(),
    el = document.createElement('div');
  el.id = 'hangar';
  el.innerHTML = `<div class="hg-touch"></div>
    <button class="hg-x" data-h="x" aria-label="${t('close')}">✕</button>
    <div class="hg-info"></div>
    <div class="hg-bar"><button data-h="p">‹</button><button class="hg-w" data-h="w">🎯 ${t('hgWpn')}</button>
    <button data-h="n">›</button><button class="hg-x2" data-h="x" aria-label="${t('close')}">✕</button></div>
    <div class="hg-hint">${t('hgHint')}</div>`;
  document.body.appendChild(el);
  const info = el.querySelector('.hg-info'),
    wbtn = el.querySelector('.hg-w');
  const setPlane = (i, soft) => {
    idx = (i + ids.length) % ids.length;
    const id = ids[idx],
      p = PLANES[id];
    st.setJet(mkJet(p.kind, p.col, true, skinOf(id)));
    show.kind = p.kind;
    show.clear();
    info.innerHTML = panelHtml(id);
    introT = soft ? INTRO * 0.55 : 0;
  };
  const size = () => {
    cm.aspect = VW() / VH();
    cm.updateProjectionMatrix();
    fx.setScale(VH() * renderer.getPixelRatio(), cm.fov);
    if (comp) {
      comp.setPixelRatio(renderer.getPixelRatio());
      comp.setSize(VW(), VH());
    }
  };
  const close = () => {
    cancelAnimationFrame(raf);
    removeEventListener('resize', size);
    removeEventListener('keydown', key);
    el.remove();
    if (comp) comp.dispose();
    show.clear();
    open = null;
    onClose && onClose();
  };
  const key = e => e.key === 'Escape' && close();
  const loop = now => {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    introT += dt;
    orbitStep(orbit, dt);
    const k = introK(introT / INTRO),
      o = {yaw: orbit.yaw - (1 - k) * 2.4, pitch: orbit.pitch - (1 - k) * 0.3, zoom: orbit.zoom * (1 + (1 - k) * 0.7)};
    const p = orbitPos(o, DIST);
    cm.position.set(p.x, p.y - 0.8, p.z);
    cm.lookAt(0, -0.8, 0);
    st.update(dt, p);
    show.update(dt);
    tickSkins(dt);
    if (comp) comp.render();
    else renderer.render(st.scene, cm);
    raf = requestAnimationFrame(loop);
  };
  // لمس: إصبع = تدوير ، إصبعان = تكبير
  const touch = el.querySelector('.hg-touch');
  let pinchD = 0,
    lt = 0;
  touch.addEventListener('pointerdown', e => {
    touch.setPointerCapture(e.pointerId);
    ptr.set(e.pointerId, {x: e.clientX, y: e.clientY});
    lt = e.timeStamp;
    el.classList.add('used');
    if (ptr.size === 2) pinchD = 0;
  });
  touch.addEventListener('pointermove', e => {
    const p = ptr.get(e.pointerId);
    if (!p) return;
    const sx = e.clientX - p.x,
      sy = e.clientY - p.y,
      [dx, dy] = FL.on ? [sy, -sx] : [sx, sy], // الجوال العمودي: الواجهة مدوّرة 90° (index.html)
      dt = Math.max(0.001, (e.timeStamp - lt) / 1000);
    lt = e.timeStamp;
    p.x = e.clientX;
    p.y = e.clientY;
    if (ptr.size === 1) orbitDrag(orbit, dx, dy, dt);
    else if (ptr.size === 2) {
      const [a, b] = [...ptr.values()],
        d = Math.hypot(a.x - b.x, a.y - b.y);
      if (pinchD) orbitPinch(orbit, d / pinchD);
      pinchD = d;
    }
  });
  const up = e => {
    ptr.delete(e.pointerId);
    pinchD = 0;
    if (!ptr.size) orbitRelease(orbit);
  };
  touch.addEventListener('pointerup', up);
  touch.addEventListener('pointercancel', up);
  touch.addEventListener('wheel', e => orbitPinch(orbit, e.deltaY > 0 ? 0.93 : 1.07), {passive: true});
  el.addEventListener('click', e => {
    const a = e.target.closest('[data-h]');
    if (!a) return;
    const h = a.dataset.h;
    if (h === 'x') close();
    else if (h === 'p') setPlane(idx - 1, true);
    else if (h === 'n') setPlane(idx + 1, true);
    else if (h === 'w') {
      show.setOn(!show.on);
      wbtn.classList.toggle('on', show.on);
    }
  });
  addEventListener('resize', size);
  addEventListener('keydown', key);
  open = {close};
  setPlane(idx);
  size();
  raf = requestAnimationFrame(loop);
}
