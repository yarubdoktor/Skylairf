/* كاميرا مراقبة الهدف (بند #13b) — دالة صرفة، تنختبر بـ node. لما يكون في قفل كامل تميل نقطة نظر الكاميرا
   قليلاً نحو الهدف (بحد أقصى للزاوية) حتى يبقى بالمشهد، بدون ما تنفصل عن اتجاه الطائرة. خيار S.ct (الافتراضي مطفأ). */
export const CT = {maxDeg: 9, k: 0.4, range: 1800};
const RAD = Math.PI / 180;
/* fw/to: {x,y,z} موحّدان (الأمام / اتجاه الهدف) · w: وزن 0..1 (يُنعَّم من الخارج) → اتجاه النظر بـ out */
export function lookBlend(fw, to, w, out) {
  out.x = fw.x;
  out.y = fw.y;
  out.z = fw.z;
  if (w <= 0) return out;
  const ang = Math.acos(Math.min(1, Math.max(-1, fw.x * to.x + fw.y * to.y + fw.z * to.z)));
  if (ang < 1e-4 || ang > 1.5) return out; // أكبر من ~86°: الهدف خلفك/جانبك، لا نلوي الكاميرا
  const t = Math.min(CT.k, (CT.maxDeg * RAD) / ang) * Math.min(1, w),
    sn = Math.sin(ang);
  const w0 = Math.sin((1 - t) * ang) / sn,
    w1 = Math.sin(t * ang) / sn;
  out.x = fw.x * w0 + to.x * w1;
  out.y = fw.y * w0 + to.y * w1;
  out.z = fw.z * w0 + to.z * w1;
  return out;
}
