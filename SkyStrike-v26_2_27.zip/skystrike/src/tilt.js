/* معالجة الميلان (بند #13b) — دوال صرفة بلا DOM، تنختبر بـ node (tools/test/test_controls.mjs).
   قبلها: الميلان كان خطياً بنطاق ثابت 22° بلا منطقة ميتة ولا تنعيم (اهتزاز اليد ينتقل مباشرة للطائرة). */
export const TILT_RANGE = [14, 22, 32]; // S.tiltR: 0 حساس · 1 عادي (كالقديم) · 2 هادئ — درجات الميلان لأقصى عصا
export const TILT_DZ = 1.6; // منطقة ميتة (درجة) حول وضع المعايرة
export const TILT_TAU = 0.07; // ثابت تنعيم (ث)

/* delta بالدرجات عن وضع المعايرة → محور -1..1 مع منطقة ميتة ومنحنى لطيف قرب الصفر (دقة أعلى بالحركات الصغيرة) */
export function tiltAxis(delta, level) {
  const R = TILT_RANGE[level] ?? TILT_RANGE[1],
    a = Math.abs(delta);
  if (a <= TILT_DZ) return 0;
  const n = Math.min(1, (a - TILT_DZ) / (R - TILT_DZ));
  return Math.sign(delta) * (n * (0.6 + 0.4 * n));
}
/* تنعيم أُسّي مستقل عن معدل الفريم */
export const smooth = (prev, next, dt) => prev + (next - prev) * (1 - Math.exp(-dt / TILT_TAU));
