/* سفن الأعداء (v26.2.18) — بيانات صرفة بدون three/DOM (تنختبر بـ node).
   النماذج: src/models/e_<type>.glb (بالحجم الحقيقي بالمتر). المحاور: المقدمة −Z · y=0 خط الماء · البدن مقطوع عند y≈−3.
   العقد: body · aim (+aim2..4 للحاملة) = أبراج المدفع (فوهتها −Z بالنموذج: mkShip يقلبها لتوافق lookAt) · radar = طبق يدور حول Y.
   r = نصف قطر التصادم (م) · muz = ارتفاع الفوهة فوق خط الماء (م) · hp/hpw/pts = أرقام التوازن (عدّلها هنا) ·
   gun = مدفع السفينة (يستعمل عقل الأرضيات 'ship' بـ enemies.js) · unarmed = هدف أعزل (لا aim). */
export const SHIP_TYPES = ['carrier', 'destroyer', 'frigate', 'patrol', 'cargo'];
export const SHIPS = {
  carrier: {
    len: 310,
    r: 95,
    muz: 14,
    hp: 1400,
    hpw: 90,
    pts: 1500,
    gun: {range: 900, cd: 1.9, speed: 480, dmg: 6, dmgw: 0.6, spread: 14}
  },
  destroyer: {
    len: 155,
    r: 48,
    muz: 8,
    hp: 480,
    hpw: 45,
    pts: 700,
    gun: {range: 1000, cd: 1.7, speed: 500, dmg: 7, dmgw: 0.8, spread: 10}
  },
  frigate: {
    len: 110,
    r: 34,
    muz: 7,
    hp: 300,
    hpw: 32,
    pts: 450,
    gun: {range: 850, cd: 1.7, speed: 480, dmg: 6, dmgw: 0.7, spread: 14}
  },
  patrol: {
    len: 32,
    r: 12,
    muz: 3.5,
    hp: 90,
    hpw: 12,
    pts: 180,
    gun: {range: 650, cd: 1.2, speed: 460, dmg: 4, dmgw: 0.5, spread: 18}
  },
  cargo: {len: 180, r: 52, muz: 8, hp: 320, hpw: 24, pts: 250, unarmed: true}
};
export const shipRadius = k => SHIPS[k].r;
export const isArmed = k => !SHIPS[k].unarmed;
// أسماء عقد الأبراج المطلوبة لكل نوع (الأولى = البرج الرئيسي)
export const AIM_NODES = {
  carrier: ['aim', 'aim2', 'aim3', 'aim4'],
  destroyer: ['aim', 'aim2'],
  frigate: ['aim'],
  patrol: ['aim'],
  cargo: []
};
