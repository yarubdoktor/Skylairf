/* أدوات مشتركة لبناء المجسمات البرمجية: كاش geometry/material + مساعدات (v26.2.11: خرج من jets.js). */
import * as THREE from 'three';
// كل الـ geometry والـ materials مشتركة ومخزّنة (cache) => ما في تسريب ذاكرة ولا إنشاء كل مرة
const GC = {},
  MC = {};
export const geo = (k, f) => GC[k] || (GC[k] = f());
export const mkm = (k, f) => MC[k] || (MC[k] = f());
export const stdm = (c, m = 0.5, r = 0.45) =>
  mkm(`s${c}_${m}_${r}`, () => new THREE.MeshStandardMaterial({color: c, metalness: m, roughness: r}));
export const basic = (c, o = 1, add = false) =>
  mkm(
    `b${c}_${o}_${add}`,
    () =>
      new THREE.MeshBasicMaterial({
        color: c,
        transparent: o < 1 || add,
        opacity: o,
        blending: add ? THREE.AdditiveBlending : THREE.NormalBlending,
        depthWrite: !(o < 1 || add)
      })
  );
export function planform(pts, th) {
  const sh = new THREE.Shape();
  pts.forEach((q, i) => (i ? sh.lineTo(q[0], q[1]) : sh.moveTo(q[0], q[1])));
  const g = new THREE.ExtrudeGeometry(sh, {depth: th, bevelEnabled: false});
  g.rotateX(Math.PI / 2);
  return g;
}
export function holder() {
  const g = new THREE.Group();
  g.add_ = (ge, ma, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) => {
    const o = new THREE.Mesh(ge, ma);
    o.position.set(x, y, z);
    o.rotation.set(rx, ry, rz);
    g.add(o);
    return o;
  };
  return g;
}
export const FUS = () =>
  geo('fus', () =>
    new THREE.LatheGeometry(
      [
        [0, -6.8],
        [0.5, -6.8],
        [0.95, -5.4],
        [1.25, -2.5],
        [1.35, 0.5],
        [1.2, 3.5],
        [0.9, 5.2],
        [0.45, 6.5],
        [0, 7.6]
      ].map(a => new THREE.Vector2(a[0], a[1])),
      20
    ).rotateX(-Math.PI / 2)
  );
export const WP = [
  [
    [1, -1.2],
    [4.8, 1.8],
    [4.8, 2.8],
    [1, 3.6]
  ],
  [
    [1, -3.2],
    [5.4, 1.2],
    [5.4, 2.4],
    [1, 3.4]
  ],
  [
    [1, -3.5],
    [5.6, 1.8],
    [5.6, 2.8],
    [1, 3.8]
  ]
];

export function flames(g, xs, z, player, sc = 1, noz = true, y = 0, col = 0) {
  const fl = [];
  for (const x of xs) {
    if (noz)
      g.add_(
        geo('noz', () => new THREE.CylinderGeometry(0.62, 0.5, 1.2, 10).rotateX(Math.PI / 2)),
        stdm(0x1b2027, 0.3, 0.6),
        x,
        0,
        z - 0.5
      );
    const f = new THREE.Group();
    f.position.set(x, y, z);
    const o = new THREE.Mesh(
      geo('fo', () => new THREE.ConeGeometry(0.55, 4.5, 10)),
      basic(col || (player ? 0xff8a2f : 0xff5a2a), 0.7, true)
    );
    o.rotation.x = Math.PI / 2;
    o.position.z = 2.25;
    const n = new THREE.Mesh(
      geo('fn', () => new THREE.ConeGeometry(0.28, 2.6, 8)),
      basic(0xfff0c0, 0.9, true)
    );
    n.rotation.x = Math.PI / 2;
    n.position.z = 1.3;
    f.add(o, n);
    f.scale.setScalar(sc);
    g.add(f);
    fl.push(f);
  }
  return fl;
}
