/* مجسمات سفن الأعداء (v26.2.18). النموذج GLB من emodels.js (e_carrier/e_destroyer/e_frigate/e_patrol/e_cargo).
   فوهة برج السفينة بالنموذج على −Z (مثل الطائرات) بينما lookAt يوجّه +Z نحو الهدف، لذلك كل عقدة aim
   تُلفّ بحاوية مقلوبة 180° حول Y: المجسم يبقى كما رُسم والفوهة تتجه فعلاً للهدف.
   userData: aim (البرج الرئيسي) · aims (كل الأبراج) · radar (طبق الرادار، إن وُجد) · ship (النوع). */
import * as THREE from 'three';
import {hasEM, mkEM} from '../emodels.js';
import {SHIPS, AIM_NODES} from '../ships.js';
import {stdm, geo, holder} from './common.js';

export function mkShip(type) {
  const g = holder(),
    S = SHIPS[type];
  g.userData.ship = type;
  if (hasEM('ship_' + type)) {
    const m = mkEM('ship_' + type);
    g.add(m);
    const aims = [];
    for (const n of AIM_NODES[type]) {
      const a = m.getObjectByName(n);
      if (!a) continue;
      // pv = محور البرج الذي يدوّره ai.js بـ lookAt؛ المجسم (a) يُقلب 180° داخله ليتجه −Z نحو الهدف
      const pv = new THREE.Group(),
        par = a.parent;
      pv.name = n;
      pv.position.copy(a.position);
      a.position.set(0, 0, 0);
      a.name = n + '_gun';
      a.rotation.y = Math.PI;
      par.add(pv);
      pv.add(a);
      aims.push(pv);
    }
    g.userData.aims = aims;
    g.userData.aim = aims[0] || new THREE.Group();
    g.userData.radar = m.getObjectByName('radar') || null;
    return g;
  }
  // احتياطي إن فشل تحميل النموذج: بدن صندوقي بسيط بنفس الطول
  const w = Math.max(6, S.len * 0.14),
    hull = new THREE.Mesh(
      geo(`shipbox_${type}`, () => new THREE.BoxGeometry(w, 6, S.len)),
      stdm(0x8a949c, 0.2, 0.65)
    );
  hull.position.y = 0;
  g.add(hull);
  const tur = new THREE.Group();
  tur.position.set(0, 3, -S.len * 0.3);
  g.add(tur);
  g.userData.aim = tur;
  g.userData.aims = S.unarmed ? [] : [tur];
  g.userData.radar = null;
  return g;
}
