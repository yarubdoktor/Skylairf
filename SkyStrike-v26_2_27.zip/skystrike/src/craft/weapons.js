/* أسلحة بصرية: رصاص، صاروخ، قنبلة (v26.2.11: خرج من jets.js). */
import * as THREE from 'three';
import {geo, stdm, basic} from './common.js';
export const BULLET_GEO = new THREE.SphereGeometry(0.35, 6, 4);
export const BULLET_P = basic(0xffe27a),
  BULLET_E = basic(0xff4040);
export function mkMsl(enemy) {
  const g = new THREE.Group(),
    w = stdm(enemy ? 0x3a3a3a : 0xe8edf2, 0.2, 0.4),
    r = stdm(enemy ? 0xff5522 : 0xc23b2e, 0.2, 0.5);
  g.add(
    new THREE.Mesh(
      geo('mbody', () => new THREE.CylinderGeometry(0.28, 0.28, 3.4, 8).rotateX(Math.PI / 2)),
      w
    ),
    new THREE.Mesh(
      geo('mnose', () => new THREE.ConeGeometry(0.28, 1.1, 8).rotateX(Math.PI / 2).translate(0, 0, 2.2)),
      r
    )
  );
  const f = new THREE.Mesh(
    geo('mfin', () => new THREE.BoxGeometry(0.08, 1.3, 0.8).translate(0, 0, -1.3)),
    r
  );
  g.add(f);
  const f2 = f.clone();
  f2.rotation.z = Math.PI / 2;
  g.add(f2);
  return g;
}
export function mkBomb() {
  const g = new THREE.Group(),
    m = stdm(0x3b4a2c, 0.2, 0.6);
  g.add(
    new THREE.Mesh(
      geo('bobody', () => new THREE.CylinderGeometry(0.5, 0.5, 2.2, 8).rotateX(Math.PI / 2)),
      m
    ),
    new THREE.Mesh(
      geo('bonose', () => new THREE.ConeGeometry(0.5, 0.9, 8).rotateX(Math.PI / 2).translate(0, 0, 1.5)),
      m
    )
  );
  return g;
}
