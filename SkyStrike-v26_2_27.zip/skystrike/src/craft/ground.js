/* مجسمات الأرضيات + مستودع الوقود (v26.2.11: خرج من jets.js). */
import * as THREE from 'three';
import {hasEM, mkEM} from '../emodels.js';
import {GK, groundScale} from '../gscale.js';
import {geo, stdm, basic, holder} from './common.js';
// أنواع الأرضيات: 0 مدفع مزدوج ، 1 دبابة مضادة ، 2 جيبارد ، 3 صواريخ SAM ، 4 فلاك ثقيل (flak). كلها GLB (فوهتها +Z) والبرج 'aim' يدور نحو اللاعب
const GK_SHADOW = [9, 12, 11, 11, 10]; // نصف قطر الظل لكل نوع (بعد التكبير)
export function mkGround(t) {
  if (hasEM(GK[t])) {
    const m = mkEM(GK[t]);
    m.rotation.y = Math.random() * Math.PI * 2; // اتجاه عشوائي للهيكل (البرج يتجه بـ lookAt بالعالم)
    const g = holder();
    g.add(m);
    // v26.2.4: مقياس واقعي/مضخّم (gscale.js). g = الحاوية اللي تكبّرها اللعبة بالمسافة
    m.scale.setScalar(groundScale(GK[t]));
    g.add_(
      geo('gshadow', () => new THREE.CircleGeometry(1, 24).rotateX(-Math.PI / 2)),
      basic(0x000000, 0.38),
      0,
      0.25,
      0
    ).scale.setScalar(GK_SHADOW[t]); // ظل دائري يثبّت الآلة بالأرض ويعطي عمقاً
    g.userData.aim = m.getObjectByName('aim') || m;
    g.userData.gk = GK[t];
    return g;
  }
  if (t === 4) t = 2; // المجسم البرمجي القديم للـ flak
  const g = holder(),
    a = stdm(0x56604a, 0.1, 0.8),
    b = stdm(0x2c3128, 0.1, 0.7),
    tur = new THREE.Group();
  const box = (w, h, d, mt, x, y, z, par) => {
    const o = new THREE.Mesh(
      geo(`bx${w}_${h}_${d}`, () => new THREE.BoxGeometry(w, h, d)),
      mt
    );
    o.position.set(x, y, z);
    (par || g).add(o);
    return o;
  };
  if (t === 0) {
    const bs = new THREE.Mesh(
      geo('gbs', () => new THREE.CylinderGeometry(5, 7, 4, 8)),
      a
    );
    bs.position.y = 2;
    g.add(bs);
    tur.position.y = 5;
    box(3.5, 2.4, 4, b, 0, 0, 0, tur);
    box(0.5, 0.5, 8, b, -0.9, 0.3, 5, tur);
    box(0.5, 0.5, 8, b, 0.9, 0.3, 5, tur);
  } else if (t === 1) {
    box(7, 2, 11, a, 0, 1.6, 0);
    box(1.6, 2, 11.4, b, -3.8, 1, 0);
    box(1.6, 2, 11.4, b, 3.8, 1, 0);
    tur.position.y = 3.6;
    box(4.4, 1.8, 5, a, 0, 0, 0, tur);
    box(0.6, 0.6, 7, b, 0, 0.2, 5.5, tur);
  } else if (t === 2) {
    box(6, 2, 6, b, 0, 1, 0);
    tur.position.y = 2.6;
    for (const x of [-1.6, 0, 1.6]) for (const y of [0, 1.6]) box(0.9, 0.9, 7, a, x, y, 2, tur);
  } else {
    box(8, 2, 8, b, 0, 1, 0);
    box(5, 0.6, 5, a, 0, 2.3, 0);
    tur.position.y = 3.2;
    box(3, 1.6, 3, a, 0, 0, 0, tur);
    for (const x of [-1.2, 1.2]) {
      box(0.9, 0.9, 6.5, a, x, 1.1, -1.8, tur).rotation.x = 0.5;
      const tip = box(0.7, 0.7, 1, stdm(0xc23b2e, 0.2, 0.5), x, 2.2, -4.4, tur);
      tip.rotation.x = 0.5;
    }
  }
  g.add(tur);
  g.userData.aim = tur;
  return g;
}
export function mkDepot() {
  const g = holder(),
    a = stdm(0x5b6458, 0.2, 0.7),
    b = stdm(0x2c3128, 0.2, 0.7);
  g.add_(
    geo('db', () => new THREE.BoxGeometry(34, 1.2, 30)),
    b,
    0,
    0.6,
    0
  );
  for (const p of [
    [-9, 0],
    [9, 0],
    [0, -10]
  ])
    g.add_(
      geo('dt', () => new THREE.CylinderGeometry(5, 5, 7, 14)),
      a,
      p[0],
      4.7,
      p[1]
    );
  g.add_(
    geo('dtw', () => new THREE.CylinderGeometry(2, 3, 20, 8)),
    a,
    0,
    11,
    8
  );
  g.add_(
    geo('dtop', () => new THREE.SphereGeometry(2.4, 10, 8)),
    basic(0xff3322),
    0,
    22.5,
    8
  );
  g.userData.aim = new THREE.Group();
  g.add(g.userData.aim);
  return g;
}
