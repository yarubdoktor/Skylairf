/* مقاتلات اللاعب/العدو: نماذج GLB + مجسم mkJet البرمجي (v26.2.11: خرج من jets.js). */
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {loadEnemyModels, hasEM, mkEM} from '../emodels.js';
import {PFL, WT, MODEL_URL} from './roster.js';
import {bakeCoords, skinMaterial} from '../skins/apply.js';
import {SKIN_DEFS} from '../skins/defs.js';
import {geo, mkm, stdm, basic, planform, holder, FUS, WP, flames} from './common.js';
/* ---------- نماذج GLB (اختيارية): إذا فشل التحميل تستعمل اللعبة المجسم البرمجي القديم ---------- */
const PM = {}; // نماذج اللاعب حسب kind (انظر roster.js)
// نسخ ملونة من نموذج اللاعب (Skins): مواد مخزّنة لكل (طائرة، لون)
const SKV = {};
function skinModel(kind, key) {
  const k = kind + '_' + key;
  if (!SKV[k]) {
    bakeCoords(PM[kind]); // إحداثيات النمط (مرة لكل نموذج، تتشاركها كل السكنات)
    const r = PM[kind].clone(true),
      cm = {};
    r.traverse(o => {
      if (o.isMesh) {
        const u = o.material.uuid;
        if (!cm[u]) cm[u] = skinMaterial(o.material, key);
        o.material = cm[u];
      }
    });
    SKV[k] = r;
  }
  return SKV[k].clone(true);
}
function loadGLB(url, tune) {
  return new Promise(res => {
    try {
      new GLTFLoader().load(
        url,
        gltf => {
          gltf.scene.traverse(o => {
            if (o.isMesh && o.material) {
              o.material.envMapIntensity = 1.3;
              if (o.material.transparent) o.material.depthWrite = false;
            }
          });
          tune(gltf.scene);
          res(true);
        },
        undefined,
        err => {
          console.warn(url + ' failed, using built-in model', err);
          res(false);
        }
      );
    } catch (err) {
      console.warn(err);
      res(false);
    }
  });
}
export {WT};
export const loadModels = () =>
  Promise.all([
    ...Object.entries(MODEL_URL).map(([k, url]) => loadGLB(url, r => (PM[k] = r))),
    loadEnemyModels()
  ]);
// skin = مفتاح السكن (data.js › SKINS)؛ 'gray'/فارغ = الأصلي
export function mkJet(kind, color, player, skin) {
  const tint = skin && SKIN_DEFS[skin] ? skin : null;
  if (player && PM[kind]) {
    // طائرة اللاعب = النموذج الحقيقي (GLB حسب kind)
    const f = PFL[kind],
      m = holder();
    m.add(tint ? skinModel(kind, tint) : PM[kind].clone(true));
    m.userData.fl = flames(m, f.xs, f.z, true, f.sc, false, f.y, f.fc);
    return m;
  }
  // طائرة لاعب بلا GLB محمّل (kind>2): نرجع لأحد المجسمات البرمجية الثلاثة بدل الانهيار
  kind %= 3;
  // v26.2.26 (بند #16): مقاتلات العدو HD (e_jet0/1/2.glb)؛ لو لم تُحمَّل نرجع للمجسم البرمجي أدناه
  if (!player && hasEM('jet' + kind)) {
    const h = holder();
    h.add(mkEM('jet' + kind, color, color === 0xd4af37 ? 0.6 : 0.3));
    h.userData.fl = flames(h, kind === 1 || kind === 2 ? [-0.85, 0.85] : [0], 6.7, false, 1, false);
    return h;
  }
  // v26.2.2 (بند #1): مقاتلات العدو = المجسم البرمجي الخاص بها (أدناه) وليس نموذج F-35؛ فتختلف عن طائرات اللاعب (GLB)
  const g = holder(),
    m = stdm(player && tint ? SKIN_DEFS[tint].c[0] : color, 0.55, 0.4),
    d = stdm(0x1b2027, 0.3, 0.6),
    gl = mkm(
      'glass',
      () =>
        new THREE.MeshStandardMaterial({
          color: 0x0b1824,
          emissive: 0x1d4a78,
          emissiveIntensity: 0.7,
          metalness: 0.95,
          roughness: 0.1
        })
    );
  g.add_(FUS(), m);
  const W = geo('w' + kind, () => planform(WP[kind], 0.16)),
    T = geo('tail', () =>
      planform(
        [
          [0.9, 3.8],
          [3, 5.6],
          [3, 6.4],
          [0.9, 6.4]
        ],
        0.1
      )
    );
  for (const s of [-1, 1]) {
    g.add_(W, m).scale.x = s;
    g.add_(T, m).scale.x = s;
    g.add_(
      geo('fin' + kind, () => new THREE.BoxGeometry(0.14, 2.3 + kind * 0.3, 1.9)),
      m,
      s * (1.15 + kind * 0.15),
      1.4,
      4.7,
      0,
      0,
      -s * (kind === 1 ? 0 : 0.4 - kind * 0.03)
    );
    g.add_(
      geo('intake', () => new THREE.BoxGeometry(0.8, 0.8, 2.6)),
      d,
      s,
      -0.45,
      -1.6
    );
    g.add_(
      geo('nav', () => new THREE.SphereGeometry(0.14, 6, 4)),
      basic(s < 0 ? 0xff2222 : 0x22ff66),
      s * [4.8, 5.4, 5.6][kind],
      0,
      2.2
    );
    if (kind === 2)
      g.add_(
        geo('canard', () => new THREE.BoxGeometry(2.2, 0.08, 1.1)),
        m,
        s * 1.9,
        0.1,
        -3.4,
        0,
        s * 0.3,
        0
      );
    if (player)
      g.add_(
        geo('pyl', () => new THREE.CylinderGeometry(0.16, 0.16, 2.6, 6).rotateX(Math.PI / 2)),
        stdm(0xdde3ea, 0.3, 0.5),
        s * 2.6,
        -0.35,
        1.4
      );
  }
  g.add_(
    geo('can', () => new THREE.SphereGeometry(0.85, 12, 10)),
    gl,
    0,
    0.8,
    -2.6
  ).scale.set(0.75, 0.7, 2.1);
  g.add_(
    geo('pitot', () => new THREE.CylinderGeometry(0.04, 0.04, 1.4, 4).rotateX(Math.PI / 2)),
    d,
    0,
    0,
    -8.2
  );
  g.userData.fl = flames(g, kind === 0 ? [0] : [-0.85, 0.85], 6.7, player);
  return g;
}
