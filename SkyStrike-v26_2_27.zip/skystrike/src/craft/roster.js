/* ملف تعريف طائرات اللاعب (بند #6): لكل kind نموذج GLB + لهب العادم + نقطة طرف الجناح.
   إضافة طائرة = سطر هنا (+ ملف GLB + مدخل PLANES + نصوص + صوت محرك)؛ يفحصها test_roster.mjs.
   روابط new URL لازم تكون نصوصاً ثابتة (literal) حتى ينسخ Vite ملفات GLB للبناء. */
// xs مواضع المحركات ، z مكان الفوهة ، sc حجم اللهب ، y الارتفاع ، fc لون اللهب ، wt طرف الجناح (لخطوط البخار)
export const PFL = {
  0: {xs: [0], z: 6.7, sc: 0.9, y: 0.07, fc: 0xff8a2f, wt: {x: 6.3, y: 0.09, z: 1.7}},
  1: {xs: [-0.7, 0.7], z: 7.2, sc: 0.7, y: -1.15, fc: 0xffb347, wt: {x: 5.4, y: -1.04, z: 5.5}},
  2: {xs: [-0.7, 0.7], z: 7.45, sc: 0.75, y: -1.15, fc: 0x7fc4ff, wt: {x: 6.15, y: -1.14, z: 5.5}},
  // 3–6 (v26.2.13): مقاسة من نماذج f16/a10/f14/f22 (مركز النموذج على محور الجسم مثل f35)
  3: {xs: [0], z: 6.95, sc: 0.85, y: 0, fc: 0xffa040, wt: {x: 5.5, y: 0.09, z: 0.8}},
  4: {xs: [-1.6, 1.6], z: 6.15, sc: 0.7, y: 0.94, fc: 0xff9a3c, wt: {x: 6.5, y: 0.17, z: 0.5}},
  5: {xs: [-1.1, 1.1], z: 7.65, sc: 0.65, y: -1.25, fc: 0xffb347, wt: {x: 6, y: -1.1, z: 0.85}},
  6: {xs: [-1, 1], z: 7.25, sc: 0.65, y: -1.03, fc: 0x9fd0ff, wt: {x: 5.75, y: -0.85, z: 1.3}}
};
export const WT = Object.fromEntries(Object.entries(PFL).map(([k, f]) => [k, f.wt]));
// رابط نموذج GLB لكل kind (0=F-35 ، 1=MiG ، 2=Su-57 ، 3=F-16 ، 4=A-10 ، 5=F-14 ، 6=F-22)
export const MODEL_URL = {
  0: new URL('../models/f35.glb', import.meta.url).href,
  1: new URL('../models/mig29.glb', import.meta.url).href,
  2: new URL('../models/su57.glb', import.meta.url).href,
  3: new URL('../models/f16.glb', import.meta.url).href,
  4: new URL('../models/a10.glb', import.meta.url).href,
  5: new URL('../models/f14.glb', import.meta.url).href,
  6: new URL('../models/f22.glb', import.meta.url).href
};
