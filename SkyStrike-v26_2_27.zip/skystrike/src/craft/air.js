/* مجسمات العدو الجوية: قاذفة، هيلوكبتر، زعماء، مسيّرة (v26.2.11: خرج من jets.js). */
import * as THREE from 'three';
import {hasEM, mkEM} from '../emodels.js';
import {geo, stdm, basic, planform, holder, flames} from './common.js';
import {mkJet} from './fighters.js';
export function mkBomber() {
  const g = holder(),
    m = stdm(0x59616b, 0.5, 0.5),
    d = stdm(0x252a30, 0.4, 0.6);
  g.add_(
    geo('bf', () => new THREE.CylinderGeometry(2.4, 2.4, 26, 12).rotateX(Math.PI / 2)),
    m
  );
  g.add_(
    geo('bn', () => new THREE.ConeGeometry(2.4, 7, 12).rotateX(-Math.PI / 2)),
    m,
    0,
    0,
    -16.5
  );
  g.add_(
    geo('bt', () => new THREE.ConeGeometry(2.4, 9, 12).rotateX(Math.PI / 2)),
    m,
    0,
    0,
    17.5
  );
  g.add_(
    geo('bcan', () => new THREE.SphereGeometry(1.5, 10, 8)),
    stdm(0x0b1824, 0.9, 0.1),
    0,
    1.8,
    -10
  ).scale.set(0.9, 0.7, 1.6);
  const W = geo('bw', () =>
      planform(
        [
          [2, -2],
          [18, 5],
          [18, 8],
          [2, 9]
        ],
        0.5
      )
    ),
    T = geo('bwt', () =>
      planform(
        [
          [1.5, 12],
          [7, 16],
          [7, 18],
          [1.5, 18.5]
        ],
        0.25
      )
    );
  for (const s of [-1, 1]) {
    g.add_(W, m).scale.x = s;
    g.add_(T, m).scale.x = s;
    for (const x of [6, 11])
      g.add_(
        geo('bnac', () => new THREE.CylinderGeometry(1, 1.1, 5, 8).rotateX(Math.PI / 2)),
        d,
        s * x,
        -0.9,
        3.5 - (x > 8 ? 2 : 0)
      );
  }
  g.add_(
    geo('bfin', () => new THREE.BoxGeometry(0.4, 7, 4)),
    m,
    0,
    4.5,
    16
  );
  g.userData.fl = flames(g, [-11, -6, 6, 11], 6.5, false, 0.8).map(f => {
    f.position.y = -0.9;
    return f;
  });
  g.scale.setScalar(1.15);
  return g;
}
export function mkHeli() {
  if (hasEM('heli')) {
    // نموذج GLB: rotor = الرئيسية (تدور حول Y) ، rotor2 = الذيل (حول X)
    const g = mkEM('heli');
    g.userData.rotor = g.getObjectByName('rotor') || new THREE.Group();
    g.userData.rotor2 = g.getObjectByName('rotor2');
    g.userData.fl = [];
    return g;
  }
  const g = holder(),
    m = stdm(0x3d4a3a, 0.4, 0.55),
    d = stdm(0x1a1f1a, 0.3, 0.6);
  g.add_(
    geo('hb', () => new THREE.SphereGeometry(2.2, 12, 9)),
    m
  ).scale.set(1, 1, 1.8);
  g.add_(
    geo('hc', () => new THREE.SphereGeometry(1.5, 10, 8)),
    stdm(0x0b1824, 0.9, 0.1),
    0,
    0.5,
    -2.8
  ).scale.set(0.9, 0.8, 1.1);
  g.add_(
    geo('ht', () => new THREE.CylinderGeometry(0.35, 0.6, 9, 6).rotateX(Math.PI / 2)),
    m,
    0,
    0.4,
    7
  );
  g.add_(
    geo('hf', () => new THREE.BoxGeometry(0.2, 2.2, 1.4)),
    m,
    0,
    1.4,
    10.6
  );
  for (const s of [-1, 1]) {
    g.add_(
      geo('hs', () => new THREE.BoxGeometry(0.2, 0.2, 5)),
      d,
      s * 1.7,
      -2.3,
      0
    );
    g.add_(
      geo('hw', () => new THREE.BoxGeometry(2.4, 0.2, 0.8)),
      m,
      s * 2.4,
      -0.4,
      -0.4
    );
  }
  const rotor = new THREE.Group();
  rotor.position.y = 2.6;
  rotor.add(
    new THREE.Mesh(
      geo('hr', () => new THREE.BoxGeometry(16, 0.08, 0.7)),
      basic(0x222222, 0.55)
    )
  );
  const r2 = new THREE.Mesh(
    geo('hr', () => new THREE.BoxGeometry(16, 0.08, 0.7)),
    basic(0x222222, 0.55)
  );
  r2.rotation.y = Math.PI / 2;
  rotor.add(r2);
  g.add(rotor);
  g.userData.rotor = rotor;
  g.userData.fl = [];
  return g;
}
export function mkBoss(id) {
  let g;
  if (id === 'fortress') {
    // القلعة الطائرة: قاذفة عملاقة بقلب أحمر
    g = mkBomber();
    g.scale.setScalar(3);
    g.add_(
      geo('core', () => new THREE.SphereGeometry(0.9, 10, 8)),
      basic(0xff3322),
      0,
      3.2,
      -5
    ).scale.setScalar(2.2);
    for (const s of [-1, 1])
      g.add_(
        geo('fpod', () => new THREE.BoxGeometry(1.2, 1.2, 6)),
        stdm(0x15181d, 0.4, 0.5),
        s * 9,
        -1.8,
        -1
      );
  } else if (id === 'phantom') {
    // الشبح: مقاتلة سوداء بقلب أزرق
    g = mkJet(2, 0x14161c, false);
    g.scale.setScalar(3);
    g.add_(
      geo('core', () => new THREE.SphereGeometry(0.9, 10, 8)),
      basic(0x55ccff),
      0,
      1.3,
      2
    );
  } else {
    // الصقر الأحمر (الأصلي)
    g = mkJet(2, 0x2c313b, false);
    g.scale.setScalar(3.4);
    g.add_(
      geo('core', () => new THREE.SphereGeometry(0.9, 10, 8)),
      basic(0xff3322),
      0,
      1.3,
      2
    );
    for (const s of [-1, 1])
      g.add_(
        geo('pod', () => new THREE.BoxGeometry(0.7, 0.7, 3)),
        stdm(0x15181d, 0.4, 0.5),
        s * 3.5,
        -0.6,
        0
      );
  }
  return g;
}
export function mkDrone() {
  // مسيّرة انتحارية صغيرة بعين حمراء
  if (hasEM('drone')) {
    // نموذج GLB مصبوغ بالأحمر (المروحة الدافعة بالخلف +Z)
    const g = holder();
    g.add(mkEM('drone', 0x8a2e2e, 0.5));
    g.userData.fl = flames(g, [0], 4.2, false, 0.35, false, 0, 0xff3a3a);
    return g;
  }
  const g = holder(),
    m = stdm(0x3a2226, 0.5, 0.4);
  g.add_(
    geo('dr_b', () => new THREE.SphereGeometry(1, 10, 8)),
    m
  ).scale.set(0.8, 0.5, 2.2);
  const W = geo('dr_w', () =>
    planform(
      [
        [0.6, -0.6],
        [4, 1.2],
        [4, 2],
        [0.6, 2.2]
      ],
      0.1
    )
  );
  for (const s of [-1, 1]) g.add_(W, m).scale.x = s;
  g.add_(
    geo('dr_e', () => new THREE.SphereGeometry(0.45, 8, 6)),
    basic(0xff2a2a),
    0,
    0.3,
    -1.9
  );
  g.userData.fl = flames(g, [0], 2.4, false, 0.35, false, 0, 0xff3a3a);
  return g;
}
