/* وضع الاختبار (للمطوّر فقط): يعطي مليون عملة ومليون جوهرة ويفتح كل مهام الحملة ويتخطى الجولة التعليمية.
   CHEAT = false بالنسخة الرسمية دائماً. يُفعَّل فقط بنسخة الاختبار (zip باسم -TEST). يُطبَّق عند كل تشغيل
   (يرفع الرصيد إلى المليون فقط إن كان أقل، فلا يمحو ما تملكه). الطائرات/السكنات/الترقيات تُشترى بالرصيد (لاختبار المتجر). */
export const CHEAT = false;
export const CHEAT_AMOUNT = 1000000;
export function applyCheat(S, campLen) {
  S.coins = Math.max(S.coins | 0, CHEAT_AMOUNT);
  S.gems = Math.max(S.gems | 0, CHEAT_AMOUNT);
  S.cp = Math.max(S.cp | 0, campLen);
  S.tut = 1;
  return S;
}
