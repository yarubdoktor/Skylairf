/* «حماية المدينة» (بند #5 — night، مهمة c3، 4 موجات، نمط defend): 4 أحياء، كل موجة تهاجم حياً مختلفاً، من الموجة 3 تأتي
   القاذفات من جهتين متعاكستين. مدفعية المدينة تضعف القاذفات القريبة (تشعرك أنك جزء من دفاع)، وكشّافات تمسح السماء. */
import * as THREE from 'three';
import {scene, world, V} from '../core.js';
import {W} from '../state.js';
import {rnd} from '../util.js';
import {t} from '../i18n.js';
import {banner} from '../ui.js';
import {addAir} from '../spawn.js';
import {boom, removeEnemy} from '../combat.js';
import {checkClear} from '../waves.js';
import {airAround} from './common.js';
import {NIGHT, districts, nightWave} from './plans.js';

export function createNight() {
  const op = {d: null, lights: null, spin: []};
  op.waves = true; // التقدّم بالموجات (waves.clearWave)
  function buildLights() {
    const geo = new THREE.CylinderGeometry(5, 9, 700, 10, 1, true),
      mat = new THREE.MeshBasicMaterial({
        color: 0xcfe6ff,
        transparent: true,
        opacity: 0.16,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide
      });
    op.lights = new THREE.Group();
    op.d.forEach((q, i) => {
      const pivot = new THREE.Group(),
        tilt = new THREE.Group(),
        beam = new THREE.Mesh(geo, mat);
      pivot.position.set(q.x, Math.max(world.ground(q.x, q.z), 0), q.z);
      pivot.rotation.y = i * 1.6;
      tilt.rotation.x = 0.5 + (i % 2) * 0.2;
      beam.position.y = 350;
      tilt.add(beam);
      pivot.add(tilt);
      op.lights.add(pivot);
      op.spin.push(pivot);
    });
    scene.add(op.lights);
  }
  op.spawn = w => {
    const G = W.G,
      pl = nightWave(w);
    if (!op.d) {
      const c = G.obj || {x: 0, z: 0};
      op.d = districts(c.x, c.z);
      buildLights();
    }
    const b = op.d[pl.district],
      a0 = rnd(0, 6.28);
    G.obj = {x: b.x, z: b.z};
    if (G.beacon) G.beacon.position.set(b.x, Math.max(world.ground(b.x, b.z), 0) + 0.2, b.z);
    for (let i = 0; i < pl.bombers; i++) {
      const a = a0 + (i % pl.fronts) * Math.PI + rnd(-0.25, 0.25),
        r = rnd(2000, 2400),
        x = b.x + Math.cos(a) * r,
        z = b.z + Math.sin(a) * r;
      addAir('bomber', V(x, Math.max(world.ground(x, z) + 90, rnd(260, 300)), z), w);
    }
    for (let i = 0; i < pl.jets; i++) addAir('jet', airAround(b.x, b.z, 1600, 2200, 150, 260), w);
    for (let i = 0; i < pl.heli; i++) addAir('heli', airAround(b.x, b.z, 900, 1300, 100, 180), w);
    for (let i = 0; i < pl.drones; i++) addAir('drone', airAround(b.x, b.z, 1200, 1600, 150, 240), w);
    banner(t('wave') + ' ' + w + ' · ' + t('op_district', {a: pl.district + 1}));
  };
  op.update = dt => {
    const G = W.G;
    for (const p of op.spin) p.rotation.y += dt * 0.45;
    if (G.dead || G.win || !G.obj) return;
    for (const e of [...W.enemies]) {
      if (e.kind !== 'bomber') continue;
      const q = e.g.position;
      if (Math.hypot(q.x - G.obj.x, q.z - G.obj.z) > NIGHT.aaRange) continue;
      e.hp -= NIGHT.aaDps * dt; // مدفعية المدينة
      if (e.hp <= 0) {
        boom(q, 26);
        removeEnemy(e);
        checkClear();
      }
    }
  };
  op.dispose = () => {
    if (!op.lights) return;
    scene.remove(op.lights);
    const m = op.spin[0]?.children[0]?.children[0];
    if (m) {
      m.geometry.dispose();
      m.material.dispose();
    }
    op.lights = null;
    op.spin.length = 0;
  };
  return op;
}
