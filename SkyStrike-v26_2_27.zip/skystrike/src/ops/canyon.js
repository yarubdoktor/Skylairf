/* «اختراق الوادي» (بند #5 — canyon، مهمة c5): طيران منخفض عبر حلقات تتبع قاع الوادي، مدافع على الجروف تطلق من
   فوقك، مقاتلات اعتراض تلحقك من الخلف، وبآخر الوادي مستودع محروس تدمّره للفوز. المنطق الصرف بـ canyon_path.js. */
import * as THREE from 'three';
import {scene, world} from '../core.js';
import {W, P} from '../state.js';
import {rnd} from '../util.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';
import {banner} from '../ui.js';
import {addGround, landPos} from '../spawn.js';
import {winOp, ambush} from './common.js';
import {CANYON, buildRoute, cliffSpot, passGate, routeLen, parTime, timeBonus, fwd} from './canyon_path.js';

const DIFF = 3, // مستوى الصعوبة (يضرب صحة الأعداء مثل مرحلة 3)
  AHEAD = 3, // كم حلقة قدّامك تُنشأ مدافعها (حتى لا تُنشأ كلها دفعة واحدة على 5 كم)
  AMBUSH = {3: ['jet', 'jet'], 6: ['jet', 'jet', 'ace'], 8: ['jet', 'jet']}; // مقاتلات تظهر خلفك عند تجاوز الحلقة

export function createCanyon() {
  const op = {
    gates: [],
    i: 0, // الحلقة التالية
    made: 0, // لحد أي حلقة أُنشئت مدافعها
    depot: null,
    prev: new THREE.Vector3(),
    t0: 0,
    par: 0,
    group: null,
    rings: []
  };
  const n = () => op.gates.length;
  function buildRings() {
    const geo = new THREE.TorusGeometry(CANYON.r, 2.6, 8, 40);
    op.group = new THREE.Group();
    for (let j = 0; j < 3; j++) {
      const m = new THREE.MeshBasicMaterial({
        color: j ? 0x2a7fa0 : 0x5fd8ff,
        transparent: true,
        opacity: j ? 0.45 : 0.95,
        blending: THREE.AdditiveBlending,
        depthWrite: false
      });
      const r = new THREE.Mesh(geo, m);
      op.group.add(r);
      op.rings.push(r);
    }
    scene.add(op.group);
  }
  function placeRings() {
    op.rings.forEach((r, j) => {
      const g = op.gates[op.i + j];
      r.visible = !!g;
      if (g) {
        r.position.set(g.x, g.y, g.z);
        r.rotation.y = g.yaw + Math.PI;
      }
    });
  }
  function target() {
    const G = W.G,
      g = op.gates[op.i] || op.depot?.g.position;
    G.obj = g ? {x: g.x, z: g.z} : null;
  }
  function defenders(upto) {
    for (; op.made <= Math.min(upto, n() - 1); op.made++) {
      const k = op.made,
        kinds = ['turret'];
      if (k >= 4) kinds.push('turret');
      if (k % 3 === 0) kinds.push('flak');
      if (k === n() - 3) kinds.push('sam');
      for (const kind of kinds) {
        const c = cliffSpot(world.ground, op.gates[k], rnd);
        if (c) addGround(kind, c.x, c.z, c.h, DIFF, k);
      }
    }
  }
  function finalPhase() {
    const g = op.gates[n() - 1],
      [dx, dz] = fwd(g.yaw),
      cx = g.x + dx * 480,
      cz = g.z + dz * 480,
      c = landPos(cx, cz, 320) || landPos(cx, cz, 900, 200) || {x: cx, z: cz, h: world.ground(cx, cz)};
    op.depot = addGround('depot', c.x, c.z, c.h, DIFF, 0);
    for (let k = 0; k < 3; k++) {
      const q = landPos(c.x, c.z, 190);
      if (q) addGround('turret', q.x, q.z, q.h, DIFF, k);
    }
    for (let k = 0; k < 2; k++) {
      const q = landPos(c.x, c.z, 200);
      if (q) addGround(k ? 'sam' : 'flak', q.x, q.z, q.h, DIFF, k);
    }
    banner(t('op_final'));
    sfx('alarm');
  }
  op.spawn = () => {
    const G = W.G,
      p = P.g.position;
    op.gates = buildRoute(world.ground, p.x, p.z, P.yaw, CANYON, world.cfg.limit || 12000);
    op.par = parTime(routeLen(p.x, p.z, op.gates), P.speed);
    op.prev.copy(p);
    op.t0 = G.t;
    buildRings();
    placeRings();
    defenders(AHEAD);
    target();
    banner(t('op_cny_go'));
  };
  op.update = dt => {
    const G = W.G;
    if (G.dead || G.win || !op.gates.length) return;
    const p = P.g.position;
    if (op.rings[0]) op.rings[0].scale.setScalar(1 + Math.sin(G.t * 5) * 0.04);
    const g = op.gates[op.i];
    if (g && passGate(op.prev, p, g)) {
      op.i++;
      G.score += 120;
      G.coins += 12;
      sfx('wave');
      if (AMBUSH[op.i]) ambush(AMBUSH[op.i], DIFF);
      defenders(op.i + AHEAD);
      placeRings();
      if (op.i >= n()) finalPhase();
      else banner(t('op_gate', {a: op.i, b: n()}));
      target();
    }
    op.prev.copy(p);
    if (op.depot && !W.enemies.includes(op.depot)) {
      winOp(timeBonus(G.t - op.t0, op.par));
    }
  };
  op.progress = () => (op.depot ? 'TARGET' : `GATE ${op.i}/${n()}`);
  op.dispose = () => {
    if (op.group) {
      scene.remove(op.group);
      op.rings[0]?.geometry.dispose();
      for (const r of op.rings) r.material.dispose();
      op.group = null;
      op.rings.length = 0;
    }
  };
  return op;
}
