/* «اصطياد النخبة» (بند #5 — arctic، مهمة c4، 5 موجات، نمط survive): بلا أرضيات ولا مسيّرات، مبارزات مع طيارين
   نخبة بأسماء نداء (FROST-1…)؛ إسقاط كل واحد يعطي مكافأة وترميم خفيف، والموجة الأخيرة مع زعيم الصقر الأحمر.
   الأرقام بـ plans.js. */
import {W, P} from '../state.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';
import {banner} from '../ui.js';
import {addAir} from '../spawn.js';
import {bossFor} from '../enemies.js';
import {airAround, aliveIn} from './common.js';
import {arcticWave, callsign} from './plans.js';

export function createArctic() {
  const op = {aces: [], n: 0};
  op.waves = true; // التقدّم بالموجات (waves.clearWave)
  op.spawn = w => {
    const pl = arcticWave(w),
      p = P.g.position;
    for (let i = 0; i < pl.aces; i++) {
      const e = addAir('ace', airAround(p.x, p.z, 700, 1100, 120, 260), w);
      e.cs = callsign(op.n++);
      op.aces.push(e);
    }
    for (let i = 0; i < pl.jets; i++) addAir('jet', airAround(p.x, p.z, 700, 1100, 120, 260), w);
    if (pl.boss) {
      addAir('boss', airAround(p.x, p.z, 1100, 1300, 260, 320), w);
      banner(t('boss') + ' — ' + t('bn_' + bossFor(w).id));
      sfx('alarm');
    } else banner(t('wave') + ' ' + w + ' · ' + t('op_aces', {n: pl.aces}));
  };
  op.update = () => {
    const G = W.G;
    if (G.dead || G.win) return;
    for (const e of op.aces.filter(x => !aliveIn(x))) {
      op.aces.splice(op.aces.indexOf(e), 1);
      G.coins += 50;
      P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.08);
      banner(t('op_ace_down', {c: e.cs, n: op.aces.length}));
    }
  };
  op.dispose = () => {
    op.aces.length = 0;
  };
  return op;
}
