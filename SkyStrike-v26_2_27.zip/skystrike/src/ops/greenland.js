/* «حرب على 3 مراحل» (بند #5 — greenland، مهمة c6، 10 موجات، نمط survive): سيادة جوية (1–5، زعيم بالخامسة) ثم ضرب العمق
   (6–10: صواريخ SAM وflak ومدافع، نخبة، زعيم ثانٍ بالعاشرة). الرادار يدلّك على أقرب دفاع أرضي. الأرقام بـ plans.js. */
import {W, P} from '../state.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';
import {banner} from '../ui.js';
import {addAir} from '../spawn.js';
import {bossFor} from '../enemies.js';
import {airAround, place, nearest} from './common.js';
import {greenWave} from './plans.js';

export function createGreenland() {
  const op = {tk: 0};
  op.waves = true; // التقدّم بالموجات (waves.clearWave)
  op.spawn = w => {
    const pl = greenWave(w),
      p = P.g.position;
    for (let i = 0; i < pl.jets; i++) addAir(i < pl.ace ? 'ace' : 'jet', airAround(p.x, p.z, 700, 1100, 120, 260), w);
    for (let i = 0; i < pl.heli; i++) addAir('heli', airAround(p.x, p.z, 650, 950, 100, 200), w);
    for (let i = 0; i < pl.drones; i++) addAir('drone', airAround(p.x, p.z, 600, 900, 100, 240), w);
    ['sam', 'flak', 'turret'].forEach(k => {
      for (let i = 0; i < pl[k]; i++) place(k, p.x, p.z, 1300, w, i);
    });
    if (pl.boss) {
      addAir('boss', airAround(p.x, p.z, 1100, 1300, 260, 320), w);
      banner(t('boss') + ' — ' + t('bn_' + bossFor(w).id));
      sfx('alarm');
    } else if (w === 1 || w === 6) banner(t('op_green_' + pl.phase));
    else banner(t('wave') + ' ' + w);
  };
  op.update = dt => {
    const G = W.G;
    op.tk -= dt;
    if (op.tk > 0 || G.dead || G.win) return;
    op.tk = 1;
    const n = nearest(
      W.enemies.filter(e => e.ground),
      P.g.position
    );
    G.obj = n ? {x: n.g.position.x, z: n.g.position.z} : null;
  };
  op.dispose = () => {};
  return op;
}
