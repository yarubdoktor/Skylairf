/* اختيار مواقع على اليابسة (بند #5، دوال صرفة): جزر للجزر، بداية/نهاية طريق القافلة.
   H(x,z) ارتفاع التضاريس، lvl مستوى الماء. */
const SLOPE = (H, x, z, h) => Math.hypot(H(x + 8, z) - h, H(x, z + 8) - h);

// موقع يابسة مسطح على جزيرة حقيقية (ليس صخرة وحيدة): ≥ 6 من 8 نقاط حوله على بعد 60 م فوق الماء
export function landSite(H, lvl, x, z) {
  const h = H(x, z);
  if (h < lvl + 6 || SLOPE(H, x, z, h) > 4) return null;
  let dry = 0;
  for (let k = 0; k < 8; k++) if (H(x + Math.cos(k * 0.785) * 60, z + Math.sin(k * 0.785) * 60) > lvl + 2) dry++;
  return dry >= 6 ? {x, z, h} : null;
}
// n مواقع بقطاعات زاوية مختلفة حول (cx,cz)، كل اثنين يبعدان ≥ sep. يوسّع البحث تدريجياً؛ قد يُرجع أقل من n
export function pickSites(H, lvl, cx, cz, n, rnd, {rMin, rMax, sep}) {
  const out = [],
    a0 = rnd(0, Math.PI * 2);
  for (let i = 0; i < n; i++) {
    for (let k = 0; k < 160; k++) {
      const grow = 1 + k / 160,
        a = a0 + ((i + rnd(0.1, 0.9)) / n) * Math.PI * 2,
        r = rnd(rMin, rMax * grow),
        s = landSite(H, lvl, cx + Math.cos(a) * r, cz + Math.sin(a) * r);
      if (s && out.every(o => Math.hypot(o.x - s.x, o.z - s.z) >= sep)) {
        out.push(s);
        break;
      }
    }
  }
  return out;
}
// نقطة يابسة بين rMin..rMax من (cx,cz) لا تحتاج أن تكون جزيرة (للصحراء)
export function findLand(H, lvl, cx, cz, rMin, rMax, rnd, tries = 80) {
  for (let i = 0; i < tries; i++) {
    const a = rnd(0, Math.PI * 2),
      r = rnd(rMin, rMax),
      x = cx + Math.cos(a) * r,
      z = cz + Math.sin(a) * r,
      h = H(x, z);
    if (h >= lvl + 3 && SLOPE(H, x, z, h) <= 5) return {x, z, h};
  }
  return null;
}
