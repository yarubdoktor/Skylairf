/* «تحرير الجزر» (بند #5 — island، مهمة c1): 3 قواعد صغيرة على جزر مختلفة تدمّرها بأي ترتيب؛ تعليمية فدفاعاتها خفيفة،
   ودوريات مقاتلات تأتي خلفك كل فترة. المواقع من sites.js. */
import {world} from '../core.js';
import {W, P} from '../state.js';
import {rnd} from '../util.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';
import {banner} from '../ui.js';
import {addGround, landPos} from '../spawn.js';
import {winOp, ambush, nearest, place, mkBeam, rmBeam, aliveIn} from './common.js';
import {pickSites} from './sites.js';
import {ISLAND, islandDefense} from './plans.js';

export function createIsland() {
  const op = {depots: [], beams: [], done: 0, patrolT: 0, patrols: 0};
  op.spawn = () => {
    const p = P.g.position,
      lvl = world.cfg.water ? world.cfg.water.level : -1e9,
      sites = pickSites(world.H, lvl, p.x, p.z, ISLAND.sites, rnd, ISLAND);
    while (sites.length < ISLAND.sites) sites.push(landPos(p.x, p.z, 2400, 200) || {x: p.x + 1500, z: p.z, h: 5});
    sites.forEach((s, i) => {
      const d = addGround('depot', s.x, s.z, s.h, ISLAND.diff, 0),
        df = islandDefense(i);
      op.depots.push(d);
      op.beams.push(mkBeam(s.x, s.h, s.z));
      for (let k = 0; k < df.turrets; k++) place('turret', s.x, s.z, 150, ISLAND.diff, k);
      for (let k = 0; k < df.sam; k++) place('sam', s.x, s.z, 170, ISLAND.diff, k);
    });
    banner(t('op_isle_go'));
  };
  op.update = dt => {
    const G = W.G;
    if (G.dead || G.win) return;
    op.depots.forEach((d, i) => {
      if (op.beams[i] && !aliveIn(d)) {
        rmBeam(op.beams[i]);
        op.beams[i] = null;
        op.done++;
        sfx('wave');
        if (op.done < op.depots.length) banner(t('op_isle', {a: op.done, b: op.depots.length}));
      }
    });
    const alive = op.depots.filter(aliveIn),
      n = nearest(alive, P.g.position);
    G.obj = n ? {x: n.g.position.x, z: n.g.position.z} : null;
    if (!alive.length) return winOp();
    op.patrolT += dt;
    if (op.patrolT >= ISLAND.patrolEvery && op.patrols < ISLAND.patrolMax) {
      op.patrolT = 0;
      op.patrols++;
      ambush(['jet', 'jet'], ISLAND.diff);
    }
  };
  op.progress = () => `ISLES ${op.done}/${op.depots.length}`;
  op.dispose = () => {
    for (const b of op.beams) if (b) rmBeam(b);
    op.beams.length = 0;
  };
  return op;
}
