/* «قافلة» (بند #5 — desert، مهمة c2، 3 مراحل): قافلة آليات تتحرك نحو القاعدة، تدمّرها قبل أن تصل. إن وصل منها العدد
   المسموح (leakMax) تسقط المهمة. المرحلة تكبر (آليات أكثر + مرافقون + هليكوبتر). المسار من convoy_path.js. */
import {world, V} from '../core.js';
import {W, P} from '../state.js';
import {rnd} from '../util.js';
import {t} from '../i18n.js';
import {banner} from '../ui.js';
import {addAir, addGround, landPos} from '../spawn.js';
import {removeEnemy, baseLost} from '../combat.js';
import {checkClear} from '../waves.js';
import {nearest, mkBeam, rmBeam} from './common.js';
import {buildConvoyRoute, routePoint} from './convoy_path.js';
import {CONVOY, convoyStage} from './plans.js';

export function createConvoy() {
  const op = {route: null, cars: [], leaked: 0, total: 0, beam: null, plan: null};
  const lvl = () => (world.cfg.water ? world.cfg.water.level : -1e9);
  op.waves = true; // التقدّم بين المراحل بنظام الموجات (waves.clearWave)
  op.spawn = st => {
    const p = P.g.position,
      plan = (op.plan = convoyStage(st));
    let r = buildConvoyRoute(world.H, lvl(), p.x, p.z, rnd, CONVOY);
    if (!r) {
      const a = landPos(p.x, p.z, 1800, 200) || {x: p.x + 1500, z: p.z};
      r = {a, b: {x: a.x + CONVOY.length, z: a.z}};
    }
    op.route = r;
    op.cars.length = 0;
    op.leaked = 0;
    op.total = plan.vehicles;
    for (let i = 0; i < plan.vehicles; i++) {
      const s = (plan.vehicles - 1 - i) * CONVOY.gap,
        q = routePoint(r.a, r.b, s),
        kind = i % 4 === 2 && i / 4 < plan.escorts ? 'flak' : 'turret',
        e = addGround(kind, q.x, q.z, world.H(q.x, q.z), st, i);
      e.cv = s;
      e.g.rotation.y = q.yaw;
      op.cars.push(e);
    }
    for (let i = 0; i < plan.heli; i++) addAir('heli', V(r.a.x + rnd(-200, 200), 150, r.a.z + rnd(-200, 200)), st);
    if (op.beam) rmBeam(op.beam);
    op.beam = mkBeam(r.b.x, world.H(r.b.x, r.b.z), r.b.z, 0xff6a3a);
    banner(t('op_convoy', {a: st, b: plan.vehicles}));
  };
  op.update = dt => {
    const G = W.G;
    if (G.dead || G.win || !op.route) return;
    const {a, b} = op.route;
    let live = 0;
    for (const e of op.cars) {
      if (!W.enemies.includes(e)) continue;
      e.cv += CONVOY.speed * dt;
      const q = routePoint(a, b, e.cv);
      if (q.done) {
        removeEnemy(e);
        op.leaked++;
        banner(t('op_leak', {a: op.leaked, b: op.plan.leakMax}));
        continue;
      }
      live++;
      e.g.position.set(q.x, world.H(q.x, q.z), q.z);
      e.g.rotation.y = q.yaw;
    }
    const n = nearest(
      op.cars.filter(e => W.enemies.includes(e)),
      P.g.position
    );
    G.obj = n ? {x: n.g.position.x, z: n.g.position.z} : {x: b.x, z: b.z};
    if (op.leaked >= op.plan.leakMax) {
      G.obj = {x: b.x, z: b.z};
      baseLost();
    } else if (!live && op.cars.length) {
      op.cars.length = 0; // المرحلة انتهت (ما بقي إلا الأعداء الآخرون)
      checkClear();
    }
  };
  op.progress = () => `CONVOY ${op.cars.filter(e => W.enemies.includes(e)).length}/${op.total}`;
  op.dispose = () => {
    if (op.beam) rmBeam(op.beam);
    op.beam = null;
  };
  return op;
}
