/* نشر أساطيل map7 (v26.2.19): سفن حيّة (GLB) على نفس مواقع الأساطيل المرسومة بالخريطة. اختيارية: لا تمنع إنهاء المرحلة
   (e.optional) وتُزال عند بداية المرحلة التالية قبل إعادة نشرها بحسب المرحلة. */
import {world} from '../core.js';
import {addShip} from '../spawn.js';
import {removeEnemy} from '../combat.js';
import {W} from '../state.js';
import {FLEETS, fleetShips, patrolCount} from './plans.js';

const onWater = (x, z) => !world.hasWater() || world.H(x, z) < world.cfg.water.level - 3;
export function clearFleet(list) {
  for (const e of list) if (W.enemies.includes(e)) removeEnemy(e);
  list.length = 0;
}
// يرجع قائمة السفن المنشورة (لتنظيفها بالمرحلة التالية)
export function spawnFleets(st, list = []) {
  const add = (type, x, z, yaw) => {
    const e = addShip(type, x, z, st, yaw);
    e.optional = true;
    list.push(e);
    return e;
  };
  for (const side of ['a', 'b']) {
    const F = FLEETS[side];
    for (const [type, x, z] of fleetShips(side, st)) add(type, x, z, F.yaw);
  }
  const n = patrolCount(st);
  for (let i = 0; i < n; i++) {
    const side = i % 2 ? 'b' : 'a',
      fr = FLEETS[side].ships.find(s => s[0] === 'frigate'),
      o = FLEETS.patrolAt[i],
      x = fr[1] + o[0],
      z = fr[2] + o[1];
    if (onWater(x, z)) add('patrol', x, z, FLEETS[side].yaw);
  }
  return list;
}
