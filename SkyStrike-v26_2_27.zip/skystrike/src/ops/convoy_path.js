/* مسار القافلة (بند #5 — desert): دوال صرفة. الطريق خط مستقيم بنقاط كل step م، نختار الاتجاه الأقل ميلاً. */
import {findLand} from './sites.js';
const stepOf = 150;

export function routeSlope(H, a, b) {
  let m = 0,
    ph = H(a.x, a.z);
  const n = Math.ceil(Math.hypot(b.x - a.x, b.z - a.z) / stepOf);
  for (let i = 1; i <= n; i++) {
    const x = a.x + ((b.x - a.x) * i) / n,
      z = a.z + ((b.z - a.z) * i) / n,
      h = H(x, z);
    m = Math.max(m, Math.abs(h - ph) / stepOf);
    ph = h;
  }
  return m;
}
// يبحث عن (بداية → نهاية) على اليابسة بطول len وميل أقصى maxSlope؛ يُرجع أقل ميل وجده إن لم ينجح الحد
export function buildConvoyRoute(H, lvl, cx, cz, rnd, cfg) {
  let best = null;
  for (let i = 0; i < 40; i++) {
    const a = findLand(H, lvl, cx, cz, cfg.startMin, cfg.startMax, rnd);
    if (!a) continue;
    const ang = rnd(0, Math.PI * 2),
      b = {x: a.x + Math.cos(ang) * cfg.length, z: a.z + Math.sin(ang) * cfg.length};
    if (H(b.x, b.z) < lvl + 3) continue;
    const s = routeSlope(H, a, b);
    if (!best || s < best.slope) best = {a, b, slope: s};
    if (s <= cfg.maxSlope) break;
  }
  return best;
}
// موضع على الطريق بعد مسافة s من البداية (يُقصّ بالطرفين) + اتجاه الحركة yaw (أمام = (-sin, -cos))
export function routePoint(a, b, s) {
  const L = Math.hypot(b.x - a.x, b.z - a.z),
    u = Math.max(0, Math.min(1, s / L)),
    dx = (b.x - a.x) / L,
    dz = (b.z - a.z) / L;
  return {x: a.x + (b.x - a.x) * u, z: a.z + (b.z - a.z) * u, yaw: Math.atan2(-dx, -dz), done: s >= L};
}
