/* «الجبهتان» (بند #5 — map7، مهمة c7، 5 مراحل، نمط assault): القاعدتان (شمال/جنوب، 9 كم بينهما) بآن واحد؛
   كل مرحلة يلزم تدمير مستودع كل قاعدة. إن تأخرت تصلك تعزيزات مقاتلات فوق القاعدة الأبعد (ضغط الجبهة الثانية).
   الأسطول (سفن) ينتظر نماذج GLB. */
import {W, P} from '../state.js';
import {t} from '../i18n.js';
import {banner} from '../ui.js';
import {addAir, addGround, landPos} from '../spawn.js';
import {airAround, place, nearest, aliveIn} from './common.js';
import {TWOFRONT, frontStage} from './plans.js';
import {spawnFleets, clearFleet} from './fleets.js';

export function createTwoFront() {
  const op = {depots: [], t: 0, ships: []};
  op.waves = true; // التقدّم بالمراحل (waves.clearWave)
  op.spawn = st => {
    const fr = frontStage(st);
    op.depots.length = 0;
    op.t = 0;
    clearFleet(op.ships); // سفن المرحلة السابقة الباقية
    TWOFRONT.bases.forEach(([bx, bz], i) => {
      const c = landPos(bx, bz, 300) || landPos(bx, bz, 800, 200) || {x: bx, z: bz, h: 24},
        df = i ? fr.b : fr.a;
      op.depots.push(addGround('depot', c.x, c.z, c.h, st, 0));
      for (let k = 0; k < df.turrets; k++) place('turret', c.x, c.z, 190, st, k);
      for (let k = 0; k < df.sam; k++) place('sam', c.x, c.z, 200, st, k);
      for (let k = 0; k < df.flak; k++) place('flak', c.x, c.z, 200, st, k);
    });
    const [bx, bz] = TWOFRONT.bases[1];
    for (let k = 0; k < fr.jets; k++) addAir(k < fr.ace ? 'ace' : 'jet', airAround(bx, bz, 300, 600, 130, 220), st);
    spawnFleets(st, op.ships);
    banner(t('op_front', {a: st}));
  };
  op.update = dt => {
    const G = W.G;
    if (G.dead || G.win) return;
    const alive = op.depots.filter(aliveIn),
      n = nearest(alive, P.g.position);
    G.obj = n ? {x: n.g.position.x, z: n.g.position.z} : null;
    op.t += dt;
    if (op.t >= TWOFRONT.pressureEvery && alive.length && G.wait <= 0) {
      op.t = 0;
      const dist = e => e.g.position.distanceTo(P.g.position),
        far = alive.reduce((b, e) => (!b || dist(e) > dist(b) ? e : b), null),
        q = far.g.position;
      for (let k = 0; k < 2; k++) addAir('jet', airAround(q.x, q.z, 300, 600, 130, 220), G.wave);
      banner(t('op_pressure'));
    }
  };
  op.dispose = () => {
    op.ships.length = 0;
  };
  return op;
}
