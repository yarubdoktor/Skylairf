/* «اختراق الوادي» (بند #5 — خريطة canyon): الجزء الصرف (بلا three ولا متصفح) فيُختبر بـ node.
   يبني مساراً من حلقات يتبع أخفض أرض (قاع الوادي)، ويحدد أماكن مدافع الجروف، ويفحص مرور الطائرة بالحلقة.
   كل الأرقام هنا بـ CANYON حتى يسهل ضبطها بعد التجربة.
   اتجاه الأمام بالعالم: (-sin yaw, -cos yaw) — مثل ai.js وplayer.js. */
export const CANYON = {
  n: 10, // عدد الحلقات
  step: 520, // المسافة بين حلقتين (م)
  r: 52, // نصف قطر الحلقة = مدى قبول المرور (م)
  lift: 78, // ارتفاع مركز الحلقة فوق أعلى أرض حولها (م) — الطيران المنخفض هو المطلوب
  turn: 0.65, // أقصى انعطاف بين حلقتين (راد)
  drift: 1.2, // أقصى انحراف تراكمي عن الاتجاه الأول (راد)
  bias: 6, // عقوبة الانعطاف (م): قيمة 18 تجعل المسار مستقيماً دائماً على تضاريس canyon (قِيس)، وأقل من 2 يزيده تعرّجاً
  par: 0.78 // زمن «الجائزة» = طول المسار ÷ (سرعة الطائرة × par)
};
const wrapPi = a => Math.atan2(Math.sin(a), Math.cos(a));
export const fwd = a => [-Math.sin(a), -Math.cos(a)];

// متوسط ارتفاع الأرض على قطعة بطول len من (x,z) باتجاه a
export function segMean(ground, x, z, a, len, n = 6) {
  const [dx, dz] = fwd(a);
  let s = 0;
  for (let i = 1; i <= n; i++) s += ground(x + (dx * len * i) / n, z + (dz * len * i) / n);
  return s / n;
}
// ارتفاع مركز الحلقة: أعلى أرض بمركزها وعلى جانبيها (حتى لا تغوص الحلقة بجرف) + lift
export function gateY(ground, x, z, a, cfg = CANYON) {
  const [dx, dz] = fwd(a);
  const hc = ground(x, z),
    hl = ground(x - dz * cfg.r, z + dx * cfg.r),
    hr = ground(x + dz * cfg.r, z - dx * cfg.r);
  return Math.max(hc, hl, hr) + cfg.lift;
}
export function buildRoute(ground, x0, z0, yaw, cfg = CANYON, lim = 12000) {
  const gates = [];
  let x = x0,
    z = z0,
    h = yaw;
  for (let i = 0; i < cfg.n; i++) {
    let bestA = null,
      bestC = Infinity;
    for (let k = -3; k <= 3; k++) {
      const a = h + (k / 3) * cfg.turn;
      if (Math.abs(wrapPi(a - yaw)) > cfg.drift) continue;
      const [dx, dz] = fwd(a);
      if (Math.max(Math.abs(x + dx * cfg.step), Math.abs(z + dz * cfg.step)) > lim) continue;
      const c = segMean(ground, x, z, a, cfg.step) + Math.abs(k) * cfg.bias;
      if (c < bestC) {
        bestC = c;
        bestA = a;
      }
    }
    if (bestA === null) break; // وصل حد الخريطة
    h = bestA;
    const [dx, dz] = fwd(h);
    x += dx * cfg.step;
    z += dz * cfg.step;
    gates.push({x, z, y: gateY(ground, x, z, h, cfg), yaw: h});
  }
  return gates;
}
export const routeLen = (x0, z0, gates) => {
  let L = 0,
    px = x0,
    pz = z0;
  for (const g of gates) {
    L += Math.hypot(g.x - px, g.z - pz);
    px = g.x;
    pz = g.z;
  }
  return L;
};
// مرّت الطائرة بالحلقة؟ أقرب مسافة من مركز الحلقة إلى مسار الفريم (a→b) ≤ r (فلا تفوتها بفريم طويل)
export function passGate(a, b, g, r = CANYON.r) {
  const vx = b.x - a.x,
    vy = b.y - a.y,
    vz = b.z - a.z,
    L = vx * vx + vy * vy + vz * vz;
  let u = L > 0 ? ((g.x - a.x) * vx + (g.y - a.y) * vy + (g.z - a.z) * vz) / L : 0;
  u = Math.max(0, Math.min(1, u));
  const dx = a.x + vx * u - g.x,
    dy = a.y + vy * u - g.y,
    dz = a.z + vz * u - g.z;
  return dx * dx + dy * dy + dz * dz <= r * r;
}
// مكان مدفع قرب الحلقة على أحد الجانبين، أرض شبه مستوية. يفضّل ما هو أعلى من مسار الطيران (يطلق من فوقك)؛
// وإن لم يوجد (تضاريس canyon هضاب منخفضة التباين) يقبل أرضاً بمستوى قاع الوادي — لا يضع مدفعاً بحفرة أخفض منه.
export function cliffSpot(ground, g, rnd, tries = 60) {
  const [dx, dz] = fwd(g.yaw),
    base = g.y - CANYON.lift;
  for (let i = 0; i < tries; i++) {
    const thr = i < tries / 3 ? g.y - 15 : i < (2 * tries) / 3 ? base + 20 : base - 5,
      side = rnd(0, 1) < 0.5 ? -1 : 1,
      d = rnd(150, 360),
      al = rnd(-130, 130),
      x = g.x - dz * d * side + dx * al,
      z = g.z + dx * d * side + dz * al,
      h = ground(x, z);
    if (h < thr) continue;
    if (Math.hypot(ground(x + 8, z) - h, ground(x, z + 8) - h) > 5) continue;
    return {x, z, h};
  }
  return null;
}
export const parTime = (len, speed, cfg = CANYON) => len / (speed * cfg.par);
export const timeBonus = (t, par) => Math.max(0, Math.min(250, Math.round((par - t) * 6)));
