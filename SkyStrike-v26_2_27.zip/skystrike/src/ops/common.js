/* أدوات مشتركة لمهام src/ops/: فوز المهمة، ظهور مقاتلات خلف اللاعب، أقرب هدف. */
import * as THREE from 'three';
import {scene, world, V} from '../core.js';
import {W, P} from '../state.js';
import {rnd} from '../util.js';
import {t} from '../i18n.js';
import {sfx} from '../audio.js';
import {banner} from '../ui.js';
import {addAir, addGround, landPos} from '../spawn.js';
import {fwd} from './canyon_path.js';

// فوز المهمة (نفس ما تفعله waves.clearWave): يُستدعى مرة واحدة
export function winOp(bonus = 0) {
  const G = W.G;
  if (G.win) return;
  G.win = true;
  G.wait = 2.8;
  G.coins += 300 + bonus;
  G.xp += 300;
  banner(t('victory') + (bonus ? ' · ⏱ +' + bonus + '🪙' : ''));
  sfx('win');
}
// مقاتلات تظهر خلف اللاعب (كمين). kinds مثل ['jet','jet','ace']
export function ambush(kinds, diff, dist = 650) {
  const [dx, dz] = fwd(P.yaw),
    p = P.g.position;
  kinds.forEach((kind, j) => {
    const s = (j - (kinds.length - 1) / 2) * 140;
    addAir(kind, V(p.x - dx * dist - dz * s, p.y + 60 + j * 25, p.z - dz * dist + dx * s), diff);
  });
  banner(t('op_ambush'));
  sfx('alarm');
}
export const nearest = (list, p) =>
  list.reduce((b, e) => (!b || e.g.position.distanceToSquared(p) < b.g.position.distanceToSquared(p) ? e : b), null);
// موضع جوي حول (cx,cz) بين r0..r1 وارتفاع y0..y1 (لا يقل عن 90 م فوق الأرض)
export function airAround(cx, cz, r0, r1, y0, y1) {
  const a = rnd(0, 6.28),
    r = rnd(r0, r1),
    x = cx + Math.cos(a) * r,
    z = cz + Math.sin(a) * r;
  return V(x, Math.max(world.ground(x, z) + 90, rnd(y0, y1)), z);
}
// عدو أرضي بمكان صالح قرب (cx,cz) نصف قطر rad؛ يُرجع العدو أو null
export function place(kind, cx, cz, rad, diff, i = 0) {
  const c = landPos(cx, cz, rad);
  return c ? addGround(kind, c.x, c.z, c.h, diff, i) : null;
}
// عمود ضوء يدل على هدف (كالمنارة)
export function mkBeam(x, y, z, color = 0x5fd8ff, h = 420) {
  const m = new THREE.Mesh(
    new THREE.CylinderGeometry(7, 7, h, 12, 1, true),
    new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.25,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide
    })
  );
  m.position.set(x, y + h / 2, z);
  scene.add(m);
  return m;
}
export function rmBeam(m) {
  scene.remove(m);
  m.geometry.dispose();
  m.material.dispose();
}
export const aliveIn = e => W.enemies.includes(e);
