/* مهام الحملة الخاصة بالخرائط (بند #5): كل مهمة ملف بهذا المجلد. تُربط بحقل `op` بـ campaign.js.
   واجهة المهمة (الكائن بـ G.op): spawn(w) يبدأ المهمة/الموجة · update(dt) كل فريم · progress() نص الـHUD (اختياري) ·
   dispose() تنظيف. نوعان: (1) المهمة تنهي نفسها بـ winOp() (canyon, island) · (2) op.waves = true: التقدّم
   بالموجات/المراحل كالمعتاد (waves.clearWave) وspawn(w) يُستدعى لكل موجة. */
import {createCanyon} from './canyon.js';
import {createIsland} from './island.js';
import {createConvoy} from './convoy.js';
import {createNight} from './night.js';
import {createArctic} from './arctic.js';
import {createGreenland} from './greenland.js';
import {createTwoFront} from './twofront.js';

const OPS = {
  canyon: createCanyon,
  island: createIsland,
  convoy: createConvoy,
  night: createNight,
  arctic: createArctic,
  greenland: createGreenland,
  twofront: createTwoFront
};
export const makeOp = id => (OPS[id] ? OPS[id]() : null);
