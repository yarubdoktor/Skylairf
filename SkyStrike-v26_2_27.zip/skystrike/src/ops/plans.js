/* جداول مهام الخرائط (بند #5): أرقام صرفة بلا three تُضبط من هنا بعد التجربة. كل دالة تُرجع تركيبة موجة/مرحلة. */

// ---- arctic «اصطياد النخبة» (c4، 5 موجات): طيارون نخبة بأسماء نداء، والموجة الأخيرة مع زعيم الصقر الأحمر ----
export const CALLSIGNS = ['FROST', 'BLIZZARD', 'ICICLE', 'GLACIER', 'AURORA', 'POLAR', 'TUNDRA', 'HAIL'];
export const arcticWave = w => {
  const boss = w % 5 === 0;
  return {
    aces: boss ? 2 : 1 + (w >> 1), // نخبة: 1،2،2،3 ثم موجة الزعيم 2
    jets: boss ? 0 : Math.min(w, 4), // مقاتلات عادية مرافقة
    boss
  };
};
export const callsign = i => `${CALLSIGNS[i % CALLSIGNS.length]}-${((i / CALLSIGNS.length) | 0) + 1}`;

// ---- greenland «حرب على 3 مراحل» (c6، 10 موجات): سيادة جوية ← ضرب العمق ← الحسم؛ زعيم بالموجتين 5 و10 ----
export const GREEN_PHASES = [
  {id: 'air', from: 1},
  {id: 'deep', from: 6}
];
export const greenPhase = w => (w >= 6 ? 'deep' : 'air');
export function greenWave(w) {
  const boss = w % 5 === 0,
    deep = w >= 6;
  return {
    phase: greenPhase(w),
    boss,
    ace: deep ? Math.min(w - 5, 3) : w >= 3 ? 1 : 0,
    jets: boss ? 0 : Math.min(1 + w, 7),
    heli: boss || w < 2 ? 0 : Math.min(1 + (((w - 2) / 3) | 0), 3),
    drones: boss ? 0 : Math.min(w, 5),
    sam: deep ? Math.min(w - 4, 4) : 0,
    flak: deep ? Math.min(w - 4, 3) : 0,
    turret: deep ? 3 : boss ? 2 : 0
  };
}

// ---- night «حماية المدينة» (c3، 4 موجات): 4 أحياء، قاذفات من جهة أو جهتين، مدفعية صديقة تضعف القاذفات ----
export const NIGHT = {
  radius: 450, // بُعد كل حي عن مركز المدينة (م)
  aaRange: 750, // مدى مدفعية المدينة (م) حول الحي المستهدف
  aaDps: 7, // ضرر المدفعية بالثانية لكل قاذفة داخل المدى
  districts: 4
};
export function districts(cx, cz, cfg = NIGHT) {
  return Array.from({length: cfg.districts}, (_, i) => {
    const a = (i / cfg.districts) * Math.PI * 2 + Math.PI / 4;
    return {x: cx + Math.cos(a) * cfg.radius, z: cz + Math.sin(a) * cfg.radius};
  });
}
export const nightWave = w => ({
  district: (w - 1) % NIGHT.districts,
  bombers: Math.min(1 + w, 6),
  fronts: w >= 3 ? 2 : 1, // جهتان متعاكستان
  jets: Math.min(w, 4),
  heli: w >= 3 ? 1 : 0,
  drones: w >= 4 ? 2 : 0
});

// ---- island «تحرير الجزر» (c1): 3 قواعد بجزر مختلفة بأي ترتيب؛ تعليمية فخفيفة الدفاع ----
export const ISLAND = {
  sites: 3,
  rMin: 900,
  rMax: 2300,
  sep: 700, // أقل مسافة بين جزيرتين
  diff: 1, // مستوى الأعداء (يضرب الصحة)
  patrolEvery: 40, // كل كم ثانية دورية مقاتلات
  patrolMax: 3 // أقصى عدد دوريات
};
export const islandDefense = i => ({turrets: 2 + (i > 1 ? 1 : 0), sam: i === 2 ? 1 : 0});

// ---- desert «قافلة» (c2، 3 مراحل): قافلة آليات متحركة نحو القاعدة؛ إن وصل منها العدد المسموح تسقط المهمة ----
export const CONVOY = {
  length: 3200, // طول الطريق (م)
  speed: 15, // م/ث
  gap: 70, // المسافة بين الآليات
  startMin: 1300,
  startMax: 2000, // بُعد بداية القافلة عن اللاعب
  maxSlope: 0.22
};
export const convoyStage = st => ({vehicles: 4 + st * 2, escorts: st, leakMax: 2, heli: st >= 2 ? st - 1 : 0});

// ---- map7 «الجبهتان» (c7، 5 مراحل): القاعدتان معاً، وضغط تعزيزات إن تأخرت ----
export const TWOFRONT = {
  bases: [
    [0, 4500],
    [0, -4500]
  ],
  pressureEvery: 50
};
export const frontStage = st => ({
  a: {turrets: 2 + st, sam: st, flak: 0},
  b: {turrets: 3 + st, sam: 1 + st, flak: Math.max(0, st - 1)},
  jets: st >= 2 ? st : 0,
  ace: st >= 4 ? 1 : 0
});

/* أساطيل map7 (v26.2.19). المواقع هي مواقع السفن المرسومة أصلاً بالخريطة (tools/convert_map7.py --live-ships)،
   وصناديق تصادمها باقية بالحزمة فالسفن الحيّة تقف فوقها. yaw: 0 = المقدمة −Z (A بالجنوب يواجه الشمال)، π = +Z.
   كل سفينة: [نوع، x، z، أول مرحلة تظهر فيها]. cargo = أعزل (ناقلات وشحن). الأسطول اختياري: لا يمنع إنهاء المرحلة. */
export const FLEETS = {
  a: {
    yaw: 0,
    ships: [
      ['frigate', 3300, 5200, 1],
      ['destroyer', 3100, 5800, 2],
      ['carrier', 3500, 5500, 3],
      ['destroyer', 3900, 5800, 4],
      ['cargo', 3800, 5000, 1],
      ['cargo', 1800, 5400, 1],
      ['cargo', 2000, 5200, 1]
    ]
  },
  b: {
    yaw: Math.PI,
    ships: [
      ['frigate', 3300, -5200, 1],
      ['destroyer', 3100, -5800, 2],
      ['carrier', 3500, -5500, 2],
      ['destroyer', 3900, -5800, 3],
      ['cargo', 3800, -5000, 1]
    ]
  },
  patrolAt: [
    [-260, 120],
    [260, 140],
    [0, -200]
  ], // إزاحات (x,z) حول الفرقاطة لزوارق الدورية؛ عددها = min(مرحلة−1، 3)
  patrolSide: 0.5 // نصف الزوارق على الأسطول A والباقي على B
};
export const fleetShips = (side, st) => FLEETS[side].ships.filter(s => s[3] <= st);
export const patrolCount = st => Math.min(Math.max(st - 1, 0), FLEETS.patrolAt.length);
