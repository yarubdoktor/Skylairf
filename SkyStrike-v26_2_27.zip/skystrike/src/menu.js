import {$, clamp, esc} from './util.js';
import {S, save} from './save.js';
import {
  PLANES,
  level,
  stats,
  rankKey,
  upCost,
  wCost,
  WPN,
  misInit,
  weeklyInit,
  loginInfo,
  claimLogin,
  useSkin,
  buySkin
} from './data.js';
import {t, setLang, getLang} from './i18n.js';
import {setMute, setMusic} from './audio.js';
import LOGO from './assets/logo-horizontal.webp';
import {ART} from './art.js';
import {enemiesSheet} from './menu_enemies.js';
import {ic} from './menu_icons.js';
import {avatar, rb, plain, bar, nextLv, baseLv, ranks, pimg} from './sheets/common.js';
import {campaignSheet} from './sheets/campaign.js';
import {hangarSheet, skinsSheet} from './sheets/hangar.js';
import {weaponsSheet, missionsSheet} from './sheets/weapons.js';
import {profileSheet, rankingSheet} from './sheets/profile.js';
import {settingsSheet} from './sheets/settings.js';
import {setupSheet} from './sheets/setup.js';
const NAV = [
  ['lobby', 'home', 'nLobby'],
  ['hangar', 'plane', 'nPlanes'],
  ['weapons', 'rocket', 'nWeapons'],
  ['settings', 'gear', 'nSettings'],
  ['missions', 'clip', 'nMissions']
];
const TITLES = {
  profile: 'profileT',
  hangar: 'hangarT',
  weapons: 'weaponsT',
  missions: 'msT',
  skins: 'skinsT',
  campaign: 'campT',
  enemies: 'enemiesT',
  ranking: 'tTop',
  settings: 'tSet',
  setup: 'setupT'
};
const ALIAS = {planes: 'lobby', top: 'lobby', wpn: 'weapons', mis: 'missions', set: 'settings'};

export function createMenu(api) {
  let screen = 'lobby',
    shown = '',
    msg = '',
    mapsBusy = false;
  const M = {};
  const claimable = () =>
    S.mis.l.filter(x => !x.c && x.p >= x.n).length +
    (S.wk ? S.wk.l.filter(x => !x.c && x.p >= x.n).length : 0) +
    (loginInfo().can ? 1 : 0);
  /* ---------- أجزاء اللوبي ---------- */
  const topBar = l => {
    const lo = baseLv(l),
      hi = nextLv(l),
      pct = clamp(((S.xp - lo) / (hi - lo)) * 100, 0, 100);
    return `<div class="lb-top">
      <div class="lb-prof ${rankKey(l)}" role="button" tabindex="0" data-a="scr" data-i="profile">${avatar(l, pct)}<div class="lb-pi"><b class="tx">${esc(S.name)}</b><span class="rkchip">${rb(l)}${t(rankKey(l))}</span><i class="xpb"><b style="width:${pct}%"></b></i><small>${S.xp} / ${hi} ${t('xp')}</small></div></div>
      <div class="lb-cur">
        <div class="cur"><span class="ci">🪙</span><b>${S.coins}</b><button data-a="scr" data-i="missions" aria-label="+">${ic('plus')}</button></div>
        <div class="cur"><span class="ci">💎</span><b>${S.gems | 0}</b><button data-a="scr" data-i="missions" aria-label="+">${ic('plus')}</button></div>
      </div>
      <div class="lb-ico"><button data-a="soon" aria-label="${t('soon')}">${ic('mail')}</button><button data-a="soon" aria-label="${t('soon')}">${ic('users')}</button><button data-a="scr" data-i="settings" aria-label="${t('nSettings')}">${ic('gear')}</button></div>
    </div>`;
  };
  const nav = () =>
    `<nav class="lb-nav">${NAV.map(([k, i, n]) => `<button data-a="scr" data-i="${k}" class="${screen === k ? 'on' : ''}">${ic(i)}<span class="tx">${t(n)}</span>${k === 'missions' && claimable() ? '<em></em>' : ''}</button>`).join('')}</nav>`;
  const planePanel = PREV => {
    const id = S.sel,
      p = PLANES[id],
      lv = S.pl[id] || 1,
      st = stats(id);
    return `<div class="lb-right"><div class="lb-logo"><img src="${LOGO}" alt="SKY STRIKE"></div><div class="lb-plane">
      <div class="pp-h"><div><b class="tx">${p.n}</b><p class="tx">${t('d_' + id)}</p></div><span class="lvb">${t('lvl')} ${lv}</span></div>
      <div class="st">${[
        ['SPD', st.speed, 280],
        ['TURN', st.turn, 2.3],
        ['HP', st.hp, 300]
      ]
        .map(([k, v, m]) => `<span>${k}</span>${bar(v, m)}<em>${Math.round(v * (k === 'TURN' ? 10 : 1))}</em>`)
        .join('')}</div>
      <button class="pp-360" data-a="view" data-i="${id}">⟳ ${t('hgView')}</button>
      <div class="ths">${Object.keys(PLANES)
        .map(k => {
          const own = !!S.pl[k];
          return `<button class="th ${S.sel === k ? 'on' : ''} ${own ? '' : 'lk'}" data-a="${own ? 'pick' : 'scr'}" data-i="${own ? k : 'hangar'}"><img src="${pimg(PREV, k)}" alt="">${own ? '' : '<span>🔒</span>'}</button>`;
        })
        .join('')}</div>
    </div></div>`;
  };
  const eventCard = PREV => {
    const L = S.mis.l,
      done = L.filter(x => x.c).length,
      rdy = claimable(),
      now = new Date(),
      nx = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1),
      ms = nx - now,
      h = Math.floor(ms / 36e5),
      m = Math.floor((ms % 36e5) / 6e4);
    return `<button class="lb-event" data-a="scr" data-i="missions"><img src="${pimg(PREV, S.sel)}" alt=""><div><span class="tag">${t('dailyT')}</span><b class="tx">${rdy ? t('ready') : t('doneOf', {a: done, b: L.length})}</b><small class="tx">⏱ ${t('resetIn', {h, m})}</small></div>${rdy ? `<em>${rdy}</em>` : ''}</button>`;
  };
  const miniRank = () =>
    `<button class="lb-rank" data-a="scr" data-i="ranking"><div class="rk-h">${ic('trophy')}<b class="tx">${plain(t('tTop'))}</b></div>${ranks(
      3
    )
      .map(
        (r, i) =>
          `<div class="rk ${r.me ? 'me' : ''}"><i>${i + 1}</i><span class="tx">${esc(r.n)}</span><small>Lv${r.l | 0}</small><b>${r.s | 0}</b></div>`
      )
      .join('')}</button>`;
  const setupChip = () =>
    `<button class="lb-chip" data-a="scr" data-i="setup">${ic('map')}<span class="tx">${plain(t('map_' + S.map))} · ${plain(t('mode_' + S.mode))}</span></button>`;
  const lobby = PREV => `${planePanel(PREV)}${eventCard(PREV)}${miniRank()}${setupChip()}`;
  const bottomBar = () =>
    `<div class="lb-bot"><button data-a="scr" data-i="setup" class="${screen === 'setup' ? 'on' : ''}">${ic('map')}<span class="tx">${t('bMaps')}</span></button><button data-a="scr" data-i="ranking" class="${screen === 'ranking' ? 'on' : ''}">${ic('trophy')}<span class="tx">${t('bRank')}</span></button><button data-a="scr" data-i="campaign" class="${screen === 'campaign' ? 'on' : ''}">${ic('target')}<span class="tx">${t('bCamp')}</span></button></div>`;
  const cta = () =>
    `<button class="lb-cta" data-a="go"><i></i><span class="tx">${t('start')}</span>${ic('plane')}</button>`;

  /* ---------- الشاشات الداخلية ---------- */
  const sheets = {
    enemies: () => enemiesSheet(t, ART),
    campaign: campaignSheet,
    hangar: hangarSheet,
    skins: skinsSheet,
    weapons: weaponsSheet,
    missions: missionsSheet,
    profile: profileSheet,
    ranking: rankingSheet,
    settings: settingsSheet,
    setup: setupSheet({api, busy: () => mapsBusy})
  };

  /* ---------- العرض ---------- */
  M.setMsg = m => {
    msg = m;
  };
  M.show = to => {
    if (to) screen = ALIAS[to] || to;
    if (!sheets[screen] && screen !== 'lobby') screen = 'lobby';
    misInit();
    weeklyInit();
    const m = $('#menu'),
      l = level(),
      PREV = api.previews(),
      prevScroll = m.querySelector('.sh-b'),
      y = prevScroll && shown === screen ? prevScroll.scrollTop : 0;
    shown = screen;
    m.style.display = 'block';
    m.dataset.s = screen;
    m.style.setProperty('--dir', getLang() === 'ar' ? 'rtl' : 'ltr');
    const inner =
      screen === 'lobby'
        ? lobby(PREV)
        : `<div class="lb-sheet"><div class="sh-h"><h2 class="tx">${t(TITLES[screen])}</h2><button class="sh-x" data-a="scr" data-i="lobby" aria-label="${t('close')}">${ic('x')}</button></div><div class="sh-b">${sheets[screen](PREV)}</div></div>`;
    m.innerHTML = `${topBar(l)}${nav()}${msg ? `<div class="lb-msg tx">${msg}</div>` : ''}${inner}${bottomBar()}${cta()}`;
    if (y) {
      const sb = m.querySelector('.sh-b');
      if (sb) sb.scrollTop = y;
    }
    if (screen === 'setup' && !mapsBusy && api.mapsPending()) {
      mapsBusy = true;
      setTimeout(
        () =>
          api.genMapPreviews(
            (id, url) => {
              const im = document.querySelector(`#menu img[data-mi="${id}"]`);
              if (im) {
                im.src = url;
                im.hidden = false;
              }
            },
            () => {
              mapsBusy = false;
              if (screen === 'setup') M.show();
            }
          ),
        250
      );
    }
  };
  $('#menu').addEventListener('change', e => {
    if (e.target.id !== 'pname') return;
    const v = e.target.value.trim().slice(0, 16);
    if (!v) {
      e.target.value = S.name;
      return;
    }
    S.name = v;
    save();
    toast(t('pSaved'));
  });
  const toast = txt => {
    const d = document.createElement('div');
    d.className = 'lb-toast tx';
    d.textContent = txt;
    $('#menu').appendChild(d);
    setTimeout(() => d.remove(), 1700);
  };

  $('#menu').addEventListener('click', e => {
    const b = e.target.closest('[data-a]');
    if (!b || b.disabled) return;
    const a = b.dataset.a,
      i = b.dataset.i;
    if (a === 'soon') return toast(t('soon'));
    msg = '';
    if (a === 'go') return api.start();
    if (a === 'view') {
      $('#menu').style.display = 'none';
      return api.hangar(i, () => M.show());
    }
    if (a === 'camp') return api.startCampaign(+i);
    if (a === 'scr') {
      screen = i;
    }
    if (a === 'pick') S.sel = i;
    if (a === 'sel') S.sel = i;
    if (a === 'buy' && S.coins >= PLANES[i].price) {
      S.coins -= PLANES[i].price;
      S.pl[i] = 1;
      S.sel = i;
    }
    if (a === 'upl' && S.coins >= upCost(S.pl[i], i)) {
      S.coins -= upCost(S.pl[i], i);
      S.pl[i]++;
    }
    if (a === 'upw') {
      const c = S[i] ? wCost(S[i]) : WPN[i].price;
      if (S.coins >= c) {
        S.coins -= c;
        S[i]++;
      }
    }
    if (a === 'clm') {
      const x = S.mis.l[i];
      if (x.p >= x.n && !x.c) {
        x.c = 1;
        S.coins += x.r;
        msg = t('claimed', {r: x.r});
      }
    }
    if (a === 'clmw') {
      const x = S.wk.l[i];
      if (x.p >= x.n && !x.c) {
        x.c = 1;
        S.coins += x.r;
        S.gems = (S.gems || 0) + x.g;
        msg = t('claimed', {r: x.r}) + (x.g ? ' +' + x.g + '💎' : '');
      }
    }
    if (a === 'login') {
      const r = claimLogin();
      if (r) msg = t('claimedL', {r: r.coins}) + (r.gems ? ' +' + r.gems + '💎' : '');
    }
    if (a === 'skn') {
      S.sel = i;
      screen = 'skins';
    }
    if (a === 'skuse') {
      if (useSkin(S.sel, i)) api.rePrev();
    }
    if (a === 'skbuy') {
      if (buySkin(S.sel, i)) {
        api.rePrev();
        msg = t('skBought');
      }
    }
    if (a === 'mode') S.mode = i;
    if (a === 'map') S.map = i;
    if (a === 'cam') S.cam = +i;
    if (a === 'fm') S.fm = +i;
    if (a === 'q') {
      S.q = i;
      api.applyQuality();
    }
    if (a === 'snd') {
      S.snd = S.snd ? 0 : 1;
      setMute(!S.snd);
    }
    if (a === 'mus') {
      S.mus = S.mus ? 0 : 1;
      setMusic(!!S.mus);
    }
    if (a === 'vib') S.vib = S.vib ? 0 : 1;
    if (a === 'fps') S.fps = S.fps ? 0 : 1;
    if (a === 'assist') S.assist = S.assist ? 0 : 1;
    if (a === 'aim') S.aim = +i;
    if (a === 'tiltR') S.tiltR = +i;
    if (a === 'ct') S.ct = S.ct ? 0 : 1;
    if (a === 'sensY') S.sensY = clamp(Math.round((S.sensY + i * 0.1) * 10) / 10, 0.5, 1.6);
    if (a === 'shk') S.shk = S.shk === 0 ? 1 : 0;
    if (a === 'tilt') S.tilt = S.tilt ? 0 : 1;
    if (a === 'tiltInv') S.tiltInv = S.tiltInv ? 0 : 1;
    if (a === 'invY') S.invY = S.invY ? 0 : 1;
    if (a === 'tutOn') S.tut = S.tut ? 0 : 1;
    if (a === 'sens') S.sens = clamp(Math.round((S.sens + i * 0.1) * 10) / 10, 0.5, 1.6);
    if (a === 'lang') {
      S.lang = i;
      setLang(i);
    }
    save();
    M.show();
  });
  return M;
}
