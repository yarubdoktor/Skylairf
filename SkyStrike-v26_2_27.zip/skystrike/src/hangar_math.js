/* منطق صرف لنافذة معاينة الطائرة (بند #3) — بلا three ولا DOM كي يُختبر بـ node.
   مدار الكاميرا بقصور ذاتي + تكبير بالقرصة + دوران تلقائي عند الترك + جدول عرض الأسلحة. */
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const ORBIT = {
  pitchMin: -0.35, // أدنى زاوية (نظر من تحت قليلاً)
  pitchMax: 1.2, // أعلى زاوية (نظر من فوق)
  zoomMin: 0.55, // أقرب (×)
  zoomMax: 1.8, // أبعد (×)
  drag: 0.0065, // راديان لكل بكسل
  damp: 3.2, // تخميد القصور الذاتي (1/ث)
  idleAfter: 2.2, // ثوانٍ بلا لمس قبل الدوران التلقائي
  idleSpeed: 0.28, // راد/ث
  idleBlend: 1.6 // سرعة دخول الدوران التلقائي
};
export const newOrbit = () => ({yaw: 0.6, pitch: 0.22, zoom: 1, vy: 0, vp: 0, idle: 0, auto: 0, held: false});
// سحب بإصبع: يحرّك فوراً ويحفظ السرعة (راد/ث) لقصور الترك
export function orbitDrag(o, dx, dy, dt) {
  const k = ORBIT.drag;
  o.yaw -= dx * k;
  o.pitch = clamp(o.pitch + dy * k, ORBIT.pitchMin, ORBIT.pitchMax);
  if (dt > 0) {
    const s = Math.min(1, dt * 14); // مرشّح خفيف للسرعة المقاسة
    o.vy += (-(dx * k) / dt - o.vy) * s;
    o.vp += ((dy * k) / dt - o.vp) * s;
  }
  o.held = true;
  o.idle = 0;
  o.auto = 0;
}
export const orbitRelease = o => {
  o.held = false;
};
// قرصة: ratio = المسافة الحالية بين الإصبعين / السابقة (>1 = تباعد = تقريب)
export function orbitPinch(o, ratio) {
  if (!(ratio > 0)) return;
  o.zoom = clamp(o.zoom / ratio, ORBIT.zoomMin, ORBIT.zoomMax);
  o.idle = 0;
  o.auto = 0;
}
export function orbitStep(o, dt) {
  if (o.held) {
    o.idle = 0;
    return o;
  }
  const d = Math.exp(-ORBIT.damp * dt);
  o.yaw += o.vy * dt;
  o.pitch = clamp(o.pitch + o.vp * dt, ORBIT.pitchMin, ORBIT.pitchMax);
  o.vy *= d;
  o.vp *= d;
  o.idle += dt;
  if (o.idle > ORBIT.idleAfter) {
    o.auto = Math.min(1, o.auto + dt * ORBIT.idleBlend); // دخول ناعم (لا قفزة)
    o.yaw += ORBIT.idleSpeed * o.auto * dt;
    o.pitch += (0.22 - o.pitch) * Math.min(1, dt * 0.8); // يعود الميل لزاوية جميلة
  }
  return o;
}
// موضع الكاميرا من المدار (الهدف عند الأصل)
export function orbitPos(o, dist) {
  const r = dist * o.zoom,
    cp = Math.cos(o.pitch);
  return {x: Math.sin(o.yaw) * cp * r, y: Math.sin(o.pitch) * r, z: Math.cos(o.yaw) * cp * r};
}
// دخول سينمائي: الكاميرا تبدأ بعيدة/منخفضة وتستقر (t من 0 إلى 1، easeOutCubic)
export const introK = t => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
export const INTRO = 1.6; // ثوانٍ

/* جدول عرض الأسلحة: دورة تتكرر. كل حدث {t, k} ؛ k = gun|msl|bomb|flr */
export const SHOW = [
  {t: 0.3, k: 'gun'},
  {t: 1.9, k: 'msl', side: -1},
  {t: 2.15, k: 'msl', side: 1},
  {t: 3.6, k: 'bomb'},
  {t: 4.6, k: 'flr'},
  {t: 4.9, k: 'flr'}
];
export const SHOW_LEN = 6.2;
export const GUN_BURST = 1.1; // مدة رشقة المدفع
// الأحداث التي استحقت بين (a, b] بزمن الدورة (يتعامل مع لفّ الدورة)
export function showDue(a, b, ev = SHOW, len = SHOW_LEN) {
  const out = [];
  const lo = a % len,
    hi = lo + (b - a);
  for (const e of ev) {
    if ((e.t > lo && e.t <= hi) || (hi > len && e.t + len > lo && e.t + len <= hi)) out.push(e);
  }
  return out;
}
// نطاق قيمة مواصفة إلى 0..1 للشريط (يتجنب القسمة على صفر)
export const norm = (v, max) => clamp(max > 0 ? v / max : 0, 0, 1);
