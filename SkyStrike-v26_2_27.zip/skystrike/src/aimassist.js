/* مساعدة تصويب المدفع (بند #13b) — دالة صرفة بلا DOM/three، تنختبر بـ node (tools/test/test_aimassist.mjs).
   الطلقة تنحرف قليلاً نحو نقطة التقدّم (lead) لأقرب هدف داخل مخروط أمام الطائرة.
   الانحراف محدود بزاوية قصوى (حتى يبقى التصويب مهارة)، ولا يعمل لو الهدف خارج المخروط.
   المستوى 0 = مطفأ. لا يمس الصواريخ (لها قفلها). */
export const AIM = [
  null,
  {cone: 7, maxDeg: 3.5, k: 0.6, range: 1100}, // 1 خفيف
  {cone: 11, maxDeg: 6, k: 0.85, range: 1300} // 2 قوي
];
const RAD = Math.PI / 180;

/* pos/fw: {x,y,z} · enemies: [{g:{position},vel?}] · speed: سرعة الطلقة · out: {x,y,z} تُملأ بالاتجاه الناتج */
export function assistDir(pos, fw, speed, enemies, level, out) {
  out.x = fw.x;
  out.y = fw.y;
  out.z = fw.z;
  const c = AIM[level | 0];
  if (!c) return out;
  const cosMin = Math.cos(c.cone * RAD);
  let best = null,
    bc = cosMin;
  for (const e of enemies) {
    const p = e.g.position,
      dx = p.x - pos.x,
      dy = p.y - pos.y,
      dz = p.z - pos.z,
      d = Math.hypot(dx, dy, dz);
    if (d < 30 || d > c.range) continue;
    const ca = (fw.x * dx + fw.y * dy + fw.z * dz) / d;
    if (ca > bc) {
      bc = ca;
      best = {e, d, dx, dy, dz};
    }
  }
  if (!best) return out;
  const v = best.e.vel || {x: 0, y: 0, z: 0},
    tt = best.d / Math.max(1, speed);
  let lx = best.dx + v.x * tt,
    ly = best.dy + v.y * tt,
    lz = best.dz + v.z * tt;
  const ll = Math.hypot(lx, ly, lz) || 1;
  lx /= ll;
  ly /= ll;
  lz /= ll;
  const ang = Math.acos(Math.min(1, Math.max(-1, fw.x * lx + fw.y * ly + fw.z * lz)));
  if (ang < 1e-4) return out;
  const t = Math.min(c.k, (c.maxDeg * RAD) / ang),
    sn = Math.sin(ang); // slerp: الانحراف = t×الزاوية بالضبط
  const w0 = Math.sin((1 - t) * ang) / sn,
    w1 = Math.sin(t * ang) / sn;
  const ox = fw.x * w0 + lx * w1,
    oy = fw.y * w0 + ly * w1,
    oz = fw.z * w0 + lz * w1,
    ol = Math.hypot(ox, oy, oz) || 1;
  out.x = ox / ol;
  out.y = oy / ol;
  out.z = oz / ol;
  return out;
}
