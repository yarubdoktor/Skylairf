/* اللاعب: التحكم بالطيران، القفل، الأسلحة، الكاميرا. الحالة نفسها (P) بـ state.js. */
import {clamp, wrap, rnd, VH} from './util.js';
import {S} from './save.js';
import {PLANES, gunDmg, mslDmg, mulDmg, bombDmg} from './data.js';
import {Q} from './quality.js';
import {WT} from './jets.js';
import {t} from './i18n.js';
import {sfx, setEngine} from './audio.js';
import {cam, world, fx, renderer, V, dirOfTo} from './core.js';
import {W, P, shadow, FW} from './state.js';
import {inp} from './input.js';
import {el, banner} from './ui.js';
import {shoot, die} from './combat.js';
import {stepPro, FM} from './flight.js';
import {assistDir} from './aimassist.js';
import {lookBlend, CT} from './camtarget.js';

const _a = V(),
  _b = V(),
  _c = V(),
  _d = V(),
  _ad = {x: 0, y: 0, z: 0},
  _lb = {x: 0, y: 0, z: 0};
let ctW = 0; // وزن كاميرا مراقبة الهدف (يُنعَّم 0..1)
export const cp = V(0, 170, 930); // موضع الكاميرا المُلاحق (يُعاد ضبطه بـ startGame)
// زاوية الكاميرا (S.cam): [المسافة خلف الطائرة، الارتفاع] — 0 قريبة (الافتراضي) ، 1 متوسطة ، 2 بعيدة (القديمة)
const CAMS = [
  [11.5, 3.2],
  [16.5, 4.2],
  [22, 5.5]
]; // v25.2: أقرب (القريبة كانت 16.5 وصارت 11.5)
export const camCfg = () => CAMS[S.cam] || CAMS[0];
const LOCK_T = 0.7; // زمن اكتمال القفل (ثانية)

/* النمط «كلاسيك» (S.fm = 0): نموذج v25.2 القديم بالضبط */
function flyClassic(dt, boosting) {
  const dz = v => (Math.abs(v) < 0.12 ? 0 : (v - Math.sign(v) * 0.12) / 0.88),
    tx = dz(inp.x),
    ty = dz(inp.y);
  P.sx += (tx * Math.abs(tx) * 0.35 + tx * 0.65 - P.sx) * Math.min(1, dt * 5);
  P.sy += (ty * Math.abs(ty) * 0.35 + ty * 0.65 - P.sy) * Math.min(1, dt * 5);
  const rate = P.turn * 0.7 * S.sens * (boosting ? P.tv : 1);
  P.yaw -= P.sx * rate * dt;
  P.pitch = clamp(P.pitch - (S.invY ? -P.sy : P.sy) * rate * 0.7 * S.sensY * dt, -1, 1);
  if (Math.abs(P.sy) < 0.05) P.pitch *= 1 - Math.min(1, dt * 0.7);
  P.roll += (-P.sx - P.roll) * Math.min(1, dt * 4);
}

export function playerUpdate(dt) {
  const G = W.G,
    enemies = W.enemies,
    flares = W.flares,
    pos = P.g.position,
    fw = FW;
  const boosting = inp.boost && P.en > 0.05;
  if (S.fm) stepPro(P, inp, {sens: S.sens, sensY: S.sensY, invY: S.invY}, dt, boosting);
  else flyClassic(dt, boosting);
  // مساعد تفادي الأرض
  const gh = world.ground(pos.x, pos.z),
    alt = pos.y - gh,
    vy = Math.sin(P.pitch) * P.cur,
    thr = 45 + Math.max(0, -vy);
  G.pull = false;
  if (S.assist && alt < thr && P.pitch < 0.4) {
    P.pitch += (0.4 - P.pitch) * clamp(1 - alt / thr, 0, 1) * dt * 3;
    G.pull = vy < -5 || alt < 30;
  }
  P.g.rotation.set(P.pitch, P.yaw, P.roll);
  dirOfTo(P.g, fw);
  P.en = clamp(P.en + (boosting ? -P.dr : P.rc) * dt, 0, 1);
  // الطاقة: الصعود يبطّئ والغطس يسرّع (احترافي فقط)
  const ef = S.fm ? clamp(1 - 0.22 * Math.sin(P.pitch), 0.8, 1.2) : 1;
  P.cur += ((boosting ? P.speed * P.bm : P.speed) * ef - P.cur) * Math.min(1, dt * 1.8);
  P.bk = clamp((P.cur / P.speed / ef - 1) / (P.bm - 1), 0, 1);
  pos.addScaledVector(fw, P.cur * dt);
  pos.y = Math.min(pos.y, world.cfg.ceil || 520);
  if (pos.y < world.ground(pos.x, pos.z) + 2.5) {
    die();
    return;
  }
  if (world.cfg.hit && world.cfg.hit(pos.x, pos.y, pos.z)) {
    die();
    return;
  }
  const lim = world.cfg.limit; // حدود الخريطة: تحذير + دوران إجباري نحو المركز
  G.outT = (G.outT || 0) - dt;
  if (lim && Math.max(Math.abs(pos.x), Math.abs(pos.z)) > lim) {
    if (G.outT <= 0) {
      banner(t('outMap'));
      sfx('alarm');
      G.outT = 2;
    }
    P.yaw += clamp(wrap(Math.atan2(pos.x, pos.z) - P.yaw), -1.3 * dt, 1.3 * dt);
  }
  world.stream(pos, false);
  // ظل الطائرة
  const al2 = pos.y - world.ground(pos.x, pos.z);
  shadow.visible = true;
  shadow.position.set(pos.x, pos.y - al2 + 0.7, pos.z);
  const ss = 14 + al2 * 0.03;
  shadow.scale.set(ss, 1, ss);
  shadow.material.opacity = 0.38 * (1 - clamp(al2 / 420, 0, 1));
  // القفل
  let lock = null,
    best = 0.8;
  for (const e of enemies) {
    _a.copy(e.g.position).sub(pos);
    const d = _a.length();
    if (d < 1600 && d > 1) {
      const dd = fw.dot(_a) / d + (e === W.candE ? 0.04 : 0);
      if (dd > best) {
        best = dd;
        lock = e;
        W.lockDist = d;
      }
    }
  }
  if (lock !== W.candE) {
    W.candE = lock;
    W.lockT = 0;
  } else if (lock) W.lockT += dt;
  const full = !!lock && W.lockT >= LOCK_T;
  el.lk.style.opacity = lock ? 1 : 0;
  el.lk.textContent = full ? t('lock') : t('locking');
  if (full && lock !== W.lockE) sfx('lock');
  W.lockE = full ? lock : null;
  // الأسلحة
  P.gcd -= dt;
  if (inp.fire && P.gcd <= 0) {
    P.gcd = 0.09;
    sfx('gun');
    _a.set(1, 0, 0).applyEuler(P.g.rotation);
    assistDir(pos, fw, 750, enemies, S.aim, _ad);
    _d.set(_ad.x, _ad.y, _ad.z); // مساعدة تصويب (S.aim: 0 مطفأ · 1 خفيف · 2 قوي)
    for (const s of [-1, 1]) {
      _b.copy(pos)
        .addScaledVector(_a, s * 2.2)
        .addScaledVector(fw, 6);
      shoot({owner: 'p', pos: _b, dir: _d, speed: 750, dmg: gunDmg()});
    }
  }
  if (inp.msl && !inp.msP && P.msl > 0) {
    P.msl--;
    sfx('msl');
    _b.copy(pos).addScaledVector(fw, 6);
    _b.y -= 1.5;
    shoot({owner: 'p', pos: _b, dir: fw, speed: 480, dmg: mslDmg(), mis: true, target: W.lockE});
  }
  inp.msP = inp.msl;
  if (inp.mul && !inp.mulP && P.mul > 0 && S.multi > 0) {
    P.mul--;
    sfx('msl');
    _a.set(1, 0, 0).applyEuler(P.g.rotation);
    const cs = enemies
      .map(e => {
        const to = e.g.position.clone().sub(pos),
          dd = to.length();
        return {e, dd, dt: fw.dot(to.normalize())};
      })
      .filter(c => c.dt > 0.6 && c.dd < 1600)
      .sort((a, b) => b.dt - a.dt)
      .slice(0, 3);
    for (let i = 0; i < 3; i++) {
      const tg = cs[i] ? cs[i].e : cs[0] ? cs[0].e : null;
      _b.copy(pos)
        .addScaledVector(fw, 6)
        .addScaledVector(_a, (i - 1) * 2);
      _b.y -= 1.5;
      _c.copy(fw).addScaledVector(_a, (i - 1) * 0.14);
      shoot({owner: 'p', pos: _b, dir: _c, speed: 440, dmg: mulDmg(), mis: true, target: tg});
    }
  }
  inp.mulP = inp.mul;
  if (inp.bmb && !inp.bmbP && P.bmb > 0 && S.bomb > 0) {
    P.bmb--;
    sfx('gun');
    _b.copy(pos);
    _b.y -= 2;
    shoot({owner: 'p', pos: _b, dir: fw, speed: P.cur * 0.9, dmg: bombDmg(), bomb: true});
  }
  inp.bmbP = inp.bmb;
  if (inp.flr && !inp.flrP && P.flr > 0) {
    P.flr--;
    sfx('flare');
    for (let i = 0; i < 3; i++) {
      const f = {
        p: pos.clone().addScaledVector(fw, -6),
        v: V(rnd(-20, 20), rnd(-12, 4), rnd(-20, 20)).addScaledVector(fw, P.cur * 0.35),
        life: 3.6
      };
      flares.push(f);
    }
  }
  inp.flrP = inp.flr;
  for (const f of P.g.userData.fl) {
    f.scale.z = 0.6 + P.bk * 1.4 + Math.random() * 0.25;
    f.scale.x = f.scale.y = 0.8 + P.bk * 0.3;
  }
  if (P.bk > 0.3 && Math.random() < dt * 30) {
    _a.set(2.2, 0, 6).applyEuler(P.g.rotation);
    fx.smk(pos.x + _a.x, pos.y + _a.y, pos.z + _a.z, 0xffffff, 1.2, 5, 0.9, 0, 0, 0, 0.25);
    _a.set(-2.2, 0, 6).applyEuler(P.g.rotation);
    fx.smk(pos.x + _a.x, pos.y + _a.y, pos.z + _a.z, 0xffffff, 1.2, 5, 0.9, 0, 0, 0, 0.25);
  }
  if (Q.fx >= 260 && ((S.fm ? P.gl > 4.2 : Math.abs(P.sx) > 0.5) || P.bk > 0.5) && Math.random() < dt * 45) {
    // خطوط بخار من أطراف الأجنحة
    const w = WT[PLANES[S.sel].kind];
    for (const s of [-1, 1]) {
      _a.set(s * w.x, w.y, w.z).applyEuler(P.g.rotation);
      fx.smk(pos.x + _a.x, pos.y + _a.y, pos.z + _a.z, 0xffffff, 0.8, 3.2, 0.7, 0, 0, 0, 0.3);
    }
  }
  setEngine(P.cur / P.speed, P.bk);
  if (P.hp < P.maxhp * 0.3 && G.t % 1 < dt) sfx('warn');
}

export function cameraUpdate(dt) {
  const G = W.G,
    pos = P.g.position;
  if (!G.dead) {
    const [cd, ch] = camCfg();
    _a.set(S.fm ? P.roll * 1.1 : 0, ch, 0).applyEuler(P.g.rotation);
    _b.copy(pos)
      .addScaledVector(FW, -(cd + P.bk * 3))
      .add(_a);
    cp.lerp(_b, Math.min(1, dt * (S.fm ? 4.5 : 5)));
  }
  cam.position.copy(cp);
  const le = W.lockE,
    wantCt = S.ct && le && !G.dead && le.g.position.distanceTo(pos) < CT.range; // كاميرا مراقبة الهدف (S.ct)
  ctW += ((wantCt ? 1 : 0) - ctW) * Math.min(1, dt * 3);
  if (ctW > 0.01 && le) {
    _d.copy(le.g.position).sub(pos).normalize();
    lookBlend(FW, _d, ctW, _lb);
    _a.set(_lb.x, _lb.y, _lb.z);
  } else _a.copy(FW);
  _a.multiplyScalar(40).add(pos);
  cam.lookAt(_a);
  cam.rotateZ(P.roll * (S.fm ? 0.5 : 0.35));
  if (S.fm && P.gl > 5.5) W.shake = Math.max(W.shake, (P.gl - 5.5) * 0.05); // اهتزاز خفيف تحت G عالي
  W.shake *= Math.max(0, 1 - dt * 4);
  if (W.shake > 0.02)
    // S.shk 0 = اهتزاز مخفّف
    cam.position.add(_c.set(rnd(-1, 1), rnd(-1, 1), rnd(-1, 1)).multiplyScalar(W.shake * (S.shk === 0 ? 0.3 : 1.2)));
  const fv = 65 + P.bk * 14 + (S.fm ? clamp((P.cur / P.speed - 1) * 10, -3, 6) : 0);
  if (Math.abs(cam.fov - fv) > 0.1) {
    cam.fov += (fv - cam.fov) * Math.min(1, dt * 4);
    cam.updateProjectionMatrix();
    fx.setScale(VH() * renderer.getPixelRatio(), cam.fov);
  }
}
