import {S, save} from './save.js';
export const PLANES = {
  // up = معامل تكلفة الترقية ، fl = عدد قنابل الإنذار (Flares)
  // ab = ميزة الطائرة: bm سرعة الـBoost (×) ، dr استهلاك الشحن ، rc سرعة الشحن ،
  //      tv مضاعف الدوران أثناء الـBoost (توجيه الدفع) ، ms مضاعف تتبع صواريخ العدو (التخفّي، أقل = أصعب عليهم)
  f35: {
    n: 'F-35 Lightning II',
    speed: 150,
    turn: 1.0,
    hp: 130,
    price: 0,
    col: 0x8a95a5,
    kind: 0,
    up: 1,
    fl: 6,
    ab: {bm: 1.4, dr: 0.38, rc: 0.12, tv: 1, ms: 0.6}
  },
  f16: {
    n: 'F-16 Viper',
    speed: 165,
    turn: 1.25,
    hp: 85,
    price: 900,
    col: 0x7d8793,
    kind: 3,
    up: 0.7,
    fl: 4,
    ab: {bm: 1.5, dr: 0.36, rc: 0.18, tv: 1.15, ms: 0.9}
  },
  mig29: {
    n: 'MiG-29 Fulcrum',
    speed: 170,
    turn: 1.3,
    hp: 75,
    price: 1800,
    col: 0x6f8f6a,
    kind: 1,
    up: 0.8,
    fl: 3,
    ab: {bm: 1.6, dr: 0.42, rc: 0.2, tv: 1, ms: 1}
  },
  a10: {
    n: 'A-10 Thunderbolt II',
    speed: 120,
    turn: 0.8,
    hp: 220,
    price: 3200,
    col: 0x6b705e,
    kind: 4,
    up: 1.2,
    fl: 5,
    ab: {bm: 1.25, dr: 0.4, rc: 0.12, tv: 1, ms: 0.8}
  },
  f14: {
    n: 'F-14 Tomcat',
    speed: 160,
    turn: 1.0,
    hp: 150,
    price: 5500,
    col: 0x7a869a,
    kind: 5,
    up: 1.3,
    fl: 6,
    ab: {bm: 1.35, dr: 0.38, rc: 0.12, tv: 1, ms: 0.75}
  },
  su57: {
    n: 'Su-57 Felon (Sukhoi)',
    speed: 175,
    turn: 1.55,
    hp: 115,
    price: 8000,
    col: 0x4b5563,
    kind: 2,
    up: 1.5,
    fl: 5,
    ab: {bm: 1.45, dr: 0.3, rc: 0.12, tv: 1.3, ms: 0.85}
  },
  f22: {
    n: 'F-22 Raptor',
    speed: 190,
    turn: 1.4,
    hp: 120,
    price: 12000,
    col: 0x4a525e,
    kind: 6,
    up: 1.8,
    fl: 5,
    ab: {bm: 1.5, dr: 0.3, rc: 0.14, tv: 1.15, ms: 0.5}
  }
};
export const level = () => Math.floor(Math.sqrt(S.xp / 60)) + 1;
export const RANKS = [
  [35, 'r5'],
  [20, 'r4'],
  [10, 'r3'],
  [5, 'r2'],
  [0, 'r1']
];
export const rankKey = l => RANKS.find(r => l >= r[0])[1];
export const stats = id => {
  const l = S.pl[id],
    P = PLANES[id];
  return {speed: P.speed * (1 + (l - 1) * 0.06), turn: P.turn * (1 + (l - 1) * 0.05), hp: P.hp * (1 + (l - 1) * 0.12)};
};
export const gunDmg = () => 6 + 3 * S.gun,
  mslDmg = () => 50 + 25 * S.msl,
  mslMax = () => 3 + S.msl;
export const mulDmg = () => 30 + 14 * S.multi,
  mulMax = () => 1 + S.multi;
export const bombDmg = () => 90 + 40 * S.bomb,
  bombMax = () => 3 + 2 * S.bomb;
export const planeFlares = () => (PLANES[S.sel] || PLANES.f35).fl;
export const MAXL = 10,
  upCost = (l, id) => Math.round((200 * l * ((PLANES[id] || {}).up || 1)) / 10) * 10,
  wCost = l => 150 * l;
export const WPN = {
  gun: {ic: '🔫', price: 0},
  msl: {ic: '🚀', price: 0},
  multi: {ic: '🎆', price: 1200},
  bomb: {ic: '💣', price: 600}
};
export const BOTS = [
  ['Falcon_X', 48200, 41],
  ['حيدر', 36500, 33],
  ['NovaPilot', 27100, 26],
  ['Viper77', 19800, 21],
  ['سارة', 12400, 15],
  ['Ghost', 8700, 11],
  ['Maverick', 5200, 8],
  ['Rookie', 2100, 4]
];
export const MODES = ['survive', 'assault', 'defend'];
export const dayKey = () => new Date().toISOString().slice(0, 10);
export function misInit() {
  if (S.mis && S.mis.day === dayKey()) return;
  const sc = 1 + Math.floor(level() / 8) * 0.5;
  S.mis = {
    day: dayKey(),
    l: [
      {k: 'kj', n: Math.round(8 * sc), r: 250, p: 0, c: 0},
      {k: 'kg', n: Math.round(6 * sc), r: 250, p: 0, c: 0},
      {k: 'wv', n: 4 + Math.floor(level() / 6), r: 400, p: 0, c: 0}
    ]
  };
  save();
}
const upd = (m, G) => {
  if (m.k === 'kj') m.p += G.kj;
  else if (m.k === 'kg') m.p += G.kg;
  else if (m.k === 'wv') m.p = Math.max(m.p, G.wave);
  else if (m.k === 'rn') m.p += 1;
};
export function trackMis(G) {
  misInit();
  weeklyInit();
  for (const m of S.mis.l) upd(m, G);
  for (const m of S.wk.l) upd(m, G);
  S.st = S.st || {n: 0, c: 0};
  S.st.n++;
  S.st.c += G.coins;
}
export const avgCoins = () => (S.st && S.st.n ? Math.round(S.st.c / S.st.n) : 0);

/* ---------- المهام الأسبوعية (تتجدد كل اثنين UTC) ---------- */
export const weekKey = () => {
  const d = new Date(),
    off = (d.getUTCDay() + 6) % 7;
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - off)).toISOString().slice(0, 10);
};
export const weekDaysLeft = () => 7 - ((new Date().getUTCDay() + 6) % 7);
export function weeklyInit() {
  if (S.wk && S.wk.wk === weekKey()) return;
  const sc = 1 + Math.floor(level() / 8) * 0.5;
  S.wk = {
    wk: weekKey(),
    l: [
      {k: 'kj', n: Math.round(50 * sc), r: 800, g: 10, p: 0, c: 0},
      {k: 'kg', n: Math.round(40 * sc), r: 800, g: 10, p: 0, c: 0},
      {k: 'wv', n: 8 + Math.floor(level() / 5), r: 1000, g: 15, p: 0, c: 0},
      {k: 'rn', n: 15, r: 600, g: 10, p: 0, c: 0}
    ]
  };
  save();
}

/* ---------- مكافأة الدخول اليومي (سلسلة 7 أيام، اليوم 7 فيه جواهر) ---------- */
const LOGIN = [100, 150, 200, 250, 300, 400, 500];
const ydayKey = () => new Date(Date.now() - 864e5).toISOString().slice(0, 10);
export function loginInfo() {
  const L = S.lg || {last: '', st: 0},
    today = dayKey();
  const day = L.last === today ? L.st || 1 : L.last === ydayKey() ? (L.st % 7) + 1 : 1;
  return {can: L.last !== today, day, coins: LOGIN[day - 1], gems: day === 7 ? 10 : 0};
}
export function claimLogin() {
  const r = loginInfo();
  if (!r.can) return null;
  S.coins += r.coins;
  S.gems = (S.gems || 0) + r.gems;
  S.lg = {last: dayKey(), st: r.day};
  save();
  return r;
}

/* ---------- ألوان الطائرات (Skins) تُشترى بالجواهر 💎 ---------- */
const sk = (c, g, sw) => ({c, g, sw: sw ?? c});
export const SKINS = {
  gray: sk(null, 0, 0x9099a5),
  desert: sk(0xc9b074, 25),
  forest: sk(0x5f7d4e, 25),
  arctic: sk(0xe2ebf4, 40),
  night: sk(0x22252b, 40),
  digital: sk(0x6a7c8c, 55),
  carbon: sk(0x2a2e36, 90),
  pearl: sk(0xd9d2ee, 110),
  neon: sk(0x22e6ff, 140),
  crimson: sk(0x9b2d2d, 60),
  chrome: sk(0xe3eaf2, 150),
  gold: sk(0xd4af37, 120)
};
export const skinOf = id => {
  const k = S.sk && S.sk[id];
  return SKINS[k] ? k : 'gray';
};
export const skinOwned = (id, k) => k === 'gray' || !!(S.sko && S.sko[id + ':' + k]);
export function useSkin(id, k) {
  if (!SKINS[k] || !skinOwned(id, k)) return false;
  S.sk = S.sk || {};
  S.sk[id] = k;
  save();
  return true;
}
export function buySkin(id, k) {
  if (!SKINS[k] || skinOwned(id, k) || (S.gems || 0) < SKINS[k].g) return false;
  S.gems -= SKINS[k].g;
  S.sko = S.sko || {};
  S.sko[id + ':' + k] = 1;
  S.sk = S.sk || {};
  S.sk[id] = k;
  save();
  return true;
}
// الترتيب محلي فقط (بدون أونلاين)
export function submitScore(sc, mode) {
  S.scores.push({n: S.name, s: sc, l: level(), m: mode});
  S.scores.sort((a, b) => b.s - a.s);
  S.scores = S.scores.slice(0, 10);
  save();
}

/* ---------- مكافآت المستويات (v16) ----------
   كل مستوى: عملات. كل 5 مستويات: جواهر. مستويات معينة: لون (Skin) مجاني لكل الطائرات.
   تُمنح عند نهاية المهمة لكل مستوى جديد (S.lvr = آخر مستوى استلمت مكافأته). */
const SKIN_AT = {3: 'desert', 6: 'forest', 9: 'arctic', 12: 'night', 15: 'crimson', 20: 'gold'};
export const lvReward = l => ({c: 100 + l * 40, g: l % 5 === 0 ? l : 0, sk: SKIN_AT[l] || null});
export function claimLevelRewards(lv0) {
  const L = level();
  if (S.lvr == null) S.lvr = lv0; // الحسابات القديمة: ما نعطي بأثر رجعي
  const o = {to: L, c: 0, g: 0, sk: []};
  let any = false;
  for (let l = S.lvr + 1; l <= L; l++) {
    const r = lvReward(l);
    any = true;
    S.coins += r.c;
    S.gems = (S.gems || 0) + r.g;
    o.c += r.c;
    o.g += r.g;
    if (r.sk) {
      S.sko = S.sko || {};
      for (const id in PLANES) S.sko[id + ':' + r.sk] = 1;
      o.sk.push(r.sk);
    }
  }
  S.lvr = Math.max(S.lvr, L);
  return any ? o : null;
}
