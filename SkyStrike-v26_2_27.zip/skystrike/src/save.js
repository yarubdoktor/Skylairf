const KEY = 'skystrike_v2',
  OLD = 'skystrike_v1';
const def = () => ({
  v: 2,
  coins: 300,
  xp: 0,
  sel: 'f35',
  pl: {f35: 1},
  gun: 1,
  msl: 1,
  multi: 0,
  bomb: 0,
  name: 'Pilot' + ((100 + Math.random() * 900) | 0),
  scores: [],
  gems: 0,
  sk: {},
  sko: {},
  lg: {last: '', st: 0},
  wk: null,
  st: {n: 0, c: 0},
  sens: 1,
  fm: 1,
  invY: 0,
  cam: 0,
  cp: 0,
  tut: 0,
  snd: 1,
  mus: 1,
  vib: 1,
  tilt: 0,
  tiltInv: 0,
  assist: 1,
  aim: 1,
  shk: 1,
  rz: 0,
  sensY: 1,
  tiltR: 1,
  ct: 0,
  fps: 0,
  q: 'auto',
  lang: (navigator.language || 'ar').toLowerCase().startsWith('ar') ? 'ar' : 'en',
  map: 'island',
  mode: 'survive'
});
function load() {
  let s = null;
  try {
    s = JSON.parse(localStorage.getItem(KEY) || 'null');
  } catch (e) {}
  if (!s) {
    try {
      s = JSON.parse(localStorage.getItem(OLD) || 'null');
    } catch (e) {}
  }
  return Object.assign(def(), s || {});
}
export const S = load();
export const save = () => {
  try {
    localStorage.setItem(KEY, JSON.stringify(S));
  } catch (e) {}
};
