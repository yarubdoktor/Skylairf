/* القتال: الطلقات والصواريخ والقنابل، الانفجارات، الضرر، القتل، المشاعل. */
import * as THREE from 'three';
import {$, clamp, rnd} from './util.js';
import {t} from './i18n.js';
import {sfx, setEngine} from './audio.js';
import {mkMsl, mkBomb, BULLET_GEO, BULLET_P, BULLET_E} from './jets.js';
import {scene, world, fx, V, vib, panOf} from './core.js';
import {W, P, shadow} from './state.js';
import {banner} from './ui.js';
import {checkClear} from './waves.js';
import {segDist2} from './collide.js';

const _a = V(),
  _b = V(),
  _o = V(); // _o = موضع الطلقة قبل الحركة (للتصادم بالمسار)

export function boom(pos, r = 12) {
  const d = pos.distanceTo(P.g.position);
  if (r < 12) {
    fx.glow(pos.x, pos.y, pos.z, 0xffe9a0, r * 1.4, r * 3.5, 0.18);
    return;
  }
  const big = r >= 22;
  sfx('boom', clamp(1 - d / 1500, 0.15, 1), big, panOf(pos));
  fx.explode(pos, r);
  W.shake = Math.max(W.shake, clamp(1 - d / 700, 0, 1) * (big ? 1.6 : 1));
  if (big && d < 500) vib(40);
}
export function shoot(o) {
  let mesh;
  if (o.bomb) mesh = mkBomb();
  else if (o.mis) mesh = mkMsl(o.owner === 'e');
  else {
    mesh = new THREE.Mesh(BULLET_GEO, o.owner === 'p' ? BULLET_P : BULLET_E);
    mesh.scale.set(1, 1, 7);
  }
  mesh.position.copy(o.pos);
  scene.add(mesh);
  if (o.owner === 'e')
    sfx(o.mis ? 'emsl' : 'efire', clamp(1 - o.pos.distanceTo(P.g.position) / 900, 0, 1), false, panOf(o.pos));
  W.projs.push({
    mesh,
    dir: o.dir.clone().normalize(),
    speed: o.speed,
    dmg: o.dmg,
    owner: o.owner,
    mis: !!o.mis,
    bomb: !!o.bomb,
    target: o.target || null,
    turn: o.turn || 2.4,
    vy: 0,
    life: o.life || (o.bomb ? 14 : o.mis ? 7 : 2.2)
  });
}

/* ---------- اللاعب: ضرر / موت / خسارة القاعدة ---------- */
export function die() {
  const G = W.G;
  if (G.dead) return;
  G.dead = true;
  G.deadT = 1.8;
  boom(P.g.position, 30);
  P.g.visible = false;
  shadow.visible = false;
  setEngine(0);
  vib(200);
}
export function baseLost() {
  const G = W.G;
  if (G.dead) return;
  G.dead = true;
  G.deadT = 2;
  banner(t('baseLost'));
  boom(_a.set(G.obj.x, world.ground(G.obj.x, G.obj.z) + 10, G.obj.z), 30);
  sfx('alarm');
}
export function hurt(d) {
  const G = W.G;
  if (G.dead || W.tut) return;
  G.hit = true;
  P.hp -= d;
  sfx('hit');
  W.shake = Math.max(W.shake, 0.6);
  vib(30);
  const f = $('#fl');
  f.style.opacity = 0.35;
  setTimeout(() => (f.style.opacity = 0), 120);
  if (P.hp <= 0) die();
}

/* ---------- الأعداء: إزالة / قتل ---------- */
export function removeEnemy(e) {
  scene.remove(e.g);
  const i = W.enemies.indexOf(e);
  if (i >= 0) W.enemies.splice(i, 1);
  if (W.lockE === e) W.lockE = null;
  if (W.candE === e) {
    W.candE = null;
    W.lockT = 0;
  }
}
export function kill(e) {
  const G = W.G;
  boom(e.g.position, e.air ? (e.kind === 'boss' ? 40 : e.kind === 'bomber' ? 26 : 22) : 16);
  removeEnemy(e);
  if (e.air) G.kj++;
  else G.kg++;
  G.combo++;
  G.ct = 4;
  G.mult = Math.min(5, 1 + Math.floor(G.combo / 3));
  G.score += Math.round(e.pts * G.mult);
  G.coins += Math.round(e.pts / 8);
  G.xp += Math.round(e.pts / 5);
  if (e.kind === 'boss') {
    G.coins += 150;
    banner(t('bossDown'));
    sfx('win');
  }
  checkClear();
}
/* تنظيف كل الكيانات (بداية/نهاية مهمة). المصفوفات تُفرَّغ بالمكان لأن باقي الملفات تقرأها من W */
export function clearEntities() {
  const G = W.G;
  for (const e of W.enemies) scene.remove(e.g);
  for (const p of W.projs) scene.remove(p.mesh);
  W.enemies.length = 0;
  W.projs.length = 0;
  W.flares.length = 0;
  W.lockE = null;
  W.candE = null;
  W.lockT = 0;
  if (G.beacon) {
    scene.remove(G.beacon);
    G.beacon = null;
  }
  if (G.op) {
    G.op.dispose();
    G.op = null;
  }
}

/* ---------- تحديث الطلقات والمشاعل ---------- */
export function projectilesUpdate(dt) {
  const pos = P.g.position,
    G = W.G,
    enemies = W.enemies,
    projs = W.projs,
    flares = W.flares;
  for (let pi = projs.length - 1; pi >= 0; pi--) {
    const p = projs[pi],
      mp = p.mesh.position;
    if (p.mis) {
      if (
        p.owner === 'p' &&
        p.target &&
        p.target.fl > 0 &&
        G.wave >= 4 &&
        p.target.g.position.distanceToSquared(mp) < 280 * 280 &&
        Math.random() < dt * Math.min(2, (G.wave - 3) * 0.4)
      ) {
        const tp = p.target.g.position;
        p.target.fl--;
        p.target = null;
        sfx('flare', clamp(1 - tp.distanceTo(pos) / 900, 0, 1), false, panOf(tp));
        for (let k = 0; k < 3; k++)
          fx.glow(tp.x + rnd(-6, 6), tp.y + rnd(-6, 2), tp.z + rnd(-6, 6), 0xffb060, 5, 2, 0.5, 0, 0, 0, 0.95);
      }
      if (p.owner === 'p') {
        if (p.target && enemies.includes(p.target)) {
          _a.copy(p.target.g.position).sub(mp).normalize();
          p.dir.lerp(_a, Math.min(1, dt * p.turn)).normalize();
        }
      } else {
        let tg = pos,
          bs = 360 * 360;
        for (const f of flares) {
          const d2 = f.p.distanceToSquared(mp);
          if (d2 < bs) {
            bs = d2;
            tg = f.p;
          }
        }
        _a.copy(tg).sub(mp).normalize();
        p.dir.lerp(_a, Math.min(1, dt * p.turn * (tg === pos ? P.ms : 1))).normalize();
      } // التخفّي: صواريخ العدو أضعف تتبعاً
      fx.glow(
        mp.x - p.dir.x * 2.5,
        mp.y - p.dir.y * 2.5,
        mp.z - p.dir.z * 2.5,
        0xffa040,
        2.4,
        0.6,
        0.14,
        0,
        0,
        0,
        0.95
      );
      if (Math.random() < 0.7)
        fx.smk(mp.x - p.dir.x * 2, mp.y - p.dir.y * 2, mp.z - p.dir.z * 2, 0xcfcfcf, 1.4, 6, 1, 0, 2, 0, 0.45);
    }
    _o.copy(mp);
    mp.addScaledVector(p.dir, p.speed * dt);
    if (p.bomb) {
      p.vy -= 75 * dt;
      mp.y += p.vy * dt;
      _b.copy(mp).addScaledVector(p.dir, p.speed);
      _b.y += p.vy;
      p.mesh.lookAt(_b);
    } else {
      _b.copy(mp).add(p.dir);
      p.mesh.lookAt(_b);
    }
    p.life -= dt;
    let dead = p.life <= 0 || mp.y < world.ground(mp.x, mp.z),
      boomed = false; // boomed: انفجرت عند الإصابة (ما نكرر الانفجار بالنهاية)
    if (!dead) {
      if (p.owner === 'p') {
        for (const e of enemies) {
          const ep = e.g.position,
            hr = e.r + (e.air ? 0 : 2);
          if (segDist2(_o.x, _o.y, _o.z, mp.x, mp.y, mp.z, ep.x, ep.y, ep.z) < hr * hr) {
            e.hp -= p.dmg;
            dead = true;
            boomed = true;
            boom(mp, p.mis ? 16 : 3);
            if (e.hp <= 0) kill(e);
            break;
          }
        }
        if (!dead && !p.mis && !p.bomb) {
          for (const q of projs) {
            if (
              q.owner === 'e' &&
              q.mis &&
              segDist2(_o.x, _o.y, _o.z, mp.x, mp.y, mp.z, q.mesh.position.x, q.mesh.position.y, q.mesh.position.z) < 20
            ) {
              q.life = 0;
              dead = true;
              break;
            }
          }
        }
      } else {
        if (!G.dead && segDist2(_o.x, _o.y, _o.z, mp.x, mp.y, mp.z, pos.x, pos.y, pos.z) < 49) {
          hurt(p.dmg);
          dead = true;
          boomed = true;
          boom(mp, p.mis ? 12 : 4);
        } else if (p.mis) {
          for (const f of flares) {
            if (f.p.distanceToSquared(mp) < 100) {
              dead = true;
              break;
            }
          }
        }
      }
    }
    if (dead) {
      if (p.mis && !boomed) boom(mp, 12);
      if (p.bomb) {
        boom(mp, 26);
        for (const e of enemies.slice()) {
          const dd = e.g.position.distanceTo(mp);
          if (dd < 36) {
            e.hp -= p.dmg * (1 - dd / 48);
            if (e.hp <= 0) kill(e);
          }
        }
      }
      scene.remove(p.mesh);
      projs.splice(pi, 1);
    }
  }
}
export function flaresUpdate(dt) {
  const flares = W.flares;
  for (let i = flares.length - 1; i >= 0; i--) {
    const f = flares[i];
    f.life -= dt;
    if (f.life <= 0) {
      flares.splice(i, 1);
      continue;
    }
    f.v.y -= 9 * dt;
    f.p.addScaledVector(f.v, dt);
    f.v.multiplyScalar(1 - dt * 0.5);
    fx.glow(f.p.x, f.p.y, f.p.z, 0xffb060, 5, 2, 0.35, 0, 0, 0, 0.95);
    if (Math.random() < 0.5) fx.smk(f.p.x, f.p.y, f.p.z, 0xdddddd, 2, 7, 1.2, 0, 1, 0, 0.4);
  }
}
