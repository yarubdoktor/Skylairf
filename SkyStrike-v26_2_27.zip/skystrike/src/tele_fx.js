/* تحذير بصري للأرضيات (v26.2.25، بند #9). دالة صرفة بدون three/DOM: تنختبر بـ node (test_tele_fx.mjs).
   أثناء التحذير (e.tele = 1) يومض الفوهة بنبضات تتسارع وتقوى كلما اقترب الرمي، ليعرف اللاعب أن الرشقة قادمة.
   ai.js يرسم النبضة بـ fx.glow؛ هنا فقط التوقيت والشدة. */
import {TELE} from './enemies.js';

/* يُستدعى كل فريم لكل وحدة. يرجع 0 (لا نبضة الآن) أو شدة النبضة بين TELE.min و1. e.gt = ما تبقّى من التحذير،
   e.gw0 = مدته الكلية (يضبطه ai_ground.js عند بدء التحذير). */
export function telePulse(e, dt) {
  if (!e.tele) {
    e.tpt = 0;
    return 0;
  }
  const prog = 1 - Math.max(0, e.gt) / Math.max(e.gw0 || 1, 1e-3);
  e.tpt = (e.tpt || 0) - dt;
  if (e.tpt > 0) return 0;
  e.tpt = TELE.gap0 - (TELE.gap0 - TELE.gap1) * prog;
  return TELE.min + (1 - TELE.min) * prog;
}
