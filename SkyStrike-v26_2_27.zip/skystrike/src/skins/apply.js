/* تطبيق السكنات على نماذج GLB (بند #2). تقنية: «حقن» بالشيدر عبر onBeforeCompile يرسم النمط بإحداثيات النموذج
   (سمة aOP تُخبَز مرة لكل نموذج، تتشاركها كل السكنات) فلا يلزم UV ولا ملفات خامات، وتبقى تفاصيل النموذج
   (خطوط الألواح، المحركات، الزجاج) لأن النمط يُضرَب بإضاءة الخامة الأصلية. الظل/الإضاءة PBR الأصلية كما هي. */
import * as THREE from 'three';
import {SKIN_DEFS, SKIN_TYPES} from './defs.js';

const KEEP = /canopy|glass|intake|exhaust|engine|dark/i; // أجزاء لا تُطلى (زجاج/محركات/فتحات)
export const SKU = {time: {value: 0}};
export const tickSkins = dt => {
  SKU.time.value += dt;
};

/* يخبز إحداثيات النمط (aOP) والاتجاه (aON) بفضاء جذر النموذج، مُطبَّعةً بأكبر بُعد.
   الهندسة المشتركة بين شبكتين تُستنسخ كي لا تتعارض المصفوفات */
export function bakeCoords(root) {
  if (root.userData.skBaked) return;
  root.userData.skBaked = true;
  root.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert(),
    m = new THREE.Matrix4(),
    n3 = new THREE.Matrix3(),
    v = new THREE.Vector3(),
    box = new THREE.Box3(),
    meshes = [];
  root.traverse(o => o.isMesh && o.geometry.attributes.position && meshes.push(o));
  for (const o of meshes) {
    m.multiplyMatrices(inv, o.matrixWorld);
    const p = o.geometry.attributes.position;
    for (let i = 0; i < p.count; i++) box.expandByPoint(v.fromBufferAttribute(p, i).applyMatrix4(m));
  }
  const c = box.getCenter(new THREE.Vector3()),
    s = Math.max(...box.getSize(new THREE.Vector3()).toArray()) || 1,
    seen = new Set();
  for (const o of meshes) {
    if (seen.has(o.geometry)) o.geometry = o.geometry.clone(); // نفس الهندسة بمصفوفة مختلفة (جناح معكوس مثلاً)
    seen.add(o.geometry);
    m.multiplyMatrices(inv, o.matrixWorld);
    n3.getNormalMatrix(m);
    const p = o.geometry.attributes.position,
      nr = o.geometry.attributes.normal,
      op = new Float32Array(p.count * 3),
      on = new Float32Array(p.count * 3);
    for (let i = 0; i < p.count; i++) {
      v.fromBufferAttribute(p, i).applyMatrix4(m).sub(c).divideScalar(s);
      op.set([v.x, v.y, v.z], i * 3);
      if (nr) {
        v.fromBufferAttribute(nr, i).applyMatrix3(n3).normalize();
        on.set([v.x, v.y, v.z], i * 3);
      }
    }
    o.geometry.setAttribute('aOP', new THREE.BufferAttribute(op, 3));
    o.geometry.setAttribute('aON', new THREE.BufferAttribute(on, 3));
  }
}

const VERT_HEAD = 'attribute vec3 aOP;\nattribute vec3 aON;\nvarying vec3 vOP;\nvarying vec3 vON;';
const GLSL_HEAD = `uniform vec3 uC0,uC1,uC2,uE0,uE1; uniform float uType,uK,uPix,uSeed,uTime;
varying vec3 vOP; varying vec3 vON;
float h3(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float vn(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);
 return mix(mix(mix(h3(i),h3(i+vec3(1,0,0)),f.x),mix(h3(i+vec3(0,1,0)),h3(i+vec3(1,1,0)),f.x),f.y),
 mix(mix(h3(i+vec3(0,0,1)),h3(i+vec3(1,0,1)),f.x),mix(h3(i+vec3(0,1,1)),h3(i+vec3(1,1,1)),f.x),f.y),f.z);}
float fbm(vec3 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*vn(p);p*=2.03;a*=.5;}return s;}
float weave(vec2 q){return mix(fract(q.x),fract(q.y),mod(floor(q.x)+floor(q.y),2.));}`;
const GLSL_BODY = `{
 float lum=dot(diffuseColor.rgb,vec3(.333)); float k=clamp(lum/.5,.35,1.35);
 vec3 p=vOP*uK; vec3 V=normalize(vViewPosition);
 float fr=pow(1.-clamp(abs(dot(V,normal)),0.,1.),1.8);
 if(uType<.5){
  if(uPix>.5) p=floor(p*2.)/2.;
  float m1=smoothstep(.45,.5,fbm(p+uSeed)), m2=smoothstep(.55,.6,fbm(p*1.7+uSeed*2.));
  diffuseColor.rgb=mix(mix(uC0,uC1,m1),uC2,m2)*k;
 } else if(uType<1.5){ diffuseColor.rgb=uC0*k;
 } else if(uType<2.5){
  vec3 w=abs(vON)+.0001; w/=(w.x+w.y+w.z);
  float t=weave(p.yz)*w.x+weave(p.xz)*w.y+weave(p.xy)*w.z;
  diffuseColor.rgb=uC0*(.5+1.1*t)*k;
 } else if(uType<3.5){
  vec3 irid=mix(uE0,uE1,.5+.5*sin((fbm(p*.8)+fr*1.2)*6.2831));
  diffuseColor.rgb=mix(uC0,irid,.2+.65*fr)*k;
 } else {
  diffuseColor.rgb=uC0*k;
  float line=smoothstep(.93,1.,sin(p.z*6.2831-uTime*3.));
  totalEmissiveRadiance+=uE0*(line*.9+fr*.7*(.65+.35*sin(uTime*2.)))*step(.3,lum);
 }
}`;
const col = n => new THREE.Color(n ?? 0);

// نسخة معدّلة من مادة النموذج بنمط السكن (تُترك الزجاجيات والمحركات كما هي)
export function skinMaterial(src, key) {
  const d = SKIN_DEFS[key],
    m = src.clone();
  if (!d || m.transparent || KEEP.test(m.name || '')) return m;
  if (d.met != null) m.metalness = d.met;
  if (d.rough != null) m.roughness = d.rough;
  const u = {
    uType: {value: SKIN_TYPES.indexOf(d.t)},
    uK: {value: d.k},
    uPix: {value: d.px || 0},
    uSeed: {value: d.seed || 0},
    uC0: {value: col(d.c[0])},
    uC1: {value: col(d.c[1])},
    uC2: {value: col(d.c[2])},
    uE0: {value: col(d.e && d.e[0])},
    uE1: {value: col(d.e && d.e[1])},
    uTime: SKU.time
  };
  m.onBeforeCompile = sh => {
    Object.assign(sh.uniforms, u);
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\n' + VERT_HEAD)
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvOP=aOP;\nvON=aON;');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\n' + GLSL_HEAD)
      .replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n' + GLSL_BODY);
  };
  m.customProgramCacheKey = () => 'skin1';
  return m;
}
