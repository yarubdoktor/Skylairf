/* تعريف مظاهر السكنات (بند #2): بيانات صرفة (بلا three) كي تُختبر بـ node.
   المفتاح = نفس مفتاح SKINS بـ data.js. النماذج GLB بلا خامات ولا UV، فالأنماط تُحسب بالشيدر
   من إحداثيات النموذج (انظر apply.js) — لا أصول مطلوبة.
   t نوع النمط: camo تمويه ضوضاء · solid دهان/معدن · carbon نسيج كربون ·
   pearl لؤلؤي متغيّر بزاوية النظر · neon خطوط متوهجة. c ألوان النمط (حتى 3) · e لون التوهج/التدرج ·
   k تردد النمط (أكبر = أدق) · met/rough ثوابت PBR · px بكسلي · seed بذرة. */
export const SKIN_TYPES = ['camo', 'solid', 'carbon', 'pearl', 'neon'];
export const SKIN_DEFS = {
  gray: null, // الأصلي: خامات النموذج كما هي
  desert: {t: 'camo', c: [0xc9b074, 0x9c8654, 0x6a5b3c], k: 6, met: 0.1, rough: 0.7, seed: 3.1},
  forest: {t: 'camo', c: [0x5f7d4e, 0x3d5535, 0x222d1e], k: 6, met: 0.1, rough: 0.7, seed: 8.4},
  arctic: {t: 'camo', c: [0xe6eef6, 0xb5c5d6, 0x8497ad], k: 5, met: 0.1, rough: 0.6, seed: 1.7},
  night: {t: 'camo', c: [0x262a31, 0x16181d, 0x0a0b0e], k: 6, met: 0.2, rough: 0.55, seed: 5.2},
  digital: {t: 'camo', c: [0x7d8f9d, 0x46586a, 0x1e2a36], k: 8, px: 1, met: 0.1, rough: 0.65, seed: 2.6},
  crimson: {t: 'solid', c: [0xa02626], k: 1, met: 0.55, rough: 0.28},
  gold: {t: 'solid', c: [0xe0b83a], k: 1, met: 1, rough: 0.22},
  chrome: {t: 'solid', c: [0xe3eaf2], k: 1, met: 1, rough: 0.05},
  carbon: {t: 'carbon', c: [0x1b1e25], k: 24, met: 0.25, rough: 0.32},
  pearl: {t: 'pearl', c: [0xeae6f2], e: [0x7fd0ff, 0xff8fd8], k: 4, met: 0.45, rough: 0.2},
  neon: {t: 'neon', c: [0x0b1017], e: [0x22e6ff], k: 6, met: 0.35, rough: 0.35}
};
export const SKIN_IDS = Object.keys(SKIN_DEFS);
export const needsAnim = k => !!SKIN_DEFS[k] && SKIN_DEFS[k].t === 'neon';
