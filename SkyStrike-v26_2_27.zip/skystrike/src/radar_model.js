/* منطق الرادار (بند #15) — دوال صرفة بلا DOM حتى تنختبر بـ node (tools/test/test_radar.mjs). الرسم بـ radar.js. */
export const RANGES = [1300, 2200, 700]; // أنصاف أقطار الرادار بالمتر (S.rz يختار؛ لمسة على الرادار تبدّل)
export const ALT_BAND = 120; // فرق ارتفاع (م) يظهر بعده سهم فوق/تحت
export const MIS_RANGE = 1000; // صاروخ عدو أقرب من هذا = إنذار
const TAU = Math.PI * 2;

/* موضع نقطة العالم (wx,wz) على الرادار بإحداثيات موحّدة: nx يمين، ny أمام (كلاهما ضمن دائرة نصف قطرها 1). edge = خارج المدى (مقصوصة للحافة) */
export function plot(px, pz, yaw, wx, wz, R) {
  const dx = wx - px,
    dz = wz - pz,
    sn = Math.sin(yaw),
    cs = Math.cos(yaw);
  let X = dx * cs - dz * sn,
    F = -(dx * sn + dz * cs);
  const m = Math.hypot(X, F),
    edge = m > R;
  if (edge) {
    X *= R / m;
    F *= R / m;
  }
  return {nx: X / R, ny: F / R, edge};
}

/* 1 = الهدف أعلى منك بوضوح، -1 = أخفض، 0 = بنفس الارتفاع تقريباً */
export const altClass = dy => (dy > ALT_BAND ? 1 : dy < -ALT_BAND ? -1 : 0);

/* توهّج النقطة: يسطع لحظة مرور المسح عليها ثم يخفت لحد أدنى (ما تختفي). الزوايا بإحداثيات الكانفس (راديان) */
export function sweepGlow(blipAng, sweepAng) {
  let d = (sweepAng - blipAng) % TAU;
  if (d < 0) d += TAU;
  return 0.3 + 0.7 * (1 - d / TAU);
}

/* شكل/حجم/لون كل نوع عدو. الأشكال: circle · ring (دائرة مجوّفة) · diamond · square · triangle */
export const STYLE = {
  jet: {shape: 'circle', r: 6, color: '#ff3b3b'},
  drone: {shape: 'circle', r: 3.5, color: '#ff9a9a'},
  bomber: {shape: 'ring', r: 8, color: '#ff5a3b'},
  heli: {shape: 'diamond', r: 7, color: '#ff6b6b'},
  boss: {shape: 'ring', r: 11, color: '#ff2bd6'},
  turret: {shape: 'square', r: 5, color: '#ff9a2f'},
  flak: {shape: 'square', r: 5, color: '#ffb02f'},
  sam: {shape: 'triangle', r: 7, color: '#ff6a2f'},
  ship: {shape: 'square', r: 8, color: '#ff8a2f'}
};
export const styleOf = e => {
  const s = STYLE[e.kind] || (e.air ? STYLE.jet : STYLE.turret);
  return e.elite ? {...s, elite: true} : s;
};

/* تهديد صواريخ العدو: العدد داخل المدى + هل أحدها يقترب منك فعلاً (اتجاهه نحوك) + أقرب مسافة */
export function missileThreat(pos, projs) {
  let count = 0,
    closing = false,
    nearest = Infinity;
  for (const p of projs) {
    if (p.owner !== 'e' || !p.mis) continue;
    const m = p.mesh.position,
      dx = pos.x - m.x,
      dy = pos.y - m.y,
      dz = pos.z - m.z,
      d = Math.hypot(dx, dy, dz);
    if (d > MIS_RANGE) continue;
    count++;
    nearest = Math.min(nearest, d);
    if (p.dir && (p.dir.x * dx + p.dir.y * dy + p.dir.z * dz) / (d || 1) > 0.3) closing = true;
  }
  return {count, closing, nearest};
}
