/* عرض الأسلحة + لهب المحرك داخل استوديو المعاينة (بند #3). كل التأثيرات بجسيمات fx.js (مشهد المعاينة نفسه).
   الطائرة ثابتة عند الأصل وأنفها نحو −z (مثل اللعبة)؛ المقذوفات تُطلق نحو −z. */
import * as THREE from 'three';
import {BULLET_GEO, BULLET_P, mkMsl, mkBomb} from './jets.js';
import {PFL} from './craft/roster.js';
import {showDue, SHOW_LEN, GUN_BURST} from './hangar_math.js';
import {FLOOR_Y} from './hangar_scene.js';

const rnd = (a, b) => a + Math.random() * (b - a);
export function createShow(scene, fx) {
  const live = [];
  let T = 0,
    on = false,
    gunT = 0,
    gunAcc = 0,
    side = 1,
    kind = 0;
  const hold = (m, o) => {
    scene.add(m);
    live.push({m, ...o});
  };
  const drop = i => {
    scene.remove(live[i].m);
    live.splice(i, 1);
  };
  function launch(e) {
    const f = PFL[kind] || PFL[0];
    if (e.k === 'gun') gunT = GUN_BURST;
    else if (e.k === 'msl') {
      const m = mkMsl(false);
      m.position.set(e.side * f.wt.x * 0.55, f.wt.y - 0.55, f.wt.z - 1);
      m.lookAt(m.position.x, m.position.y, m.position.z - 10); // أنف المقذوف = +z محلياً
      hold(m, {t: 0, life: 0.95, k: 'msl', v: 8});
    } else if (e.k === 'bomb') {
      const m = mkBomb();
      m.position.set(0, -1.5, 0.5);
      hold(m, {t: 0, life: 2, k: 'bomb', vy: -2, vz: -4});
    } else if (e.k === 'flr') {
      for (let i = 0; i < 6; i++) {
        const m = new THREE.Object3D();
        m.position.set(rnd(-1.8, 1.8), -1, 4);
        hold(m, {t: 0, life: rnd(1.4, 2), k: 'flr', vx: rnd(-7, 7), vy: rnd(-5, -1), vz: rnd(12, 22)});
      }
    }
  }
  function step(dt) {
    for (let i = live.length - 1; i >= 0; i--) {
      const o = live[i],
        p = o.m.position;
      o.t += dt;
      if (o.k === 'msl') {
        o.v += dt * 150; // تسارع المحرك
        p.z -= o.v * dt;
        fx.glow(p.x, p.y, p.z + 2.4, 0xffc060, 2.2, 0.8, 0.14, 0, 0, 10, 0.95);
        fx.smk(p.x, p.y, p.z + 2.6, 0xd8dde6, 0.8, 3.2, 0.9, 0, 0.5, 2, 0.5);
        if (o.t > o.life) {
          fx.explode(new THREE.Vector3(p.x, p.y, p.z), 9);
          drop(i);
        }
      } else if (o.k === 'bomb') {
        o.vy -= dt * 22;
        p.y += o.vy * dt;
        p.z += o.vz * dt;
        o.m.rotation.x = Math.min(0.9, o.t * 1.1); // تميل نحو الأمام أثناء السقوط
        if (p.y <= FLOOR_Y + 0.5) {
          fx.explode(new THREE.Vector3(p.x, FLOOR_Y + 0.3, p.z), 5);
          drop(i);
        }
      } else if (o.k === 'flr') {
        o.vy -= dt * 3;
        p.x += o.vx * dt;
        p.y += o.vy * dt;
        p.z += o.vz * dt;
        o.vx *= 1 - dt * 0.8;
        o.vz *= 1 - dt * 1.2;
        fx.glow(p.x, p.y, p.z, 0xfff0c0, 2.4, 0.6, 0.3, 0, 0, 0, 1);
        fx.smk(p.x, p.y, p.z, 0xffffff, 0.6, 2.6, 0.8, 0, 0.3, 0, 0.35);
        if (o.t > o.life) drop(i);
      }
      if (o.k === 'blt' ? o.t > o.life : o.t > 4) drop(i);
    }
  }
  function gun(dt) {
    gunT -= dt;
    gunAcc += dt * 26; // طلقات/ث
    while (gunAcc >= 1) {
      gunAcc -= 1;
      side = -side;
      const b = new THREE.Mesh(BULLET_GEO, BULLET_P);
      b.scale.set(1, 1, 5);
      b.position.set(side * 0.75, -0.3, -5.8);
      hold(b, {t: 0, life: 0.5, k: 'blt'});
      fx.glow(b.position.x, b.position.y, b.position.z, 0xffd070, 3, 0.5, 0.07, 0, 0, 0, 1);
    }
  }
  function flames() {
    const f = PFL[kind] || PFL[0];
    for (const x of f.xs) {
      fx.glow(x, f.y, f.z, f.fc, f.sc * 3.2, f.sc * 0.8, 0.17, 0, 0, 16, 0.9);
      fx.glow(x, f.y, f.z - 0.2, 0xffffff, f.sc * 1.6, f.sc * 0.4, 0.1, 0, 0, 10, 0.95);
    }
  }
  const proto = {
    set kind(k) {
      kind = k;
    },
    get on() {
      return on;
    },
    setOn(v) {
      on = v;
      T = 0;
      gunT = 0;
      if (!v) this.clear();
    },
    clear() {
      while (live.length) drop(0);
    },
    update(dt) {
      flames();
      if (on) {
        for (const e of showDue(T, T + dt)) launch(e);
        T = (T + dt) % SHOW_LEN;
        if (gunT > 0) gun(dt);
      }
      for (const o of live) if (o.k === 'blt') o.m.position.z -= 260 * dt;
      step(dt);
      fx.update(dt);
    }
  };
  return proto;
}
