/* رسم الرادار (بند #15): مسح دوّار بذيل متلاشٍ + توهّج النقاط عند مرور المسح، أشكال/ألوان حسب النوع،
   أسهم ارتفاع (فوق/تحت)، صواريخ العدو + إنذار (حدود حمراء تومض)، وتكبير بلمسة (S.rz). المنطق بـ radar_model.js. */
import {$} from './util.js';
import {S, save} from './save.js';
import {W, P} from './state.js';
import {RANGES, plot, altClass, sweepGlow, styleOf, missileThreat} from './radar_model.js';

const rc = $('#radar'),
  cx = rc.getContext('2d'),
  SZ = 240,
  C = 120,
  K = C - 10;
rc.style.pointerEvents = 'auto';
rc.addEventListener('pointerdown', e => {
  e.preventDefault();
  S.rz = ((S.rz | 0) + 1) % RANGES.length;
  save();
  acc = 1;
});
let acc = 1; // مؤقت: نرسم ~30 فريم/ث (يوفّر بطارية الجوال)
const GREEN = '95,227,161';

function shape(s, x, y, r) {
  cx.beginPath();
  if (s === 'circle' || s === 'ring') cx.arc(x, y, r, 0, 6.283);
  else if (s === 'square') cx.rect(x - r, y - r, r * 2, r * 2);
  else if (s === 'diamond') {
    cx.moveTo(x, y - r);
    cx.lineTo(x + r, y);
    cx.lineTo(x, y + r);
    cx.lineTo(x - r, y);
    cx.closePath();
  } else {
    cx.moveTo(x, y - r);
    cx.lineTo(x + r, y + r * 0.8);
    cx.lineTo(x - r, y + r * 0.8);
    cx.closePath();
  }
  if (s === 'ring') {
    cx.lineWidth = 3;
    cx.stroke();
  } else cx.fill();
}
function chevron(x, y, up) {
  cx.beginPath();
  const d = up ? -1 : 1;
  cx.moveTo(x - 3, y - d * 2);
  cx.lineTo(x, y + d * 2);
  cx.lineTo(x + 3, y - d * 2);
  cx.lineWidth = 1.6;
  cx.stroke();
}

export function radarUpdate(dt) {
  acc += dt;
  if (acc < 0.033) return;
  acc = 0;
  const G = W.G,
    R = RANGES[S.rz | 0] || RANGES[0],
    p = P.g.position,
    sweep = (G.t * 2.5) % 6.283;
  const th = missileThreat(p, W.projs),
    flash = th.count && ((G.t * 6) | 0) % 2 === 0;
  cx.clearRect(0, 0, SZ, SZ);
  cx.save();
  cx.beginPath();
  cx.arc(C, C, C - 2, 0, 6.283);
  cx.fillStyle = 'rgba(8,24,18,.62)';
  cx.fill();
  cx.strokeStyle = th.count ? (flash ? '#ff3b3b' : 'rgba(255,59,59,.45)') : `rgba(${GREEN},.75)`;
  cx.lineWidth = 3;
  cx.stroke();
  cx.clip();
  cx.strokeStyle = `rgba(${GREEN},.25)`;
  cx.lineWidth = 1.5;
  for (const r of [K / 3, (K * 2) / 3]) {
    cx.beginPath();
    cx.arc(C, C, r, 0, 6.283);
    cx.stroke();
  }
  cx.beginPath();
  cx.moveTo(C, 0);
  cx.lineTo(C, SZ);
  cx.moveTo(0, C);
  cx.lineTo(SZ, C);
  cx.stroke();
  for (let i = 0; i < 14; i++) {
    const a0 = sweep - i * 0.06;
    cx.fillStyle = `rgba(${GREEN},${0.28 * (1 - i / 14)})`; // ذيل المسح
    cx.beginPath();
    cx.moveTo(C, C);
    cx.arc(C, C, C, a0 - 0.06, a0);
    cx.closePath();
    cx.fill();
  }
  cx.strokeStyle = `rgba(${GREEN},.7)`;
  cx.lineWidth = 2;
  cx.beginPath();
  cx.moveTo(C, C);
  cx.lineTo(C + Math.cos(sweep) * C, C + Math.sin(sweep) * C);
  cx.stroke();
  const at = (wx, wz) => {
    const o = plot(p.x, p.z, P.yaw, wx, wz, R);
    return {x: C + o.nx * K, y: C - o.ny * K, edge: o.edge, o};
  };
  if (G.obj) {
    const q = at(G.obj.x, G.obj.z);
    cx.globalAlpha = q.edge ? 0.6 : 1;
    cx.fillStyle = '#5fd8ff';
    shape('diamond', q.x, q.y, 9);
  }
  for (const e of W.enemies) {
    const q = at(e.g.position.x, e.g.position.z),
      st = styleOf(e),
      g = sweepGlow(Math.atan2(q.y - C, q.x - C), sweep);
    cx.globalAlpha = (q.edge ? 0.55 : 1) * g;
    cx.fillStyle = cx.strokeStyle = st.color;
    shape(st.shape, q.x, q.y, st.r);
    if (st.elite) {
      cx.lineWidth = 1.5;
      cx.beginPath();
      cx.arc(q.x, q.y, st.r + 3.5, 0, 6.283);
      cx.stroke();
    }
    if (e.air) {
      const a = altClass(e.g.position.y - p.y);
      if (a) chevron(q.x + st.r + 6, q.y, a > 0);
    }
  }
  cx.globalAlpha = 1;
  for (const m of W.projs) {
    if (m.owner !== 'e' || !m.mis) continue;
    const q = at(m.mesh.position.x, m.mesh.position.z);
    if (q.edge) continue;
    cx.fillStyle = flash || !th.count ? '#ffe14d' : '#ff8a3b';
    shape('triangle', q.x, q.y, 4);
  }
  cx.fillStyle = '#9fd8ff';
  cx.beginPath();
  cx.moveTo(C, C - 10);
  cx.lineTo(C - 7, C + 8);
  cx.lineTo(C + 7, C + 8);
  cx.closePath();
  cx.fill();
  cx.fillStyle = `rgba(${GREEN},.85)`;
  cx.font = 'bold 18px sans-serif';
  cx.textAlign = 'center';
  cx.fillText((R / 1000).toFixed(1) + ' km', C, SZ - 14);
  cx.restore();
}
