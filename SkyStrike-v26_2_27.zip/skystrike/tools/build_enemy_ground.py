#!/usr/bin/env python3
"""بند #16 (v26.2.27): أرضيات/مروحية/مسيّرة العدو HD بخامات PBR مولّدة (Gepard · SAM · الهيلوكبتر · المسيّرة).
تشغيل: python3 tools/build_enemy_ground.py [gepard sam heli drone] [--preview] → src/models/e_<name>.glb
العقد (تقرأها اللعبة): body دائماً · aim (برج الأرضيات، الفوهة +Z، المحور = موضع العقدة) · rotor (حول Y) / rotor2 (حول X) بالهيلوكبتر.
المقاييس تطابق النماذج السابقة (gscale.js › GSCALE.size: gepard 16.8 · sam 15.4)؛ النسخ القديمة بـ models_src/retired/."""
import sys, os, math
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from hdlib import (loft, cbox, box, extrude, cyl, ellipsoid, place, cat, rot, Model, uv_planar, vcolors,
                   tex_paint, tex_metal, tex_rubber, write_glb_hd, render_model)
from build_enemy_jets import mir, fuselage

OUT = os.path.join(os.path.dirname(__file__), '..', 'src', 'models')
TILE = {'paint': 9.0, 'metal': 6.0, 'rubber': 3.0}

class B:
    """بنّاء: add(node, kind, prim) و both(...). إحداثيات aim/rotor نسبة لمحور عقدتها (المحور يُكتب بالعقدة بالـGLB)"""
    def __init__(self, pivots=None): self.m = Model(ground=True); self.pv = pivots or {}
    def add(self, node, kind, p, t=(0, 0, 0), R=None):
        if R is not None or any(t): p = place(p, R, t)
        self.m.add(node, kind, p); return self
    def both(self, node, kind, p, t=(0, 0, 0), R=None):
        if R is not None or any(t): p = place(p, R, t)
        self.add(node, kind, p); self.add(node, kind, mir(p)); return self

def wheel(b, node, x, y, z, r, w, kind='metal'): b.add(node, kind, cyl((x, y, z), r, w, 'x', seg=12))

def barrel(b, node, x, y, z0, z1, r):
    L = z1 - z0; b.add(node, 'metal', cyl((x, y, (z0 + z1) / 2), r, L, 'z', seg=10))
    b.add(node, 'metal', cyl((x, y, z0 + L * .22), r * 1.7, L * .44, 'z', seg=10))        # غلاف
    b.add(node, 'metal', cyl((x, y, z1 - .35), r * 1.5, .7, 'z', seg=10, r2=r * 1.2))     # كابح الفوهة

# ------------------------------------------------------------------ Gepard
def gepard():
    pv = {'aim': (0, 3.12, 0)}; b = B(pv); H = 'body'
    # الهيكل: مقطع جانبي (z,y) بسماكة x
    b.add(H, 'paint', extrude([(-5.8, .8), (-5.8, 2.0), (-4.9, 2.55), (3.6, 2.6), (5.8, 1.7), (5.8, .8)], -3.0, 3.0, plane='zy'))
    b.add(H, 'paint', cbox((0, 2.7, -3.2), (4.6, .35, 3.6), .12))                         # سطح المحرك
    b.add(H, 'metal', cbox((0, 2.9, -3.6), (3.0, .12, 2.2), .04))                          # شبك التهوية
    b.both(H, 'metal', cyl((2.4, 2.9, -5.5), .22, .9, 'y', seg=8))                         # عوادم
    b.both(H, 'metal', cbox((1.8, 2.2, 5.9), (.9, .5, .25), .08))                          # مصابيح أمامية
    # الجنازير + العجلات + الواقيات
    for s in (-1, 1):
        t = extrude([(-5.6, .9), (-5.0, 0), (5.0, 0), (5.9, 1.05), (4.8, 1.95), (-4.8, 1.95)], 2.85, 4.65, plane='zy')
        b.add(H, 'rubber', t if s > 0 else mir(t))
        b.add(H, 'paint', place(box((0, 0, 0), (.14, 1.0, 9.6)), None, (s * 4.72, 2.25, -.2)))  # واقي جانبي
    for z in np.linspace(-4.2, 4.2, 6): wheel(b, H, 4.62, .95, z, .78, .3); wheel(b, H, -4.62, .95, z, .78, .3)
    for z in (-5.1, 5.1): wheel(b, H, 4.62, 1.15, z, .95, .3); wheel(b, H, -4.62, 1.15, z, .95, .3)
    # البرج (محوره 0,3.12,0): خانة + قوس + سلاحان 35 مم + رادارات
    A = 'aim'
    b.add(A, 'paint', cbox((0, .55, -.4), (4.4, 2.2, 6.2), .35))
    b.add(A, 'paint', place(box((0, 0, 0), (3.2, 1.3, 1.6)), None, (0, .7, 3.4)))           # مانتليت
    b.both(A, 'paint', cbox((2.45, .35, -.6), (.9, 1.5, 3.6), .15))                         # صناديق الذخيرة
    b.both(A, 'metal', place(box((0, 0, 0), (.1, .9, 2.2)), None, (2.93, .3, -.6)))
    for x in (-1.25, 1.25): barrel(b, A, x, .8, 3.0, 11.0, .24)
    b.add(A, 'metal', cyl((0, -.35, 0), 2.1, .5, 'y', seg=16))                              # حلقة البرج
    # رادار التتبع (أمام) + رادار البحث (خلف، ساق + شبكة)
    b.add(A, 'gray', ellipsoid((0, 2.15, 1.6), (1.0, .8, .45), seg=12, lat=6))
    b.add(A, 'metal', cyl((0, 1.75, 1.4), .15, .8, 'y', seg=8))
    b.add(A, 'metal', cyl((0, 2.1, -2.4), .18, 1.9, 'y', seg=8))
    b.add(A, 'gray', place(box((0, 0, 0), (3.4, 1.5, .18)), rot(-12, 0, 0), (0, 3.4, -2.5)))
    b.add(A, 'accent', place(box((0, 0, 0), (3.4, .22, .22)), rot(-12, 0, 0), (0, 4.15, -2.35)))
    b.add(A, 'glass', place(box((0, 0, 0), (1.2, .45, .2)), None, (-1.0, 1.2, 2.6)))        # بصريات
    return b.m, {'paint': 1, 'rubber': 1}

# ------------------------------------------------------------------ SAM (شاحنة 6x6 + منصة 4 صواريخ، الفوهة +Z)
def sam():
    pv = {'aim': (0, 3.0, -1.0)}; b = B(pv); H = 'body'
    b.add(H, 'paint', cbox((0, 1.55, -.2), (3.0, .8, 13.6), .15))                           # الشاسيه
    b.add(H, 'paint', extrude([(3.5, 1.9), (3.5, 4.0), (4.9, 4.3), (6.5, 3.4), (6.8, 1.9)], -1.45, 1.45, plane='zy'))  # المقصورة
    b.add(H, 'glass', place(box((0, 0, 0), (2.6, 1.0, .1)), rot(-28, 0, 0), (0, 3.55, 6.15)))
    b.both(H, 'glass', place(box((0, 0, 0), (.08, .9, 1.3)), None, (1.47, 3.3, 4.7)))
    b.add(H, 'paint', cbox((0, 2.3, -3.4), (3.0, 1.0, 6.4), .2))                            # صندوق المعدات
    b.both(H, 'paint', cbox((1.55, 1.25, 0), (.6, .8, 3.4), .1))                            # خزانات
    for z in (-5.0, -2.4, 4.9):
        for s in (-1, 1): wheel(b, H, s * 2.05, 1.05, z, 1.05, .9, 'rubber'); wheel(b, H, s * 2.05, 1.05, z, .45, .95)
    b.both(H, 'metal', cbox((2.1, .55, -6.6), (.7, .5, .6), .08))                           # دعامات التثبيت
    b.both(H, 'metal', cbox((2.1, .55, 1.3), (.7, .5, .6), .08))
    b.both(H, 'metal', cbox((.95, 2.0, 6.85), (.5, .3, .15), .04))
    b.add(H, 'accent', place(box((0, 0, 0), (2.4, .12, .12)), None, (0, 4.5, 4.8)))         # بارة تحذير
    # المنصة (محور 0,3.0,-1.0): قاعدة دوّارة + إطار + 4 حاويات + رؤوس الصواريخ
    A = 'aim'
    b.add(A, 'metal', cyl((0, -.35, 0), 1.9, .7, 'y', seg=16))
    b.add(A, 'paint', cbox((0, .45, .8), (3.0, .6, 6.0), .12))
    b.both(A, 'paint', cbox((1.45, 1.0, 0), (.3, 2.0, 1.4), .06))
    for x in (-.78, .78):
        for y in (.9, 2.05):
            b.add(A, 'paint', cbox((x, y, 3.5), (1.0, 1.0, 11.0), .12))
            b.add(A, 'metal', place(box((0, 0, 0), (.8, .8, .08)), None, (x, y, -2.05)))   # مؤخرة
            b.add(A, 'white', cyl((x, y, 9.0), .3, 1.0, 'z', seg=10, r2=.05))              # رأس الصاروخ البارز
            b.add(A, 'accent', cyl((x, y, 8.45), .31, .2, 'z', seg=10))
    return b.m, {'paint': 1, 'rubber': 1}

# ------------------------------------------------------------------ هيلوكبتر هجومية (الأنف −Z، الذيل +Z)
def blade_set(n, R, r0, chord):
    parts = []
    for i in range(n):
        bl = cat(box(((r0 + R) / 2, 0, 0), (R - r0, .07, chord)), box((R * .93, .0, 0), (R * .14, .075, chord * .6)))
        parts.append(place(bl, rot(0, 360 * i / n, 0)))
    return cat(*parts)

def heli():
    pv = {'rotor': (0, 2.01, -2.05), 'rotor2': (-.6, 1.51, 8.55)}; b = B(pv); H = 'body'
    secs = [(-7.0, .05, .05, .05, -.5), (-6.2, .55, .5, .5, -.6), (-4.6, 1.25, 1.05, 1.0, -.1), (-1.5, 1.6, 1.25, 1.1, .15),
            (1.5, 1.4, 1.15, 1.0, .15), (4.0, .9, .7, .6, .45), (7.0, .35, .35, .3, .7), (8.0, .25, .28, .22, .9)]
    b.add(H, 'paint', fuselage(secs, k=14, n=2.4))
    b.add(H, 'glass', ellipsoid((0, .75, -4.6), (.85, .62, 1.7), seg=12, lat=6))             # مظلة الطيار
    b.add(H, 'glass', ellipsoid((0, 1.05, -2.7), (.9, .7, 1.2), seg=12, lat=6))              # مظلة الرامي
    b.add(H, 'metal', cyl((0, -.95, -6.4), .42, .8, 'z', seg=10))                            # برج الحساسات
    b.add(H, 'glass', cyl((0, -.95, -6.85), .3, .1, 'z', seg=10))
    b.both(H, 'paint', cbox((.95, 1.55, .3), (.85, .75, 3.6), .2))                           # غلاف المحركين
    b.both(H, 'metal', cyl((.95, 1.55, 2.2), .36, .5, 'z', seg=10))
    b.add(H, 'paint', cbox((0, 1.75, -2.05), (.9, .5, .9), .1))                              # صندوق التروس
    b.add(H, 'metal', cyl((0, 2.0, -2.05), .17, .6, 'y', seg=8))                             # عمود الدوار
    b.add(H, 'paint', extrude([(6.4, .4), (8.5, 2.9), (9.0, 2.9), (8.9, .4)], -.07, .07, plane='zy'))  # الزعنفة
    b.add(H, 'paint', extrude([(7.0, .0), (8.6, 0), (8.9, .4), (7.5, .4)], -.07, .07, plane='zx'), t=(0, .5, 0)) if False else None
    for s in (-1, 1): b.add(H, 'paint', place(extrude([(6.6, 0), (7.8, 1.9), (8.5, 1.9), (8.3, 0)], -.06, .06, plane='zx'), None, (0, .55, 0)) if s > 0 else mir(place(extrude([(6.6, 0), (7.8, 1.9), (8.5, 1.9), (8.3, 0)], -.06, .06, plane='zx'), None, (0, .55, 0))))
    # أجنحة قصيرة + حوامل صواريخ وأغطية صواريخ
    w = extrude([(-1.2, .4), (.2, 3.0), (1.0, 3.0), (1.3, .4)], -.07, .07, plane='zx')
    b.both(H, 'paint', place(w, None, (0, .05, 0)))
    for x in (1.9, 2.8):
        b.both(H, 'paint', cyl((x, -.12, -.1), .3, 2.6, 'z', seg=10, r2=.3))
        b.both(H, 'white', cyl((x, -.12, -1.55), .3, .1, 'z', seg=10))
    b.both(H, 'accent', cbox((2.95, .05, .1), (.12, .1, .5), .03))
    # الهبوط: عجلتان أماميتان وخلفية
    for (x, z) in ((.95, -3.2), (-.95, -3.2), (0, 5.0)):
        b.add(H, 'metal', cyl((x, -1.05, z), .08, 1.2, 'y', seg=6)); b.add(H, 'rubber', cyl((x, -1.75, z), .32, .26, 'x', seg=10))
    b.add(H, 'metal', cyl((0, -.7, -5.2), .06, .5, 'z', seg=6))                              # مدفع الذقن
    b.add(H, 'metal', cyl((0, -.7, -6.3), .07, 1.6, 'z', seg=6))
    # دوار رئيسي (4 شفرات) ودوار ذيل (4 شفرات)
    b.add('rotor', 'rotorm', blade_set(4, 9.2, .5, .62))
    b.add('rotor', 'metal', cyl((0, .15, 0), .5, .35, 'y', seg=10))
    for sy, sz in ((1, 0), (-1, 0), (0, 1), (0, -1)):   # 4 شفرات بمستوى YZ (تدور حول X)
        b.add('rotor2', 'rotorm', box((0, sy * .8, sz * .8), (.07, 1.2 if sy else .26, .26 if sy else 1.2)))
    b.add('rotor2', 'metal', cyl((0, 0, 0), .2, .3, 'x', seg=8))
    return b.m, {'paint': 1, 'rubber': 1}

# ------------------------------------------------------------------ مسيّرة انتحارية (الأنف −Z، المروحة الدافعة +Z)
def drone():
    b = B(); H = 'body'
    secs = [(-4.0, .03, .03, .03, 0), (-3.4, .3, .28, .28, 0), (-2.0, .5, .45, .45, 0), (.5, .5, .42, .42, 0), (2.4, .38, .3, .3, 0), (3.4, .22, .2, .2, 0)]
    b.add(H, 'paint', fuselage(secs, k=14, n=2.2))
    b.add(H, 'accent', cyl((0, 0, -3.35), .31, .35, 'z', seg=12, r2=.28))                    # حزام الرأس الحربي
    b.add(H, 'eye', ellipsoid((0, -.2, -3.6), (.2, .2, .28), seg=8, lat=5))                  # العين الحمراء
    wing = extrude([(-.4, .3), (2.6, 3.2), (3.3, 3.2), (3.3, .3)], -.05, .05, plane='zx')
    b.both(b, None, None) if False else None
    for s in (-1, 1):
        wp = place(wing, None, (0, .02, 0))
        b.add(H, 'paint', wp if s > 0 else mir(wp))
        fin = place(extrude([(2.4, 0), (3.3, 1.2), (3.3, 0)], -.04, .04, plane='zy'), rot(0, 0, -15 * s), (s * 3.2, 0, 0))
        b.add(H, 'paint', fin)
    b.add(H, 'metal', cyl((0, 0, 3.6), .15, .5, 'z', seg=8))                                  # محور المروحة
    for a in (0, 180): b.add(H, 'rotorm', place(box((0, .0, 0), (.1, 1.5, .25)), rot(0, 0, a), (0, 0, 3.85)))
    b.add(H, 'metal', cyl((0, .38, 1.4), .12, .5, 'y', seg=6))                                # هوائي
    return b.m, {'paint': 1}

def mats(name):
    P = {'gepard': ('#55603f', '#2f3a2a', '#7a6e4c', '#26231f'), 'sam': ('#5a6248', '#363f2d', '#80765a', '#2b2a24'),
         'heli': ('#4a5441', '#2a3128', '#5f6652', '#1d211c'), 'drone': ('#6a6e72', '#4c5055', '#8b8f93', '#33363a')}[name]
    M = {'paint': {'tex': tex_paint(512, palette=P, seed={'gepard': 31, 'sam': 32, 'heli': 33, 'drone': 34}[name], panels=4,
                                    grime=.34 if name != 'drone' else .2, rough=.62, metal=.2)},
         'metal': {'tex': tex_metal(256, base='#2c2f2c', seed=41)},
         'rubber': {'tex': tex_rubber(256, seed=43)},
         'rotorm': {'color': [.07, .08, .08], 'metal': .5, 'rough': .5},
         'gray': {'color': [.52, .55, .58], 'metal': .3, 'rough': .5},
         'white': {'color': [.86, .87, .85], 'metal': .2, 'rough': .4},
         'accent': {'color': [.85, .68, .1] if name in ('gepard', 'sam') else [.62, .09, .08], 'metal': .25, 'rough': .5},
         'eye': {'color': [1, .1, .1], 'emissive': [1, .12, .1]},
         'glass': {'color': [.05, .1, .13], 'metal': .9, 'rough': .1, 'emissive': [.03, .08, .12]}}
    return M

def pack(m):
    nodes = {}
    for node, kind, P, N in m.items():
        UV = uv_planar(P, N, TILE[kind], 'zstripe' if kind == 'rubber' else 'planar') if kind in TILE else None
        nodes.setdefault(node, {})[kind] = (P, N, UV, vcolors(P, N, ground=(node != 'rotor' and node != 'rotor2')))
    return nodes

BUILD = {'gepard': (gepard, {'aim': (0, 3.12, 0)}), 'sam': (sam, {'aim': (0, 3.0, -1.0)}),
         'heli': (heli, {'rotor': (0, 2.01, -2.05), 'rotor2': (-.6, 1.51, 8.55)}), 'drone': (drone, {})}

if __name__ == '__main__':
    names = [a for a in sys.argv[1:] if not a.startswith('--')] or list(BUILD)
    prev = []
    for nm in names:
        fn, pivs = BUILD[nm]; m, _ = fn(); M = mats(nm); g = pack(m)
        nodes = [('body', None, g.pop('body'))] + [(k, pivs[k], v) for k, v in g.items()]
        used = {k for _, _, gr in nodes for k in gr}
        tris = sum(len(P) // 3 for _, _, gr in nodes for (P, _, _, _) in gr.values())
        size = write_glb_hd(os.path.join(OUT, f'e_{nm}.glb'), nodes, {k: v for k, v in M.items() if k in used})
        print(f'e_{nm}.glb: {tris} مثلث، {size // 1024} KB، عقد: {[n[0] for n in nodes]}')
        if '--preview' in sys.argv:
            views = [(35, 20, nm + ' 3/4'), (90, 0, 'side'), (0, 90, 'top')]
            prev.append(render_model(nodes, {k: v for k, v in M.items() if k in used}, views, size=(420, 300)))
    if prev:
        from PIL import Image
        im = Image.new('RGB', (prev[0].width, sum(p.height for p in prev))); y = 0
        for p in prev: im.paste(p, (0, y)); y += p.height
        im.save('/tmp/eground_preview.png'); print('preview ok')
