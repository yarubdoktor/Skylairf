// بند #16 (v26.2.26): مقاتلات العدو HD (e_jet0/1/2.glb) — سلامة الملفات + مقاييسها + الربط + الرجوع للبرمجي.
import {readFileSync} from 'node:fs';
const src = p => new URL('../../src/' + p, import.meta.url);
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
console.log('مقاتلات العدو HD:');
for (let v = 0; v < 3; v++) {
  const b = readFileSync(src(`models/e_jet${v}.glb`)),
    len = b.readUInt32LE(12),
    j = JSON.parse(b.subarray(20, 20 + len).toString());
  const lo = [1e9, 1e9, 1e9],
    hi = [-1e9, -1e9, -1e9];
  let tris = 0;
  for (const me of j.meshes)
    for (const p of me.primitives) {
      const a = j.accessors[p.attributes.POSITION];
      tris += a.count / 3;
      for (let i = 0; i < 3; i++) {
        lo[i] = Math.min(lo[i], a.min[i]);
        hi[i] = Math.max(hi[i], a.max[i]);
      }
    }
  const L = hi[2] - lo[2],
    S = hi[0] - lo[0];
  ok(j.nodes.some(n => n.name === 'body'), `jet${v}: عقدة body`);
  ok(L > 14 && L < 17.5 && S > 10 && S < 13, `jet${v}: الطول ${L.toFixed(1)} والجناح ${S.toFixed(1)} (مثل المجسم القديم)`);
  ok(lo[2] < -8 && hi[2] > 6.5 && hi[2] < 7.2, `jet${v}: الأنف −Z والفوهات تنتهي قرب z=6.7 (${hi[2].toFixed(1)})`);
  ok(Math.abs(lo[0] + hi[0]) < 0.05, `jet${v}: متماثل يمين/يسار`);
  ok(tris > 800 && tris <= 3000, `jet${v}: ${tris} مثلثاً (ميزانية ≤ 3000 لكل مقاتلة عدو)`);
  const kinds = j.materials.map(m => m.name);
  ok(['paint', 'metal', 'glass', 'accent'].every(k => kinds.includes(k)), `jet${v}: المواد ${kinds.join('/')}`);
  ok(j.images && j.images.length >= 6, `jet${v}: خامات PBR مدمجة (${(j.images || []).length})`);
}
const em = readFileSync(src('emodels.js'), 'utf8'),
  fg = readFileSync(src('craft/fighters.js'), 'utf8');
ok([0, 1, 2].every(v => em.includes(`e_jet${v}.glb', import.meta.url).href`)), 'emodels: روابط نصية ثابتة للثلاثة');
ok(/!player && hasEM\('jet' \+ kind\)/.test(fg), 'mkJet: مقاتلة العدو تستعمل HD عند توفرها');
ok(/addMesh|FUS\(\)/.test(fg) || fg.includes('g.add_(FUS(), m)'), 'mkJet: المجسم البرمجي باقٍ كاحتياطي');
if (fail) {
  console.log(`✗ ${fail} فشل`);
  process.exit(1);
}
console.log('✓ test_enemy_jets');
