// بند #15: منطق الرادار (radar_model.js دالة صرفة) — الإسقاط، المدى، الارتفاع، توهّج المسح، الأنواع، إنذار الصواريخ.
import {
  RANGES,
  plot,
  altClass,
  sweepGlow,
  styleOf,
  STYLE,
  missileThreat,
  ALT_BAND,
  MIS_RANGE
} from '../../src/radar_model.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const near = (a, b, e = 1e-9) => Math.abs(a - b) < e;
console.log('الرادار:');
ok(RANGES.length === 3 && RANGES.every(r => r > 0), 'ثلاثة مستويات تكبير');
// الإسقاط: اللاعب عند (0,0) متجه نحو -Z (yaw=0) → الأمام = -Z
let o = plot(0, 0, 0, 0, -650, 1300);
ok(near(o.nx, 0) && near(o.ny, 0.5) && !o.edge, 'هدف أمامك 650م: فوق المركز بنصف المدى');
o = plot(0, 0, 0, 650, 0, 1300);
ok(near(o.nx, 0.5) && near(o.ny, 0), 'هدف على يمينك: يمين المركز');
o = plot(0, 0, 0, 0, 650, 1300);
ok(near(o.ny, -0.5), 'هدف خلفك: تحت المركز');
o = plot(0, 0, Math.PI / 2, -650, 0, 1300);
ok(near(o.ny, 0.5, 1e-9), 'بعد دوران 90°: الأمام يتبع اتجاه الطائرة');
o = plot(0, 0, 0, 0, -5000, 1300);
ok(o.edge && near(Math.hypot(o.nx, o.ny), 1), 'خارج المدى: يُقصّ على حافة الدائرة ويُعلَّم edge');
o = plot(100, 200, 0.7, 100, 200, 1300);
ok(near(o.nx, 0) && near(o.ny, 0), 'نفس موضعك: المركز');
for (const R of RANGES) {
  const q = plot(0, 0, 0.3, R * 0.4, R * 0.3, R);
  ok(Math.hypot(q.nx, q.ny) <= 1 + 1e-9, `المدى ${R}: النقطة داخل الدائرة`);
}
// الارتفاع
ok(
  altClass(ALT_BAND + 1) === 1 && altClass(-ALT_BAND - 1) === -1 && altClass(0) === 0 && altClass(ALT_BAND) === 0,
  'فئات الارتفاع'
);
// توهّج المسح
ok(near(sweepGlow(1, 1), 1), 'لحظة مرور المسح: أقصى توهّج');
ok(sweepGlow(1, 1 + 3.14) < sweepGlow(1, 1 + 0.2), 'يخفت مع ابتعاد المسح');
let mn = 9,
  mx = 0;
for (let a = 0; a < 6.3; a += 0.05) {
  const g = sweepGlow(2, a);
  mn = Math.min(mn, g);
  mx = Math.max(mx, g);
}
ok(mn >= 0.3 - 1e-9 && mx <= 1 + 1e-9, 'التوهّج بين 0.3 و1 (النقطة ما تختفي أبداً)');
ok(sweepGlow(6, 0.5) >= 0.3 && sweepGlow(0.5, 6) <= 1, 'التفاف الزاوية (فرق سالب) سليم');
// الأنواع
const kinds = ['jet', 'drone', 'bomber', 'heli', 'boss', 'turret', 'flak', 'sam'];
ok(
  kinds.every(k => STYLE[k] && STYLE[k].r > 0 && /^#/.test(STYLE[k].color)),
  'كل الأنواع الثمانية لها نمط'
);
ok(new Set(kinds.map(k => STYLE[k].shape + STYLE[k].color)).size === kinds.length, 'كل نوع مميّز (شكل+لون)');
ok(styleOf({kind: 'jet', elite: true}).elite && !styleOf({kind: 'jet'}).elite, 'نخبة العدو تُعلَّم');
ok(
  styleOf({kind: '؟', air: true}).shape === 'circle' && styleOf({kind: '؟', air: false}).shape === 'square',
  'نوع مجهول: بديل آمن (جوي/أرضي)'
);
// صواريخ العدو
const ms = (x, y, z, dir, owner = 'e', mis = true) => ({owner, mis, dir, mesh: {position: {x, y, z}}}),
  me = {x: 0, y: 100, z: 0};
let th = missileThreat(me, []);
ok(th.count === 0 && !th.closing, 'بلا صواريخ: لا إنذار');
th = missileThreat(me, [ms(0, 100, -600, {x: 0, y: 0, z: 1})]);
ok(th.count === 1 && th.closing && near(th.nearest, 600), 'صاروخ متجه إليك: إنذار + يقترب');
th = missileThreat(me, [ms(0, 100, -600, {x: 0, y: 0, z: -1})]);
ok(th.count === 1 && !th.closing, 'صاروخ مبتعد: يُحصى لكن لا يقترب');
th = missileThreat(me, [ms(0, 100, -(MIS_RANGE + 50), {x: 0, y: 0, z: 1})]);
ok(th.count === 0, 'خارج مدى الإنذار: لا يُحصى');
th = missileThreat(me, [ms(0, 100, -300, {x: 0, y: 0, z: 1}, 'p'), ms(0, 100, -300, {x: 0, y: 0, z: 1}, 'e', false)]);
ok(th.count === 0, 'صواريخ اللاعب وطلقات العدو العادية: لا تُحصى');
if (fail) {
  console.log('✗ فشل ' + fail);
  process.exit(1);
}
console.log('✓ نجح الكل');
