// three وهمي صغير لاختبار src/ops/ بـ node: كائنات بمواضع/دوران فقط.
export class Vector3 {
  constructor(x = 0, y = 0, z = 0) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  set(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
    return this;
  }
  copy(v) {
    return this.set(v.x, v.y, v.z);
  }
  clone() {
    return new Vector3(this.x, this.y, this.z);
  }
  distanceToSquared(v) {
    return (this.x - v.x) ** 2 + (this.y - v.y) ** 2 + (this.z - v.z) ** 2;
  }
  distanceTo(v) {
    return Math.sqrt(this.distanceToSquared(v));
  }
}
class Obj {
  constructor() {
    this.position = new Vector3();
    this.rotation = {x: 0, y: 0, z: 0};
    this.scale = {x: 1, y: 1, z: 1, setScalar() {}};
    this.children = [];
    this.visible = true;
  }
  add(c) {
    this.children.push(c);
  }
}
export class Group extends Obj {}
export class Mesh extends Obj {
  constructor(geometry, material) {
    super();
    this.geometry = geometry;
    this.material = material;
  }
}
const geo = class {
  dispose() {}
};
export class TorusGeometry extends geo {}
export class CylinderGeometry extends geo {}
export class MeshBasicMaterial {
  dispose() {}
}
export const AdditiveBlending = 2,
  DoubleSide = 2;
