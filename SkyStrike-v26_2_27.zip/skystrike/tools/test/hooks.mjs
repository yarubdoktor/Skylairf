// يحوّل استيرادات combat.js و ai.js (three/core/state/…) لنسخ وهمية خفيفة، فنختبرهم بـ node بدون متصفح.
const STUBS = new URL('./stubs.mjs', import.meta.url).href;
const STUB_COMBAT = new URL('./stub_combat.mjs', import.meta.url).href;
const SPECS = new Set([
  'three',
  './util.js',
  './i18n.js',
  './audio.js',
  './jets.js',
  './core.js',
  './state.js',
  './ui.js',
  './waves.js',
  './spawn.js'
]);
// مهام src/ops/ (test_ops_sim): كل استيراداتها (three والوحدات الأم) تتحول لنسخ وهمية
const STUB_THREE = new URL('./stub_three.mjs', import.meta.url).href;
const STUBS_OPS = new URL('./stubs_ops.mjs', import.meta.url).href;
const OPS_SPECS = new Set(['../core.js', '../state.js', '../util.js', '../i18n.js', '../audio.js', '../ui.js']);
OPS_SPECS.add('../spawn.js').add('../combat.js').add('../waves.js').add('../enemies.js');
export async function resolve(spec, ctx, next) {
  const p = ctx.parentURL || '';
  if (/\/src\/ops\/[a-z_0-9]+\.js$/.test(p)) {
    if (spec === 'three') return {url: STUB_THREE, shortCircuit: true};
    if (OPS_SPECS.has(spec)) return {url: STUBS_OPS, shortCircuit: true};
  }
  if (/\/(maps|greenland|map7)\.js$/.test(p) && spec === 'three') return {url: STUBS, shortCircuit: true}; // test_ops
  if (/\/(combat|ai)\.js$/.test(p)) {
    if (spec === './combat.js' && /\/ai\.js$/.test(p)) return {url: STUB_COMBAT, shortCircuit: true};
    if (SPECS.has(spec)) return {url: STUBS, shortCircuit: true};
  }
  return next(spec, ctx);
}
