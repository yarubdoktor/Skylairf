// بند #16 (v26.2.27): أرضيات/مروحية/مسيّرة العدو HD (Gepard · SAM · heli · drone) — العقد والمحاور والمقاييس وميزانية المثلثات والخامات.
import {readFileSync} from 'node:fs';
const dir = new URL('../../src/models/', import.meta.url);
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
function info(k) {
  const b = readFileSync(new URL('e_' + k + '.glb', dir)),
    j = JSON.parse(b.subarray(20, 20 + b.readUInt32LE(12)).toString()),
    nd = {};
  for (const n of j.nodes) {
    const t = n.translation || [0, 0, 0],
      lo = [1e9, 1e9, 1e9],
      hi = [-1e9, -1e9, -1e9];
    let tris = 0;
    for (const p of j.meshes[n.mesh].primitives) {
      const a = j.accessors[p.attributes.POSITION];
      tris += a.count / 3;
      for (let i = 0; i < 3; i++) {
        lo[i] = Math.min(lo[i], a.min[i]);
        hi[i] = Math.max(hi[i], a.max[i]);
      }
    }
    nd[n.name] = {t, lo, hi, tris};
  }
  return {j, nd};
}
console.log('أرضيات/مروحية/مسيّرة HD:');
const SPEC = {
  gepard: {nodes: ['body', 'aim'], aim: [0, 3.12, 0], tris: [1200, 4000]},
  sam: {nodes: ['body', 'aim'], aim: [0, 3.0, -1.0], tris: [1200, 4000]},
  heli: {nodes: ['body', 'rotor', 'rotor2'], tris: [1200, 4000]},
  drone: {nodes: ['body'], tris: [300, 2500]}
};
for (const [k, s] of Object.entries(SPEC)) {
  const {j, nd} = info(k),
    tris = Object.values(nd).reduce((a, n) => a + n.tris, 0);
  ok(s.nodes.every(n => nd[n]), `${k}: عقد ${s.nodes.join('/')}`);
  ok(tris >= s.tris[0] && tris <= s.tris[1], `${k}: ${tris} مثلثاً (${s.tris[0]}..${s.tris[1]})`);
  const nm = j.materials.map(m => m.name);
  ok(nm.includes('paint') && nm.includes('metal') && (j.images || []).length >= 6, `${k}: خامات PBR مدمجة (${(j.images || []).length})`);
  if (s.aim) {
    ok(s.aim.every((v, i) => Math.abs(nd.aim.t[i] - v) < 1e-4), `${k}: محور البرج ${s.aim}`);
    ok(nd.aim.hi[2] > 5, `${k}: الفوهة/الصواريخ نحو +Z (${nd.aim.hi[2].toFixed(1)})`);
    ok(nd.aim.lo[1] > -2.6 && nd.aim.hi[1] < 6, `${k}: البرج ضمن حدود معقولة حول محوره`);
  }
}
const h = info('heli').nd;
ok(Math.abs(h.rotor.hi[0] - 9.2) < 0.2 && Math.abs(h.rotor.lo[0] + 9.2) < 0.2, 'heli: دوار رئيسي نصف قطره 9.2 حول محوره');
ok(h.rotor.hi[1] - h.rotor.lo[1] < 1, 'heli: الدوار الرئيسي مسطّح (يدور حول Y)');
ok(Math.abs(h.rotor2.hi[1]) > 1.2 && Math.abs(h.rotor2.hi[2]) > 1.2 && h.rotor2.hi[0] < 0.5, 'heli: دوار الذيل بمستوى YZ (يدور حول X)');
ok(h.body.hi[2] > 8 && h.body.lo[2] < -6.5, 'heli: الأنف −Z والذيل +Z');
const d = info('drone').nd.body;
ok(d.lo[2] < -3.8 && d.hi[2] > 3.8 && d.hi[0] > 3, 'drone: الأنف −Z والمروحة +Z وجناح عريض');
if (fail) {
  console.log(`✗ ${fail} فشل`);
  process.exit(1);
}
console.log('✓ test_enemy_ground');
