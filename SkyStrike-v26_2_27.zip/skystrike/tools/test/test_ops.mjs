// بند #5 (v26.2.16): مهمة «اختراق الوادي» (src/ops/). الجزء الصرف canyon_path.js على تضاريس canyon الحقيقية
// (من maps.js) + فحص الربط (campaign/i18n/hooks) + قاعدة R4 (حجم الملفات). يُشغَّل مع register.mjs (يستبدل three).
import {readFileSync, readdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {
  CANYON,
  fwd,
  buildRoute,
  gateY,
  routeLen,
  passGate,
  cliffSpot,
  parTime,
  timeBonus
} from '../../src/ops/canyon_path.js';
// util.js (يستورده maps.js) يلمس window عند التحميل: نوفّر نسخة وهمية صغيرة قبل الاستيراد
Object.assign(globalThis, {
  innerWidth: 800,
  innerHeight: 600,
  matchMedia: () => ({matches: false}),
  addEventListener() {},
  document: {documentElement: {classList: {toggle() {}}, style: {setProperty() {}}}, getElementById: () => null}
});
const {buildMap} = await import('../../src/maps.js');
const rd = p => readFileSync(fileURLToPath(new URL('../../src/' + p, import.meta.url)), 'utf8');
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
let seed = 12345;
const rnd = (a, b) => {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  return a + (seed / 4294967296) * (b - a);
};
const wrapPi = a => Math.atan2(Math.sin(a), Math.cos(a));

console.log('المسار على تضاريس canyon الحقيقية:');
const {ground} = buildMap('canyon');
for (const [x0, z0, yaw] of [
  [0, 0, 0],
  [3000, -2000, 1.2],
  [-4000, 5000, -2.4]
]) {
  const g = buildRoute(ground, x0, z0, yaw);
  const tag = `(${x0},${z0},${yaw})`;
  ok(g.length === CANYON.n, `${tag} عدد الحلقات ${g.length} = ${CANYON.n}`);
  let px = x0,
    pz = z0,
    ph = yaw,
    stepsOk = true,
    turnOk = true,
    driftOk = true,
    lowOk = true;
  for (const q of g) {
    if (Math.abs(Math.hypot(q.x - px, q.z - pz) - CANYON.step) > 0.5) stepsOk = false;
    if (Math.abs(wrapPi(q.yaw - ph)) > CANYON.turn + 1e-9) turnOk = false;
    if (Math.abs(wrapPi(q.yaw - yaw)) > CANYON.drift + 1e-9) driftOk = false;
    if (q.y < ground(q.x, q.z) + CANYON.lift - 1e-9) lowOk = false;
    px = q.x;
    pz = q.z;
    ph = q.yaw;
  }
  ok(stepsOk, `${tag} المسافة بين الحلقات = ${CANYON.step} م`);
  ok(turnOk && driftOk, `${tag} الانعطاف ≤ ${CANYON.turn} والانحراف الكلي ≤ ${CANYON.drift}`);
  ok(lowOk, `${tag} كل حلقة ≥ ${CANYON.lift} م فوق الأرض (لا تغوص بجرف)`);
  // يتبع الوادي: متوسط ارتفاع الأرض عند الحلقات أقل من خط مستقيم بنفس الطول
  const [dx, dz] = fwd(yaw);
  let sg = 0,
    ss = 0;
  g.forEach((q, i) => {
    sg += ground(q.x, q.z);
    ss += ground(x0 + dx * CANYON.step * (i + 1), z0 + dz * CANYON.step * (i + 1));
  });
  ok(sg <= ss, `${tag} المسار أخفض من الخط المستقيم (${Math.round(sg / g.length)} ≤ ${Math.round(ss / g.length)} م)`);
  ok(gateY(ground, g[0].x, g[0].z, g[0].yaw) === g[0].y, `${tag} gateY ثابتة/قابلة لإعادة الحساب`);
}
// المسار لا يكون خطاً مستقيماً دائماً ولا متعرجاً، والخط بين الحلقات لا يصطدم بهضبة (خلوص ≥ 10 م فوق الأرض)
let turns = 0,
  worst = Infinity;
const STARTS = [
  [0, 0, 0],
  [3000, -2000, 1.2],
  [-4000, 5000, -2.4],
  [1000, 1000, 0.7],
  [-2000, -3000, 3],
  [5000, 5000, -1]
];
for (const [x0, z0, yaw] of STARTS) {
  const g = buildRoute(ground, x0, z0, yaw);
  let px = x0,
    pz = z0,
    py = ground(x0, z0) + 170;
  g.forEach((q, i) => {
    if (Math.abs(q.yaw - (i ? g[i - 1].yaw : yaw)) > 1e-6) turns++;
    for (let s = 1; s <= 40; s++) {
      const u = s / 40;
      worst = Math.min(worst, py + (q.y - py) * u - ground(px + (q.x - px) * u, pz + (q.z - pz) * u));
    }
    [px, pz, py] = [q.x, q.z, q.y];
  });
}
const avgTurns = turns / STARTS.length;
ok(avgTurns >= 1.5 && avgTurns <= 6, `المسار يلتف مع التضاريس (${avgTurns.toFixed(1)} انعطافاً لكل مسار، بين 1.5 و6)`);
ok(worst >= 10, `خلوص خط الطيران بين الحلقات فوق الأرض ≥ 10 م (الأسوأ ${Math.round(worst)} م)`);
const tiny = buildRoute(ground, 0, 0, 0, CANYON, 1200);
ok(tiny.length < CANYON.n && tiny.every(q => Math.max(Math.abs(q.x), Math.abs(q.z)) <= 1200), 'حد الخريطة يقصّ المسار');

console.log('مرور الحلقة:');
const G0 = {x: 100, y: 200, z: -300};
ok(passGate({x: 100, y: 200, z: 0}, {x: 100, y: 200, z: -310}, G0), 'عبور من المركز');
ok(!passGate({x: 100 + 90, y: 200, z: 0}, {x: 100 + 90, y: 200, z: -600}, G0), 'يبعد 90 م = لا يُحتسب');
ok(passGate({x: 100 + 40, y: 200, z: 0}, {x: 100 + 40, y: 200, z: -600}, G0), 'فريم طويل على بعد 40 م = يُحتسب');
ok(!passGate({x: 100, y: 200 + 80, z: 0}, {x: 100, y: 200 + 80, z: -310}, G0), 'فوق الحلقة بـ 80 م = لا يُحتسب');
ok(passGate({x: 100, y: 200, z: -300}, {x: 100, y: 200, z: -300}, G0), 'فريم صفري داخل الحلقة لا ينهار');

console.log('مدافع الجروف:');
const route = buildRoute(ground, 0, 0, 0);
let found = 0,
  high = 0,
  bad = 0;
for (const q of route)
  for (let k = 0; k < 4; k++) {
    const c = cliffSpot(ground, q, rnd);
    if (!c) continue;
    found++;
    if (c.h >= q.y - 15) high++;
    const [dx, dz] = fwd(q.yaw),
      lat = Math.abs((c.x - q.x) * -dz + (c.z - q.z) * dx),
      flat = Math.hypot(ground(c.x + 8, c.z) - c.h, ground(c.x, c.z + 8) - c.h) <= 5;
    if (c.h < q.y - CANYON.lift - 5 || lat < 100 || !flat) bad++;
  }
ok(found >= route.length * 4 * 0.9, `وُجدت أماكن لـ 90%+ من المحاولات (${found} من ${route.length * 4})`);
ok(bad === 0, 'كل مدفع على جنب (≥100 م)، أرضه شبه مستوية، وليس بحفرة أخفض من قاع الوادي');
console.log(`  ℹ ${high} من ${found} أعلى من مسار الطيران (يطلق من فوقك؛ الباقي بمستوى قاع الوادي)`);

console.log('الزمن والمكافأة:');
const par = parTime(5000, 150);
ok(Math.abs(par - 5000 / (150 * CANYON.par)) < 1e-9, `زمن الجائزة ${par.toFixed(1)} ث`);
ok(timeBonus(par + 10, par) === 0 && timeBonus(par - 10, par) === 60 && timeBonus(0, par) === 250, 'المكافأة 0..250');
ok(routeLen(0, 0, [{x: 3, z: 4}, {x: 3, z: 14}]) === 15, 'طول المسار');

console.log('الربط والبنية:');
const camp = rd('campaign.js'),
  i18n = rd('i18n.js');
ok(/id: 'c5'[^\n]*op: 'canyon'/.test(camp), 'c5 مربوطة بـ op: canyon');
ok(/t\(c\.op \? 'opn_' \+ c\.op : 'mode_' \+ c\.mode\)/.test(rd('sheets/campaign.js')), 'بطاقة الحملة تعرض اسم نوع المهمة (KI-20)');
for (const k of ['island', 'convoy', 'night', 'arctic', 'greenland', 'twofront']) ok(rd('ops/index.js').includes(k + ':'), `السجل يعرّف ${k}`);
for (const k of ['c1d','c2d','c3d','c4d','c5d','c6d','c7d','op_cny_go','op_gate','op_ambush','op_final','op_isle_go','op_isle','op_convoy','op_leak','op_district','op_aces','op_ace_down','op_green_air','op_green_deep','op_front','op_pressure','opn_island','opn_convoy','opn_night','opn_arctic','opn_canyon','opn_greenland','opn_twofront'])
  ok(new RegExp(`\\n  ${k}: \\[`).test(i18n), `نص i18n: ${k} (عربي/إنجليزي)`);
ok(/canyon: createCanyon/.test(rd('ops/index.js')), 'سجل المهام يعرّف canyon');
ok(/if \(G\.op\) return G\.op\.spawn\(w\)/.test(rd('spawn.js')), 'spawnWave يحوّل للمهمة الخاصة (مع رقم الموجة)');
ok(/if \(G\.op && !G\.op\.waves\) return;/.test(rd('waves.js')), 'checkClear يتجاهل المهام التي تنهي نفسها فقط');
const game = rd('game.js');
ok(/G\.op\.update\(dt\)/.test(game) && /makeOp\(CAMP\.c\.op\)/.test(game), 'game.js ينشئ المهمة ويحدّثها');
ok(/G\.op\.dispose\(\)/.test(rd('combat.js')), 'clearEntities ينظّف المهمة');
ok(/G\.op && G\.op\.progress \? G\.op\.progress\(\)/.test(rd('hud.js')), 'HUD يعرض تقدّم المهمة إن وُجد');
const dir = fileURLToPath(new URL('../../src/ops/', import.meta.url));
for (const f of readdirSync(dir)) {
  const L = readFileSync(dir + f, 'utf8').split('\n');
  ok(L.length <= 250 && L.every(l => l.length <= 120), `ops/${f}: ${L.length} سطراً، لا سطر > 120 (R4)`);
}
if (fail) {
  console.log(`\n✗ فشل ${fail}`);
  process.exit(1);
}
console.log('\n✓ نجح كل شيء');
