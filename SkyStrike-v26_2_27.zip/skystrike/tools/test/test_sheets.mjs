// شاشات المنيو الداخلية (src/sheets/*): كل شاشة تُنفَّذ فعلاً بالحالة الحقيقية،
// فأي معرّف ناقص بعد التقسيم يرمي ReferenceError.
import {register} from 'node:module';
const ART_STUB =
  'export const ART={planes:{},weapons:{},campaign:{},ships:{},modes:{},ui:{}};' +
  'export const planeArt=()=>"";export const modeArt=()=>"";';
const UTIL_STUB =
  'export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));export const esc=s=>String(s);export const $=()=>null;';
const stub = c => `{url:'data:text/javascript,'+encodeURIComponent('${c}'),shortCircuit:true}`;
const hook =
  `export async function resolve(s,c,n){if(/\\/art\\.js$/.test(s))return${stub(ART_STUB)};` +
  `if(/\\/util\\.js$/.test(s))return${stub(UTIL_STUB)};return n(s,c)}`;
register('data:text/javascript,' + encodeURIComponent(hook));
globalThis.localStorage = {getItem: () => null, setItem() {}, removeItem() {}};
const {S} = await import('../../src/save.js');
const {PLANES, misInit, weeklyInit} = await import('../../src/data.js');
misInit();
weeklyInit(); // نفس ما يفعله M.show() قبل بناء الشاشات
const {t} = await import('../../src/i18n.js');
const {campaignSheet} = await import('../../src/sheets/campaign.js');
const {hangarSheet, skinsSheet} = await import('../../src/sheets/hangar.js');
const {weaponsSheet, missionsSheet} = await import('../../src/sheets/weapons.js');
const {profileSheet, rankingSheet} = await import('../../src/sheets/profile.js');
const {settingsSheet} = await import('../../src/sheets/settings.js');
const {setupSheet} = await import('../../src/sheets/setup.js');
const {wd, ranks, nextLv, baseLv, plain, bar, pimg} = await import('../../src/sheets/common.js');
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
console.log('شاشات المنيو:');
const api = {maps: () => [{id: 'island', grad: 'linear-gradient(#000,#111)', img: ''}]};
const PREV = Object.fromEntries(Object.keys(PLANES).map(k => [k, '']));
const sheets = {
  campaign: () => campaignSheet(),
  hangar: () => hangarSheet(PREV),
  skins: () => skinsSheet(),
  weapons: () => weaponsSheet(),
  missions: () => missionsSheet(),
  profile: () => profileSheet(),
  ranking: () => rankingSheet(),
  settings: () => settingsSheet(),
  setup: () => setupSheet({api, busy: () => true})()
};
for (const [k, f] of Object.entries(sheets)) {
  let h = '',
    err = '';
  try {
    h = f();
  } catch (e) {
    err = e.message;
  }
  ok(!err && typeof h === 'string' && h.length > 50, `${k}: تُبنى بلا خطأ ${err}`);
  ok(!/undefined|NaN|\[object/.test(h), `${k}: لا undefined/NaN بالناتج`);
}
ok(Object.keys(PLANES).every(id => hangarSheet(PREV).includes(PLANES[id].n)), 'الهنجر: كل الطائرات (7)');
ok(setupSheet({api, busy: () => true})().includes(t('prepMaps')), 'setup: حالة التحضير busy()');
ok(!setupSheet({api, busy: () => false})().includes(t('prepMaps')), 'setup: بدون تحضير لا رسالة');
ok(nextLv(3) === 540 && baseLv(3) === 240 && baseLv(1) === 0, 'common: nextLv/baseLv');
ok(plain('🎯 المهمة (x)') === 'المهمة' && bar(50, 100).includes('width:50%'), 'common: plain/bar');
ok(ranks(3).length === 3 && wd.gun(1).length > 0 && pimg({f35: 'p'}, 'f35') === 'p', 'common: ranks/wd/pimg');
if (fail) {
  console.log(`\nفشل ${fail}`);
  process.exit(1);
}
console.log('\nكل الفحوص نجحت');
