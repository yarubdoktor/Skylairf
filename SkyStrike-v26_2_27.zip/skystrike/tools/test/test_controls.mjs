// بند #13b (الجزء 2): حساسية الصعود/النزول المنفصلة (flight.js) + معالجة الميلان (tilt.js) + كاميرا مراقبة الهدف (camtarget.js).
import {stepPro} from '../../src/flight.js';
import {tiltAxis, smooth, TILT_RANGE, TILT_DZ} from '../../src/tilt.js';
import {lookBlend, CT} from '../../src/camtarget.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const RAD = Math.PI / 180,
  deg = (a, b) => Math.acos(Math.min(1, a.x * b.x + a.y * b.y + a.z * b.z)) / RAD;
console.log('حساسية لكل محور:');
const mk = () => ({sx: 0, sy: 0, wr: 0, wp: 0, roll: 0, pitch: 0, yaw: 0, gl: 1, cur: 150, speed: 150, turn: 1, tv: 1});
const fly = o => {
  const P = mk();
  for (let i = 0; i < 60; i++) stepPro(P, {x: 0, y: -1}, o, 1 / 60, false);
  return P;
};
const base = fly({sens: 1, invY: 0}),
  hi = fly({sens: 1, sensY: 1.5, invY: 0}),
  lo = fly({sens: 1, sensY: 0.6, invY: 0});
ok(hi.pitch > base.pitch * 1.2, 'sensY=1.5: الأنف يصعد أسرع من الافتراضي');
ok(lo.pitch < base.pitch * 0.85, 'sensY=0.6: أبطأ');
ok(
  Math.abs(fly({sens: 1, sensY: 1, invY: 0}).pitch - base.pitch) < 1e-12,
  'sensY=1 يطابق السلوك القديم (غياب sensY = 1)'
);
const h1 = (() => {
  const P = mk();
  for (let i = 0; i < 60; i++) stepPro(P, {x: 1, y: 0}, {sens: 1, sensY: 1.6, invY: 0}, 1 / 60, false);
  return P.yaw;
})();
const h0 = (() => {
  const P = mk();
  for (let i = 0; i < 60; i++) stepPro(P, {x: 1, y: 0}, {sens: 1, invY: 0}, 1 / 60, false);
  return P.yaw;
})();
ok(Math.abs(h1 - h0) < 1e-9, 'sensY لا يؤثر على الدوران الأفقي');

console.log('الميلان:');
ok(tiltAxis(0, 1) === 0 && tiltAxis(TILT_DZ, 1) === 0 && tiltAxis(-TILT_DZ, 1) === 0, 'منطقة ميتة حول المعايرة');
ok(tiltAxis(40, 1) === 1 && tiltAxis(-40, 1) === -1, 'أقصى عصا عند تجاوز النطاق');
ok(tiltAxis(5, 0) > tiltAxis(5, 1) && tiltAxis(5, 1) > tiltAxis(5, 2), 'حساس > عادي > هادئ لنفس الميلان');
ok(tiltAxis(8, 1) === -tiltAxis(-8, 1), 'متماثل');
let mono = true,
  prev = -1;
for (let d = 0; d <= 40; d += 0.5) {
  const v = tiltAxis(d, 1);
  if (v < prev - 1e-12) mono = false;
  prev = v;
}
ok(mono, 'متصاعد بلا قفزات');
ok(tiltAxis(TILT_DZ + 0.01, 1) < 0.01, 'بلا قفزة عند حدّ المنطقة الميتة');
ok(tiltAxis(5, 9) === tiltAxis(5, 1), 'مستوى مجهول: يرجع للعادي');
ok(TILT_RANGE[1] === 22, 'المستوى العادي = النطاق القديم (22°)');
let v = 0;
for (let i = 0; i < 10; i++) v = smooth(v, 1, 1 / 60);
const v2 = (() => {
  let x = 0;
  for (let i = 0; i < 20; i++) x = smooth(x, 1, 1 / 120);
  return x;
})();
ok(v > 0 && v < 1 && Math.abs(v - v2) < 1e-9, 'التنعيم مستقل عن معدل الفريم');

console.log('كاميرا مراقبة الهدف:');
const fw = {x: 0, y: 0, z: -1},
  out = {},
  tgt = d => ({x: Math.sin(d * RAD), y: 0, z: -Math.cos(d * RAD)});
ok(deg(lookBlend(fw, tgt(30), 0, out), fw) < 1e-9, 'وزن 0: بلا تغيير');
let r = lookBlend(fw, tgt(30), 1, out);
ok(deg(r, fw) > 1 && deg(r, fw) <= CT.maxDeg + 1e-6, `الميل ≤ ${CT.maxDeg}°`);
ok(deg(r, tgt(30)) < 30, 'يميل نحو الهدف');
r = lookBlend(fw, tgt(5), 1, out);
ok(Math.abs(deg(r, fw) - 5 * CT.k) < 1e-6, 'هدف قريب من المحور: يميل k من الزاوية فقط');
ok(deg(lookBlend(fw, tgt(120), 1, out), fw) < 1e-9, 'هدف خلف/جانب الطائرة (>86°): لا يلوي الكاميرا');
ok(Math.abs(Math.hypot(out.x, out.y, out.z) - 1) < 1e-9 || deg(out, fw) < 1e-9, 'اتجاه موحّد');
r = lookBlend(fw, tgt(30), 0.5, {});
ok(deg(r, fw) < deg(lookBlend(fw, tgt(30), 1, {}), fw), 'الوزن الجزئي ينعّم الميل');
if (fail) {
  console.log('✗ فشل ' + fail);
  process.exit(1);
}
console.log('✓ نجح الكل');
