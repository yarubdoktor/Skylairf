// يتأكد أن سفن الأعداء (src/models/e_{carrier,destroyer,frigate,patrol,cargo}.glb) تطابق ships.js: العقد، المحاور (−Z مقدمة)،
// الأطوال، خط الماء، الميزانيات، والمواد. بدون three: يقرأ JSON الـ GLB مباشرة.
import {readFileSync} from 'node:fs';
import {SHIPS, SHIP_TYPES, AIM_NODES} from '../../src/ships.js';
const dir = new URL('../../src/models/', import.meta.url);
const BUDGET = {
  carrier: [24000, 40000, 1200],
  destroyer: [12000, 18000, 500],
  frigate: [8000, 12000, 350],
  patrol: [3000, 5000, 150],
  cargo: [6000, 10000, 400]
};
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
console.log('سفن الأعداء:');
for (const k of SHIP_TYPES) {
  const f = `e_${k}.glb`,
    b = readFileSync(new URL(f, dir)),
    j = JSON.parse(b.subarray(20, 20 + b.readUInt32LE(12)).toString()),
    names = j.nodes.map(n => n.name),
    S = SHIPS[k];
  const need = ['body', ...AIM_NODES[k]];
  ok(need.every(n => names.includes(n)), `${k}: عقد ${need.join('/')}`);
  ok(S.unarmed ? !names.includes('aim') : names.includes('aim'), `${k}: ${S.unarmed ? 'أعزل بلا aim' : 'فيها aim'}`);
  let lo = [1e9, 1e9, 1e9],
    hi = [-1e9, -1e9, -1e9],
    tris = 0;
  for (const n of j.nodes) {
    if (n.name === 'radar' || /^aim/.test(n.name)) continue;
    const t = n.translation || [0, 0, 0];
    for (const p of j.meshes[n.mesh].primitives) {
      const a = j.accessors[p.attributes.POSITION];
      for (let i = 0; i < 3; i++) {
        lo[i] = Math.min(lo[i], a.min[i] + t[i]);
        hi[i] = Math.max(hi[i], a.max[i] + t[i]);
      }
    }
  }
  for (const m of j.meshes) for (const p of m.primitives) tris += j.accessors[p.indices].count / 3;
  const len = hi[2] - lo[2],
    [tmin, tmax, kb] = BUDGET[k];
  ok(Math.abs(len - S.len) / S.len < 0.08, `${k}: الطول ${len.toFixed(0)}م ≈ ships.js (${S.len}م)`);
  ok(lo[1] <= -1.5 && lo[1] >= -3.5, `${k}: قاع البدن y=${lo[1].toFixed(1)} (خط الماء y=0)`);
  ok(Math.abs(lo[0] + hi[0]) < 40 && Math.abs(lo[2] + hi[2]) < 20, `${k}: مركز x/z قرب الصفر`);
  ok(tris >= tmin * 0.9 && tris <= tmax, `${k}: ${tris} مثلث ضمن الميزانية`);
  ok(b.length / 1024 <= kb, `${k}: ${(b.length / 1024).toFixed(0)}KB ≤ ${kb}KB`);
  ok(j.materials.length <= 6 && !j.extensionsUsed && !j.images && !j.animations, `${k}: مواد ${j.materials.length} · بلا خامات/ضغط/أنيميشن`);
  ok(
    j.nodes.every(n => j.meshes[n.mesh].primitives.every(p => p.attributes.NORMAL !== undefined)),
    `${k}: كل المجسمات فيها normals`
  );
  // اتجاه الفوهة: بدن البرج يمتد على −Z أكثر من +Z (قبل قلب mkShip)
  const aim = j.nodes.find(n => n.name === 'aim');
  if (aim) {
    const a = j.accessors[j.meshes[aim.mesh].primitives[0].attributes.POSITION];
    ok(a.min[2] < -2 && a.max[2] < 3, `${k}: فوهة aim على −Z (${a.min[2]}..${a.max[2]})`);
  }
  ok(S.r > 0 && S.hp > 0 && S.pts > 0 && (S.unarmed || (S.gun && S.gun.range > 0)), `${k}: أرقام ships.js سليمة`);
}
ok(SHIPS.carrier.len / SHIPS.destroyer.len > 1.9, 'الحاملة ≈ ضعف المدمرة');
// ربط الكود: emodels يسجّل الخمس، jets يصدّر mkShip، ai/spawn يعرفون kind 'ship'
const src = f => readFileSync(new URL('../../src/' + f, import.meta.url), 'utf8');
for (const k of SHIP_TYPES) ok(src('emodels.js').includes(`ship_${k}: new URL('./models/e_${k}.glb'`), `emodels.js يسجّل ship_${k}`);
ok(/mkShip/.test(src('jets.js')), 'jets.js يصدّر mkShip');
ok(/export function addShip/.test(src('spawn.js')), 'spawn.js فيه addShip');
ok(/ship\(e, dt, c\)/.test(src('ai.js')), 'ai.js فيه AI.ship');
ok(/ship:/.test(src('enemies.js')) && /ship:/.test(src('radar_model.js')), 'enemies.js + radar_model.js فيهم ship');
if (fail) {
  console.log('✗ فشل ' + fail);
  process.exit(1);
}
console.log('✓ كل فحوص السفن نجحت');
