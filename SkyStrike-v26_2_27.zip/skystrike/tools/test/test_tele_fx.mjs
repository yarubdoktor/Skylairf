// بند #9 (v26.2.25): التحذير البصري للأرضيات — نبضات تتسارع وتقوى أثناء التحذير فقط، ولا شيء خارجه.
import {telePulse} from '../../src/tele_fx.js';
import {groundThink, maxCrew} from '../../src/ai_ground.js';
import {GROUND_AI as A, TURRET, AGGR, TELE} from '../../src/enemies.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const seeded = s => () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296;
const DT = 1 / 60;

// 1) خارج التحذير: صفر دائماً
const idle = {tele: 0};
let any = 0;
for (let i = 0; i < 120; i++) any += telePulse(idle, DT);
ok(any === 0, 'بلا تحذير (tele=0): لا نبضات');

// 2) أثناء التحذير: نبضات متسارعة وشدتها تتصاعد (محاكاة مباشرة)
const e = {tele: 1, gt: 0.9, gw0: 0.9};
const pulses = [];
for (let t = 0; e.gt > 0; t += DT) {
  const p = telePulse(e, DT);
  if (p) pulses.push({t, p});
  e.gt -= DT;
}
ok(pulses.length >= 3, `عدد النبضات بتحذير 0.9ث = ${pulses.length} (≥3)`);
ok(pulses[0].p >= TELE.min - 1e-9 && pulses.every(x => x.p <= 1 + 1e-9), 'الشدة بين الحد الأدنى و1');
ok(pulses.every((x, i) => !i || x.p > pulses[i - 1].p), 'الشدة تتصاعد مع اقتراب الرمي');
const g = pulses.slice(1).map((x, i) => x.t - pulses[i].t);
ok(g[g.length - 1] < g[0], `الفاصل يضيق (${g[0].toFixed(2)}→${g[g.length - 1].toFixed(2)} ث)`);

// 3) تكامل مع groundThink: كل تحذير حقيقي ينتج نبضات، وبعد الرمي تتوقف
const r = seeded(7),
  u = {kind: 'turret'},
  pl = {x: 0, y: 400, z: 500};
let inWarn = 0,
  pulsesInWarn = 0,
  pulsesOutside = 0,
  shots = 0;
for (let i = 0, since = 99; i < 60 * 30; i++, since += DT) {
  const d = Math.hypot(pl.x, pl.y - 6, pl.z);
  const o = groundThink(
    u,
    {
      px: pl.x,
      py: pl.y,
      pz: pl.z,
      vx: 0,
      vy: 0,
      vz: 0,
      ex: 0,
      ey: 6,
      ez: 0,
      dist: d,
      alive: true,
      canFire: true,
      rmin: 0,
      rmax: TURRET.gun.range,
      gunSp: TURRET.gun.speed,
      spread: TURRET.gun.spread || 0,
      ag: Math.min(1, AGGR.base + AGGR.w * 3),
      w: 3,
      crew: 0,
      maxCrew: maxCrew(3),
      since
    },
    DT,
    r
  );
  if (o.start) since = 0;
  shots += o.shots;
  const p = telePulse(u, DT);
  if (u.tele) inWarn++;
  if (p && u.tele) pulsesInWarn++;
  else if (p) pulsesOutside++;
}
ok(shots > 0 && inWarn > 0, `المحاكاة رمت ${shots} طلقة بـ ${inWarn} فريم تحذير`);
ok(pulsesInWarn >= 3, `نبضات أثناء التحذير = ${pulsesInWarn}`);
ok(pulsesOutside === 0, 'لا نبضات خارج التحذير');
ok(A.warn.turret > 0 && TELE.gap1 < TELE.gap0 && TELE.range > 1000, 'أرقام TELE سليمة');
if (fail) {
  console.log(`✗ ${fail} فشل`);
  process.exit(1);
}
console.log('✓ test_tele_fx');
