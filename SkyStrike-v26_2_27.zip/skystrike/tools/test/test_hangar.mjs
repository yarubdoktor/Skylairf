import {readFileSync} from 'node:fs';
// بند #3: منطق نافذة معاينة الطائرة (hangar_math.js) — مدار بقصور ذاتي + قرصة + دوران تلقائي + جدول الأسلحة.
import {
  newOrbit,
  orbitDrag,
  orbitRelease,
  orbitPinch,
  orbitStep,
  orbitPos,
  introK,
  showDue,
  SHOW,
  SHOW_LEN,
  ORBIT,
  norm
} from '../../src/hangar_math.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
console.log('المدار:');
const o = newOrbit();
const y0 = o.yaw;
for (let i = 0; i < 6; i++) orbitDrag(o, 40, 0, 1 / 60);
ok(o.yaw < y0, 'السحب يمينا يدير النموذج (اتجاه ثابت)');
orbitRelease(o);
const yR = o.yaw;
orbitStep(o, 1 / 60);
ok(Math.abs(o.yaw - yR) > 1e-4, 'قصور ذاتي بعد الترك');
const vBefore = Math.abs(o.vy);
for (let i = 0; i < 60 * 3; i++) orbitStep(o, 1 / 60);
ok(vBefore > 0.5 && Math.abs(o.vy) < vBefore * 0.02, 'السرعة تتخمد (' + vBefore.toFixed(2) + ' → ' + Math.abs(o.vy).toFixed(4) + ')');
const o2 = newOrbit();
for (let i = 0; i < 100; i++) orbitDrag(o2, 0, 80, 1 / 60);
ok(o2.pitch <= ORBIT.pitchMax + 1e-9, 'حد أعلى للميل');
for (let i = 0; i < 100; i++) orbitDrag(o2, 0, -80, 1 / 60);
ok(o2.pitch >= ORBIT.pitchMin - 1e-9, 'حد أدنى للميل');
const o3 = newOrbit();
orbitPinch(o3, 0.1);
ok(o3.zoom === ORBIT.zoomMax, 'قرصة بعيدة: سقف التكبير');
orbitPinch(o3, 50);
ok(o3.zoom === ORBIT.zoomMin, 'قرصة قريبة: حد التقريب');
orbitPinch(o3, 0);
ok(o3.zoom === ORBIT.zoomMin, 'نسبة غير صالحة تُتجاهل');
const o4 = newOrbit();
const a0 = o4.yaw;
for (let i = 0; i < 60 * 1; i++) orbitStep(o4, 1 / 60);
ok(o4.yaw === a0, 'لا دوران تلقائي قبل مهلة الترك');
for (let i = 0; i < 60 * 6; i++) orbitStep(o4, 1 / 60);
ok(o4.yaw > a0 + 0.5, 'دوران تلقائي بعد الترك');
const o5 = newOrbit();
for (let i = 0; i < 60 * 2.3; i++) orbitStep(o5, 1 / 60);
const s1 = o5.yaw;
orbitStep(o5, 1 / 60);
ok(o5.yaw - s1 < ORBIT.idleSpeed / 60 * 0.5, 'الدوران التلقائي يدخل بنعومة لا بقفزة');
orbitDrag(o5, 10, 0, 1 / 60);
ok(o5.auto === 0 && o5.idle === 0, 'اللمس يلغي الدوران التلقائي فوراً');
const p = orbitPos({yaw: 0, pitch: 0, zoom: 1}, 20);
ok(Math.abs(p.z - 20) < 1e-9 && Math.abs(p.x) < 1e-9 && Math.abs(p.y) < 1e-9, 'موضع الكاميرا على المدار');
const pz = orbitPos({yaw: 1, pitch: 0.5, zoom: 2}, 10);
ok(Math.abs(Math.hypot(pz.x, pz.y, pz.z) - 20) < 1e-9, 'نصف القطر = المسافة × التكبير');
ok(introK(0) === 0 && introK(1) === 1 && introK(0.5) > 0.5, 'دخول سينمائي: تباطؤ ناعم');
console.log('جدول الأسلحة:');
const all = [];
for (let t = 0; t < SHOW_LEN; t += 1 / 60) all.push(...showDue(t, t + 1 / 60));
ok(all.length === SHOW.length, 'كل حدث يُطلق مرة بالدورة (' + all.length + '/' + SHOW.length + ')');
const wrap = [];
for (let t = SHOW_LEN * 3 - 0.5; t < SHOW_LEN * 3 + 0.5; t += 1 / 60) wrap.push(...showDue(t, t + 1 / 60));
ok(wrap.filter(e => e.k === 'gun').length === 1, 'لفّ الدورة لا يضيّع ولا يكرّر حدثاً');
ok(showDue(1, 1.5).length === 0, 'لا أحداث بفترة فارغة');
ok(norm(5, 0) === 0 && norm(500, 100) === 1 && norm(50, 100) === 0.5, 'تطبيع المواصفات');
const view = readFileSync(new URL('../../src/hangar_view.js', import.meta.url), 'utf8');
const bar = view.match(/<div class="hg-bar">.*?<\/div>/s);
ok(bar && bar[0].includes('data-h="x"'), 'KI-21: زر ✕ ثانٍ داخل الشريط السفلي (بجانب ‹ ›)');
ok((view.match(/data-h="x"/g) || []).length === 2, 'KI-21: زرا إغلاق بالضبط');
console.log(fail ? '\nفشل ' + fail : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
