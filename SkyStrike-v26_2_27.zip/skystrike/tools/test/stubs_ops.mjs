// بيئة وهمية لمهام src/ops/ (اختبار محاكاة بـ node): تضاريس مسطحة، أعداء مسجَّلون بقائمة، لافتات مسجَّلة.
import {Vector3} from './stub_three.mjs';
export const log = {banners: [], sfx: [], spawned: [], booms: 0, checks: 0};
export const scene = {add() {}, remove() {}};
export const world = {ground: () => 20, H: () => 20, hasWater: () => true, cfg: {water: {level: 0}, limit: 12000}};
export const V = (x, y, z) => new Vector3(x, y, z);
export const W = {run: true, G: {}, enemies: []};
export const P = {g: {position: new Vector3(0, 200, 0)}, yaw: 0, speed: 150, hp: 50, maxhp: 100};
export const rnd = (a, b) => a + Math.random() * (b - a);
export const t = (k, o) => k + (o ? JSON.stringify(o) : '');
export const sfx = k => log.sfx.push(k);
export const banner = m => log.banners.push(m);
export function addAir(kind, pos, w) {
  const e = {kind, g: {position: pos.clone()}, hp: 100, max: 100, air: true, w};
  W.enemies.push(e);
  log.spawned.push(kind);
  return e;
}
export function addGround(kind, x, z, h, w) {
  const e = {kind, g: {position: new Vector3(x, h, z), rotation: {y: 0}}, hp: 100, max: 100, ground: true, w};
  W.enemies.push(e);
  log.spawned.push(kind);
  return e;
}
export function addShip(type, x, z, w, yaw = 0) {
  const e = {kind: 'ship', ship: type, g: {position: new Vector3(x, 0, z), rotation: {y: yaw}}, hp: 100, max: 100, ground: true, w};
  W.enemies.push(e);
  log.spawned.push('ship:' + type);
  return e;
}
export const landPos = (cx, cz) => ({x: cx + 40, z: cz + 40, h: 20});
export const removeEnemy = e => {
  const i = W.enemies.indexOf(e);
  if (i >= 0) W.enemies.splice(i, 1);
};
export const boom = () => {
  log.booms++;
};
export const baseLost = () => {
  W.G.dead = true;
  W.G.baseLost = true;
};
export const checkClear = () => {
  log.checks++;
  if (!W.enemies.some(e => !e.optional) && !(W.G.wait > 0)) {
    W.G.cleared = (W.G.cleared || 0) + 1;
    W.G.wait = 2.2;
  }
};
export const bossFor = () => ({id: 'warhawk'});
export function reset(extra = {}) {
  W.enemies.length = 0;
  Object.assign(log, {banners: [], sfx: [], spawned: [], booms: 0, checks: 0});
  for (const k of Object.keys(W.G)) delete W.G[k];
  Object.assign(W.G, {t: 0, wave: 1, wait: 0, score: 0, coins: 0, xp: 0, dead: false, win: false, obj: null, ...extra});
  P.g.position.set(0, 200, 0);
  P.yaw = 0;
}
export const kill = e => removeEnemy(e);
