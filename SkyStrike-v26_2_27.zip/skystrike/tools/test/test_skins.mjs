// بند #2: اتساق السكنات — كل مفتاح بـ SKINS (data.js) له تعريف مظهر (skins/defs.js) واسم i18n وسعر،
// ومفاتيح الحفظ القديمة باقية (R9). يفحص نصاً/بيانات صرفة (بلا three ولا متصفح).
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {SKIN_DEFS, SKIN_TYPES, SKIN_IDS, needsAnim} from '../../src/skins/defs.js';
const rd = p => readFileSync(fileURLToPath(new URL('../../src/' + p, import.meta.url)), 'utf8');
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const data = rd('data.js'),
  i18n = rd('i18n.js');
const block = data.slice(data.indexOf('export const SKINS'), data.indexOf('export const skinOf'));
const keys = [...block.matchAll(/\n {2}(\w+): sk\((\w+), (\d+)/g)].map(m => ({id: m[1], g: +m[3]}));
console.log('السكنات:');
ok(keys.length >= 11, 'عدد السكنات ' + keys.length + ' (≥ 11)');
for (const old of ['gray', 'desert', 'forest', 'arctic', 'night', 'crimson', 'gold'])
  ok(keys.some(k => k.id === old), 'مفتاح الحفظ القديم باقٍ: ' + old);
ok(
  keys.every(k => SKIN_IDS.includes(k.id)) && SKIN_IDS.every(id => keys.some(k => k.id === id)),
  'مفاتيح SKINS = مفاتيح SKIN_DEFS بالضبط'
);
ok(keys.every(k => new RegExp('sk_' + k.id + ':').test(i18n)), 'اسم i18n (عربي/إنجليزي) لكل سكن');
ok(keys.filter(k => k.id !== 'gray').every(k => k.g > 0), 'كل سكن مدفوع له سعر جواهر');
ok(keys.find(k => k.id === 'gray').g === 0 && SKIN_DEFS.gray === null, 'الأصلي مجاني وبلا تعريف');
console.log('تعريفات المظهر:');
const ds = Object.entries(SKIN_DEFS).filter(([, d]) => d);
ok(ds.every(([, d]) => SKIN_TYPES.includes(d.t)), 'نوع كل نمط معروف');
ok(ds.every(([, d]) => d.c.length >= 1 && d.c.every(c => Number.isInteger(c) && c >= 0 && c <= 0xffffff)), 'ألوان صالحة');
ok(ds.filter(([, d]) => d.t === 'camo').every(([, d]) => d.c.length === 3), 'التمويه 3 ألوان');
ok(ds.filter(([, d]) => ['pearl', 'neon'].includes(d.t)).every(([, d]) => d.e && d.e.length >= 1), 'لؤلؤي/نيون لهما لون توهج');
ok(ds.filter(([, d]) => d.t === 'pearl').every(([, d]) => d.e.length === 2), 'اللؤلؤي لونا تدرج');
ok(ds.every(([, d]) => d.k > 0 && d.met >= 0 && d.met <= 1 && d.rough >= 0.03 && d.rough <= 1), 'k/معدنية/خشونة بالمدى');
ok(needsAnim('neon') && !needsAnim('gold') && !needsAnim('gray'), 'النيون وحده متحرك');
console.log('الربط:');
const fj = rd('craft/fighters.js'),
  ap = rd('skins/apply.js');
ok(/skinMaterial\(o\.material, key\)/.test(fj) && /bakeCoords\(PM\[kind\]\)/.test(fj), 'fighters يستعمل النظام الجديد');
ok(!/lerp\(tc/.test(fj), 'لا صبغ قديم (lerp) يخرّب الشكل');
ok(/KEEP = \/canopy\|glass/.test(ap), 'الزجاج والمحركات لا تُطلى');
ok(!/SKINS\[skinOf\(id\)\]\.c/.test(rd('game.js') + rd('previews.js') + rd('hangar_view.js')), 'المستدعون يمرّرون مفتاح السكن');
console.log(fail ? '\nفشل ' + fail : '\nكل الاختبارات نجحت');
process.exit(fail ? 1 : 0);
