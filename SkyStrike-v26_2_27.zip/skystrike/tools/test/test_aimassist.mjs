// بند #13b: مساعدة التصويب (aimassist.js دالة صرفة) + ترحيل الحفظ لإعداداتها الجديدة (R9).
import {assistDir, AIM} from '../../src/aimassist.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const RAD = Math.PI / 180,
  P0 = {x: 0, y: 100, z: 0},
  FW = {x: 0, y: 0, z: -1};
const en = (x, y, z, vel) => ({g: {position: {x, y, z}}, vel});
const angDeg = (a, b) => Math.acos(Math.min(1, a.x * b.x + a.y * b.y + a.z * b.z)) / RAD;
const run = (es, lv, fw = FW, sp = 750) => assistDir(P0, fw, sp, es, lv, {});
console.log('مساعدة التصويب:');
ok(angDeg(run([en(30, 100, -500)], 0), FW) < 1e-9, 'المستوى 0: بلا تغيير');
ok(angDeg(run([], 1), FW) < 1e-9, 'بلا أعداء: بلا تغيير');
// هدف داخل المخروط (4° يمين على 600م)
const t1 = en(600 * Math.tan(4 * RAD), 100, -600),
  r1 = run([t1], 1),
  toT = {x: Math.sin(4 * RAD), y: 0, z: -Math.cos(4 * RAD)};
ok(angDeg(r1, FW) > 0.3, 'هدف داخل المخروط: الطلقة تنحرف نحوه');
ok(angDeg(r1, toT) < angDeg(FW, toT), 'والانحراف يقرّبها من الهدف (لا يبعدها)');
ok(angDeg(r1, FW) <= AIM[1].maxDeg + 1e-6, `الانحراف ≤ الحد الأقصى (${AIM[1].maxDeg}°) للخفيف`);
const t2 = en(600 * Math.tan(10 * RAD), 100, -600);
ok(angDeg(run([t2], 1), FW) < 1e-9, 'خارج مخروط الخفيف (10° > 7°): بلا تغيير');
ok(angDeg(run([t2], 2), FW) > 0.3 && angDeg(run([t2], 2), FW) <= AIM[2].maxDeg + 1e-6, 'القوي يلتقطه وبحد أقصى 6°');
ok(angDeg(run([en(0, 100, -1500)], 1), FW) < 1e-9, 'خارج المدى: بلا تغيير');
ok(angDeg(run([en(0, 100, -10)], 1), FW) < 1e-9, 'قريب جداً (<30م): بلا تغيير');
ok(angDeg(run([en(0, 100, 600)], 2), FW) < 1e-9, 'هدف خلف الطائرة: بلا تغيير');
// يختار الأقرب للمحور
const near = en(600 * Math.tan(1 * RAD), 100, -600),
  far = en(600 * Math.tan(5 * RAD), 100, -600),
  r3 = run([far, near], 2);
ok(
  angDeg(r3, {x: Math.sin(1 * RAD), y: 0, z: -Math.cos(1 * RAD)}) <
    angDeg(r3, {x: Math.sin(5 * RAD), y: 0, z: -Math.cos(5 * RAD)}),
  'يختار الهدف الأقرب لمحور التصويب'
);
// التقدّم (lead): هدف يتحرك يميناً → التصويب يميل يميناً أكثر من هدف ثابت
const st = run([en(0, 100, -600)], 1),
  mv = run([en(0, 100, -600, {x: 150, y: 0, z: 0})], 1);
ok(mv.x > st.x + 1e-4, 'هدف يتحرك يميناً: التصويب يتقدّمه');
ok(Math.abs(Math.hypot(mv.x, mv.y, mv.z) - 1) < 1e-9, 'الاتجاه الناتج موحّد الطول');
const bad = [null, {x: 0, y: 0, z: 0}, {x: NaN, y: 0, z: -1}];
void bad;

// ترحيل الحفظ: حفظ قديم بلا aim/shk يأخذ الافتراضيات ويحتفظ بباقي بياناته
const store = {skystrike_v2: JSON.stringify({v: 2, coins: 777, sel: 'mig29', sens: 1.3})};
globalThis.localStorage = {
  getItem: k => store[k] ?? null,
  setItem: (k, v) => {
    store[k] = v;
  }
};
const {S} = await import('../../src/save.js');
ok(S.coins === 777 && S.sel === 'mig29' && S.sens === 1.3, 'حفظ قديم: البيانات القديمة محفوظة');
ok(S.aim === 1 && S.shk === 1, 'حفظ قديم: aim/shk يأخذان الافتراضي (خفيف/عادي)');
ok(
  S.rz === 0 && S.sensY === 1 && S.tiltR === 1 && S.ct === 0,
  'حفظ قديم: rz/sensY/tiltR/ct يأخذون الافتراضي (يطابق السلوك القديم)'
);
if (fail) {
  console.log('✗ فشل ' + fail);
  process.exit(1);
}
console.log('✓ نجح الكل');
