// شاشة معلومات الأعداء: لكل سفينة صورة بالمجلد + نصوص عربي/إنجليزي + أرقام صحيحة (بدون DOM).
import {existsSync} from 'node:fs';
import {SHIPS, SHIP_TYPES} from '../../src/ships.js';
import {t, setLang} from '../../src/i18n.js';
import {shipCard, enemiesSheet} from '../../src/menu_enemies.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
console.log('شاشة معلومات الأعداء:');
const ART = {ships: Object.fromEntries(SHIP_TYPES.map(k => [k, `/ships/${k}.webp`]))};
for (const lang of ['ar', 'en']) {
  setLang(lang);
  for (const k of SHIP_TYPES) {
    const keys = ['shn_' + k, 'shd_' + k];
    ok(keys.every(x => t(x) !== x), `${lang}/${k}: النصوص موجودة`);
  }
  ok(['shStats', 'shStatsU', 'enemiesT', 'enemiesBtn', 'enemiesHint'].every(x => t(x) !== x), `${lang}: مفاتيح الشاشة`);
}
setLang('ar');
for (const k of SHIP_TYPES) {
  ok(existsSync(new URL(`../../src/assets/ships/${k}.webp`, import.meta.url)), `${k}: ملف الصورة موجود`);
  const h = shipCard(k, t, ART.ships[k]);
  ok(h.includes(`/ships/${k}.webp`) && h.includes(String(SHIPS[k].hp)), `${k}: البطاقة فيها الصورة والدرع`);
  ok(!/\{\w+\}/.test(h), `${k}: لا قوالب غير مستبدلة`);
  ok(SHIPS[k].unarmed ? h.includes('أعزل') : h.includes(String(SHIPS[k].gun.range)), `${k}: المدى/أعزل`);
}
ok(shipCard('cargo', t, '').indexOf('class="cim"') < 0, 'بدون صورة: لا عنصر صورة');
ok((enemiesSheet(t, ART).match(/class="card ms/g) || []).length === SHIP_TYPES.length, 'بطاقة لكل سفينة');
if (fail) {
  console.log(`\nفشل ${fail}`);
  process.exit(1);
}
console.log('\nكل الفحوص نجحت');
