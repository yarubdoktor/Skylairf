// بند #18: اختبار دخان للمجسمات البرمجية (jets.js وما تفرّع منه) بدون متصفح ولا three الحقيقية.
// نستبدل `three` بنسخة «بروكسي» تقبل أي استدعاء، ثم نبني كل مجسم: يلتقط أي ReferenceError/استيراد ناقص
// بعد تقسيم الملفات (تقسيم بلا تغيير سلوك). لا يتحقق من شكل المجسم (هذا بالمحرك).
import {register} from 'node:module';
import {readFileSync, readdirSync, statSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve, join} from 'node:path';
const root = resolve(fileURLToPath(new URL('../../src', import.meta.url)));
const files = [];
(function walk(d) {
  for (const f of readdirSync(d)) {
    const p = join(d, f);
    if (statSync(p).isDirectory()) {
      if (!/assets|models$/.test(p)) walk(p);
    } else if (p.endsWith('.js')) files.push(p);
  }
})(root);
const names = new Set(['GLTFLoader']);
for (const f of files) for (const m of readFileSync(f, 'utf8').matchAll(/THREE\.(\w+)/g)) names.add(m[1]);
globalThis.__THREE_NAMES = [...names];
register(
  'data:text/javascript,' +
    encodeURIComponent(`
const STUB = 'stub:three';
export async function resolve(s, c, n) { if (s === 'three' || s.startsWith('three/')) return {url: STUB + (s === 'three' ? '' : '-gl'), shortCircuit: true}; return n(s, c); }
export async function load(u, c, n) {
  if (!u.startsWith(STUB)) return n(u, c);
  const gl = u.endsWith('-gl'), list = ${JSON.stringify([...names])};
  const body = \`const mk = () => { const store = {}; const f = function () {}; const p = new Proxy(f, {
    get(t, k) { if (k === Symbol.iterator) return function* () {}; if (k === Symbol.toPrimitive) return () => 0; if (k === 'then') return undefined;
      if (!(k in store)) store[k] = mk(); return store[k]; },
    set(t, k, v) { store[k] = v; return true; }, apply() { return mk(); }, construct() { return mk(); } }); return p; };
  const C = function () { return mk(); };\`;
  return {format: 'module', shortCircuit: true, source: body + list.map(n => \`export const \${n} = C;\`).join('\\n')};
}`)
);
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
console.log('المجسمات البرمجية:');
const J = await import('../../src/jets.js');
const tryMk = (label, fn) => {
  try {
    const r = fn();
    ok(r !== undefined && r !== null, label);
  } catch (e) {
    ok(false, label + ' — ' + e.message);
  }
};
for (const k of [0, 1, 2]) tryMk('mkJet(' + k + ') لاعب', () => J.mkJet(k, 0x888888, true, null));
for (const k of [0, 1, 2]) tryMk('mkJet(' + k + ') عدو', () => J.mkJet(k, 0xaa3333, false, null));
tryMk('mkBomber', () => J.mkBomber());
tryMk('mkHeli', () => J.mkHeli());
for (const id of ['warhawk', 'fortress', 'phantom', 'x']) tryMk('mkBoss(' + id + ')', () => J.mkBoss(id));
tryMk('mkDrone', () => J.mkDrone());
for (const t of [0, 1, 2, 3, 4]) tryMk('mkGround(' + t + ')', () => J.mkGround(t));
tryMk('mkDepot', () => J.mkDepot());
tryMk('mkMsl(عدو)', () => J.mkMsl(true));
tryMk('mkMsl(لاعب)', () => J.mkMsl(false));
tryMk('mkBomb', () => J.mkBomb());
ok(J.BULLET_GEO && J.BULLET_P && J.BULLET_E, 'BULLET_GEO/P/E معرّفة');
ok(J.WT && J.WT[0] && J.WT[1] && J.WT[2], 'WT للطائرات الثلاث');
ok(typeof J.loadModels === 'function', 'loadModels دالة');
const exp = Object.keys(J).sort().join(',');
console.log('  الصادرات: ' + exp);
if (fail) {
  console.log('✗ فشل ' + fail);
  process.exit(1);
}
console.log('✓ نجح الكل');
