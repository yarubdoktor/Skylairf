// بند #5: محاكاة سلوك مهام src/ops/ كلها بـ node (بيئة وهمية: stubs_ops.mjs) + مواقع الجزر والقافلة على التضاريس الحقيقية.
// يُشغَّل مع register.mjs. المحاكاة تتحقق من المنطق (الفوز/التقدم/التسرّب/الضغط...) لا من الشكل المرئي.
Object.assign(globalThis, {
  innerWidth: 800,
  innerHeight: 600,
  matchMedia: () => ({matches: false}),
  addEventListener() {},
  document: {documentElement: {classList: {toggle() {}}, style: {setProperty() {}}}, getElementById: () => null}
});
const {makeOp} = await import('../../src/ops/index.js');
const {W, P, log, reset, kill, checkClear, world} = await import('./stubs_ops.mjs');
const {buildMap} = await import('../../src/maps.js');
const {pickSites, findLand} = await import('../../src/ops/sites.js');
const {buildConvoyRoute, routePoint, routeSlope} = await import('../../src/ops/convoy_path.js');
const {CONVOY, ISLAND, arcticWave, greenWave, nightWave, districts, NIGHT, callsign, convoyStage, frontStage, TWOFRONT} =
  await import('../../src/ops/plans.js');
const {CAMPAIGN} = await import('../../src/campaign.js');
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const count = k => log.spawned.filter(x => x === k).length;
const run = (op, sec, dt = 0.1) => {
  for (let t = 0; t < sec; t += dt) {
    W.G.t += dt;
    op.update(dt);
  }
};
let seed = 7;
const rnd = (a, b) => a + ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296) * (b - a);

console.log('كل مهام الحملة مربوطة:');
for (const c of CAMPAIGN) ok(!!c.op && !!makeOp(c.op), `${c.id} (${c.map}) ← ${c.op}`);

console.log('canyon:');
reset();
let op = makeOp('canyon');
op.spawn(1);
ok(op.gates.length === 10 && count('depot') === 0, '10 حلقات والمستودع لم يظهر بعد');
for (const g of op.gates) {
  P.g.position.set(g.x, g.y, g.z + 30);
  run(op, 0.1);
  P.g.position.set(g.x, g.y, g.z - 30);
  run(op, 0.1);
}
ok(op.i === 10 && count('depot') === 1, 'مرور الحلقات العشر يُظهر المستودع');
ok(count('jet') === 6 && count('ace') === 1, 'ثلاثة كمائن (2+3+2 مقاتلة، منها نخبة)');
kill(op.depot);
run(op, 0.1);
ok(W.G.win && W.G.wait === 2.8 && W.G.coins >= 300, 'تدمير المستودع = فوز');

console.log('island:');
reset();
op = makeOp('island');
op.spawn(1);
ok(count('depot') === 3 && count('turret') >= 6, '3 مستودعات + دفاعات');
run(op, 5);
ok(op.progress() === 'ISLES 0/3' && !W.G.win, 'التقدّم 0/3 ولا فوز مبكراً');
kill(op.depots[1]);
run(op, 0.1);
ok(op.progress() === 'ISLES 1/3', 'بأي ترتيب: الثاني أولاً يحتسب');
run(op, 41);
ok(count('jet') === 2, 'دورية مقاتلات بعد 40 ث');
kill(op.depots[0]);
kill(op.depots[2]);
run(op, 0.1);
ok(W.G.win, 'تدمير الثلاثة = فوز');

console.log('convoy:');
reset();
op = makeOp('convoy');
op.spawn(1);
const c0 = op.cars[0].g.position.clone();
ok(op.cars.length === convoyStage(1).vehicles && op.progress() === 'CONVOY 6/6', 'قافلة 6 آليات');
run(op, 10);
ok(Math.hypot(op.cars[0].g.position.x - c0.x, op.cars[0].g.position.z - c0.z) > CONVOY.speed * 8, 'الآليات تتحرك');
op.cars.forEach(e => kill(e));
run(op, 0.1);
ok(W.G.cleared === 1, 'تدمير القافلة يُنهي المرحلة');
reset();
op = makeOp('convoy');
op.spawn(2);
ok(count('heli') === 1, 'المرحلة 2: هليكوبتر مرافقة');
run(op, 260, 0.5);
ok(W.G.dead && W.G.baseLost, 'وصول القافلة للنهاية (تسرّب ≥2) = سقوط القاعدة');
reset();
op = makeOp('convoy');
op.spawn(1);
for (let i = 1; i < op.cars.length; i++) kill(op.cars[i]);
run(op, 260, 0.5);
ok(!W.G.dead && W.G.cleared === 1, 'تسرّب واحد فقط (< الحد 2) والباقي دُمّر = المرحلة تنتهي');

console.log('night:');
reset({obj: {x: 0, z: 0}});
op = makeOp('night');
op.spawn(1);
ok(count('bomber') === 2 && W.G.obj && op.d.length === NIGHT.districts, 'موجة 1: قاذفتان + 4 أحياء');
const d1 = {...W.G.obj};
W.enemies.length = 0;
op.spawn(2);
ok(W.G.obj.x !== d1.x || W.G.obj.z !== d1.z, 'الموجة 2 تهاجم حياً مختلفاً');
W.enemies.length = 0;
log.spawned.length = 0;
op.spawn(3);
const b3 = W.enemies.filter(e => e.kind === 'bomber'),
  side = b3.map(e => Math.sign((e.g.position.x - W.G.obj.x) * (b3[0].g.position.x - W.G.obj.x) + (e.g.position.z - W.G.obj.z) * (b3[0].g.position.z - W.G.obj.z)));
ok(b3.length === 4 && side.includes(1) && side.includes(-1), 'الموجة 3: 4 قاذفات من جهتين متعاكستين');
W.enemies.length = 0;
const near = {kind: 'bomber', g: {position: {x: W.G.obj.x + 100, y: 250, z: W.G.obj.z}}, hp: 100},
  far = {kind: 'bomber', g: {position: {x: W.G.obj.x + 3000, y: 250, z: W.G.obj.z}}, hp: 100};
W.enemies.push(near, far);
run(op, 16);
ok(!W.enemies.includes(near) && W.enemies.includes(far) && far.hp === 100, 'مدفعية المدينة تُسقط القريبة فقط');
ok(log.booms === 1 && log.checks >= 1, 'انفجار + فحص إنهاء الموجة');

console.log('arctic:');
reset();
op = makeOp('arctic');
op.spawn(1);
ok(count('ace') === 1 && count('jet') === 1 && op.aces[0].cs === 'FROST-1', 'موجة 1: نخبة FROST-1 + مقاتلة');
const hp0 = (P.hp = 50);
kill(op.aces[0]);
run(op, 0.1);
ok(W.G.coins === 50 && P.hp > hp0 && log.banners.at(-1).includes('op_ace_down'), 'إسقاط النخبة: +50 عملة، ترميم، إعلان');
reset();
op = makeOp('arctic');
op.spawn(5);
ok(count('boss') === 1 && count('ace') === 2 && count('jet') === 0, 'موجة 5: الزعيم + نخبتان');

console.log('greenland:');
reset();
op = makeOp('greenland');
op.spawn(1);
ok(count('jet') === 2 && count('drone') === 1 && count('sam') === 0, 'موجة 1: جوية فقط');
reset();
op.spawn(6);
ok(count('sam') === 2 && count('flak') === 2 && count('turret') === 3 && count('ace') === 1, 'موجة 6: ضرب العمق + نخبة');
run(op, 1.1);
ok(W.G.obj && W.enemies.some(e => e.ground), 'الرادار يدل على أقرب دفاع أرضي');
reset();
op.spawn(5);
ok(count('boss') === 1 && count('jet') === 0, 'موجة 5: الزعيم الأول');
reset();
op.spawn(10);
ok(count('boss') === 1, 'موجة 10: الزعيم الثاني');

console.log('twofront:');
reset({wave: 1});
op = makeOp('twofront');
op.spawn(1);
ok(count('depot') === 2, 'مستودع بكل قاعدة');
run(op, TWOFRONT.pressureEvery + 1);
ok(count('jet') === frontStage(1).jets + 2 && log.banners.at(-1).includes('op_pressure'), 'ضغط التعزيزات بعد 50 ث');
kill(op.depots[0]);
log.spawned.length = 0;
run(op, TWOFRONT.pressureEvery + 1);
ok(count('jet') === 2, 'التعزيز يستمر على القاعدة الحية');

console.log('أساطيل map7:');
const nShips = k => W.enemies.filter(e => e.ship && (!k || e.ship === k)).length;
const H0 = world.H;
world.H = () => -20; // ماء (التضاريس الوهمية يابسة افتراضياً)
reset({wave: 1});
op = makeOp('twofront');
op.spawn(1);
ok(nShips('frigate') === 2 && nShips('carrier') === 0 && nShips('destroyer') === 0, 'مرحلة 1: فرقاطتان فقط بلا حاملة/مدمرة');
ok(nShips('cargo') === 4 && nShips('patrol') === 0, 'مرحلة 1: 4 سفن شحن/ناقلات أعزل، بلا زوارق');
ok(W.enemies.filter(e => e.ship).every(e => e.optional), 'السفن اختيارية');
for (const e of [...W.enemies]) if (!e.ship) kill(e);
checkClear();
ok(nShips() > 0 && W.G.cleared === 1, 'السفن الحيّة لا تمنع إنهاء المرحلة (checkClear)');
op.spawn(3);
ok(nShips() === 13 && nShips('carrier') === 2 && nShips('patrol') === 2, 'مرحلة 3: تُستبدل سفن المرحلة السابقة (لا تتراكم): 13 سفينة بحاملتين وزورقين');
op.spawn(5);
ok(nShips('destroyer') === 4 && nShips('patrol') === 3 && W.enemies.filter(e => e.ship).length === nShips(), 'مرحلة 5: 4 مدمرات و3 زوارق');
world.H = H0;
console.log('الجداول:');
ok([1, 2, 3, 4].every(w => arcticWave(w).aces === 1 + (w >> 1)) && arcticWave(5).boss, 'arctic: 1،2،2،3 نخبة ثم الزعيم');
ok(greenWave(5).boss && greenWave(10).boss && !greenWave(7).boss, 'greenland: زعيم 5 و10 فقط');
ok(greenWave(5).phase === 'air' && greenWave(6).phase === 'deep', 'greenland: المرحلة 2 تبدأ بالموجة 6');
const gw = [1, 2, 3, 4, 6, 7, 8, 9].map(w => greenWave(w));
ok(gw.every((p, i) => i === 0 || p.jets >= gw[i - 1].jets || p.phase !== gw[i - 1].phase), 'greenland: العدد لا ينخفض داخل المرحلة');
ok(districts(0, 0).every(d => Math.abs(Math.hypot(d.x, d.z) - NIGHT.radius) < 1e-6), 'night: الأحياء على نصف القطر');
ok([1, 2, 3, 4].map(w => nightWave(w).district).join() === '0,1,2,3', 'night: حي مختلف كل موجة');
ok(new Set(Array.from({length: 24}, (_, i) => callsign(i))).size === 24, 'arctic: أسماء النداء فريدة');
ok(convoyStage(3).vehicles === 10 && convoyStage(3).heli === 2, 'convoy: المرحلة 3 = 10 آليات و2 هليكوبتر');

console.log('الجزر والقافلة على التضاريس الحقيقية:');
for (const id of ['island']) {
  const {cfg, H} = buildMap(id),
    sp = cfg.spawn || {x: 0, z: 0};
  for (const [x0, z0] of [[sp.x, sp.z], [1500, -900], [-2500, 2000]]) {
    const s = pickSites(H, cfg.water.level, x0, z0, ISLAND.sites, rnd, ISLAND),
      sep = s.every((a, i) => s.every((b, j) => i === j || Math.hypot(a.x - b.x, a.z - b.z) >= ISLAND.sep));
    ok(s.length === 3 && sep && s.every(q => q.h >= 6), `${id} من (${x0},${z0}): 3 جزر يابسة متباعدة ≥ ${ISLAND.sep} م`);
  }
}
{
  const {cfg, H} = buildMap('desert'),
    lvl = cfg.water ? cfg.water.level : -1e9;
  let good = 0;
  for (const [x0, z0] of [[0, 0], [2000, 1500], [-3000, 500], [800, -2500]]) {
    const r = buildConvoyRoute(H, lvl, x0, z0, rnd, CONVOY);
    if (r && routeSlope(H, r.a, r.b) <= CONVOY.maxSlope) good++;
  }
  ok(good >= 3, `desert: ${good}/4 طرق قافلة بميل ≤ ${CONVOY.maxSlope}`);
  const p0 = routePoint({x: 0, z: 0}, {x: 0, z: -100}, 50);
  ok(Math.abs(p0.z + 50) < 1e-9 && Math.abs(p0.yaw) < 1e-9 && !p0.done, 'routePoint: الاتجاه -z = yaw 0');
  ok(routePoint({x: 0, z: 0}, {x: 0, z: -100}, 500).done, 'routePoint: يُقصّ عند النهاية');
  ok(findLand(H, lvl, 0, 0, 500, 900, rnd) !== null, 'desert: findLand يجد أرضاً');
}
if (fail) {
  console.log(`\n✗ فشل ${fail}`);
  process.exit(1);
}
console.log('\n✓ نجح كل شيء');
