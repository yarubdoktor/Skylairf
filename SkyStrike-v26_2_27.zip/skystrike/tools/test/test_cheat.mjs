// وضع الاختبار (src/cheat.js): الدالة صحيحة وغير مدمّرة، والخطّاف موجود بـ game.js. الفحص أن CHEAT=false بالنسخة الرسمية
// يتم بـ`npm run check:release` (لا يدخل npm test حتى لا تفشل نسخة الاختبار).
import {readFileSync} from 'node:fs';
import {CHEAT, CHEAT_AMOUNT, applyCheat} from '../../src/cheat.js';
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const a = applyCheat({coins: 300, gems: 0, cp: 0, tut: 0}, 7);
ok(a.coins === CHEAT_AMOUNT && a.gems === CHEAT_AMOUNT, 'مليون عملة ومليون جوهرة');
ok(a.cp === 7 && a.tut === 1, 'كل مهام الحملة مفتوحة والجولة التعليمية متخطاة');
const b = applyCheat({coins: 5e6, gems: 2e6, cp: 7, tut: 1}, 7);
ok(b.coins === 5e6 && b.gems === 2e6, 'لا يخفّض رصيداً أعلى من المليون');
const g = readFileSync(new URL('../../src/game.js', import.meta.url), 'utf8');
ok(/if \(CHEAT\) \{\s*applyCheat\(S, CAMPAIGN\.length\)/.test(g), 'game.js يطبّقه عند التشغيل فقط إن كان CHEAT');
console.log(`  ℹ CHEAT = ${CHEAT}`);
if (fail) process.exit(1);
console.log('✓ نجح كل شيء');
