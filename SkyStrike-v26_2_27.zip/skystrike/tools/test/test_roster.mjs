// بند #6: اتساق تشكيلة الطائرات — كل طائرة بـ PLANES لها (kind فريد) نموذج GLB موجود + لهب/طرف جناح
// بـ craft/roster.js + صوت محرك بـ audio.js + نصوص i18n (d_/ab_). يفحص نصاً (بلا three ولا متصفح).
import {readFileSync, existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const rd = p => readFileSync(fileURLToPath(new URL('../../src/' + p, import.meta.url)), 'utf8');
let fail = 0;
const ok = (c, m) => {
  console.log((c ? '  ✓ ' : '  ✗ ') + m);
  if (!c) fail++;
};
const data = rd('data.js'),
  roster = rd('craft/roster.js'),
  audio = rd('audio.js'),
  i18n = rd('i18n.js');
const block = data.slice(data.indexOf('export const PLANES'), data.indexOf('export const level'));
const planes = [...block.matchAll(/\n {2}(\w+): \{([\s\S]*?)\n {2}\}/g)].map(m => ({
  id: m[1],
  kind: +/kind: (\d+)/.exec(m[2])?.[1],
  price: +/price: (\d+)/.exec(m[2])?.[1],
  speed: +/speed: (\d+)/.exec(m[2])?.[1]
}));
console.log('تشكيلة الطائرات:');
ok(planes.length >= 3, `عدد الطائرات ${planes.length} (≥ 3)`);
ok(new Set(planes.map(p => p.kind)).size === planes.length, 'كل kind فريد');
ok(planes.every(p => Number.isInteger(p.kind) && p.kind >= 0), 'كل kind رقم صحيح');
ok(planes.find(p => p.id === 'f35')?.price === 0, 'الطائرة الافتراضية f35 مجانية');
const prices = planes.map(p => p.price);
ok(prices.every((p, i) => i === 0 || p > prices[i - 1]), 'الأسعار تصاعدية بترتيب التعريف');
const keys = (name, src) => {
  const s = src.slice(src.indexOf(name));
  return new Set([...s.slice(0, s.indexOf('};')).matchAll(/^ {2}(\d+): /gm)].map(m => +m[1]));
};
const pfl = keys('export const PFL', roster),
  eng = keys('const EP', audio),
  mu = keys('export const MODEL_URL', roster);
for (const p of planes) {
  ok(pfl.has(p.kind), `${p.id}: لهب/طرف جناح (PFL ${p.kind})`);
  ok(mu.has(p.kind), `${p.id}: رابط نموذج (MODEL_URL ${p.kind})`);
  ok(eng.has(p.kind), `${p.id}: صوت محرك (EP ${p.kind})`);
  const hasTxt = k => new RegExp(`\\n  ${k}_${p.id}:`).test(i18n);
  ok(hasTxt('d') && hasTxt('ab'), `${p.id}: نصوص d_/ab_`);
}
const urls = [...roster.matchAll(/new URL\('(\.\.\/models\/[\w.]+)', import\.meta\.url\)/g)].map(m => m[1]);
ok(urls.length === mu.size, 'كل روابط GLB نصوص ثابتة (يلتقطها Vite)');
for (const u of urls) {
  const f = fileURLToPath(new URL('../../src/' + u.replace('../', ''), import.meta.url));
  ok(existsSync(f), `الملف موجود: ${u}`);
}
if (fail) {
  console.log('\n✗ فشل ' + fail);
  process.exit(1);
}
console.log('\n✓ test_roster ناجح');
