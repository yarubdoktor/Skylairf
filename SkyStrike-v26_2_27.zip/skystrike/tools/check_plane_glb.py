#!/usr/bin/env python3
"""فحص نموذج طائرة GLB مقابل docs/planes/GLB_SPEC.md (بند #6). الاستعمال: python3 tools/check_plane_glb.py a.glb [...]"""
import json, struct, sys, os
import numpy as np

CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}

def load(p):
    d = open(p, 'rb').read()
    jl = struct.unpack('<I', d[12:16])[0]
    j = json.loads(d[20:20 + jl])
    off = 20 + jl
    bl = struct.unpack('<I', d[off:off + 4])[0]
    return j, d[off + 8:off + 8 + bl]

def acc(j, b, i):
    a = j['accessors'][i]; v = j['bufferViews'][a['bufferView']]
    dt = np.dtype(CT[a['componentType']]); n = NC[a['type']]
    st = v.get('byteStride') or dt.itemsize * n
    o = v.get('byteOffset', 0) + a.get('byteOffset', 0)
    arr = np.ndarray((a['count'], n), dt, b, o, (st, dt.itemsize))
    return np.array(arr)

def mat_of(node):
    m = np.eye(4)
    if 'matrix' in node: return np.array(node['matrix']).reshape(4, 4).T
    t = node.get('translation', [0, 0, 0]); r = node.get('rotation', [0, 0, 0, 1]); s = node.get('scale', [1, 1, 1])
    x, y, z, w = r
    R = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                  [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
    m[:3, :3] = R * np.array(s); m[:3, 3] = t
    return m

def collect(j, b):
    pts, tris = [], 0
    sc = j['scenes'][j.get('scene', 0)]
    def walk(i, pm):
        nonlocal tris
        n = j['nodes'][i]; m = pm @ mat_of(n)
        if 'mesh' in n:
            for pr in j['meshes'][n['mesh']]['primitives']:
                p = acc(j, b, pr['attributes']['POSITION']).astype(float)
                pts.append((np.c_[p, np.ones(len(p))] @ m.T)[:, :3])
                tris += (j['accessors'][pr['indices']]['count'] if 'indices' in pr else len(p)) // 3
        for c in n.get('children', []): walk(c, m)
    for r in sc['nodes']: walk(r, np.eye(4))
    return np.vstack(pts), tris

def check(p):
    j, b = load(p); P, tris = collect(j, b)
    mn, mx = P.min(0), P.max(0); dim = mx - mn
    res = []
    def ok(c, msg): res.append((c, msg))
    ok(2 <= len(j.get('materials', [])) or True, '')
    res.pop()
    ln = dim[2]
    ok(12.5 <= ln <= 15.5 and dim[2] == dim.max(), f'الطول على Z = {ln:.1f} (13–15 وأطول محور)' + ('' if dim[2] == dim.max() else f' ← المحور الأطول غير Z (أبعاد XYZ = {dim.round(1)}): غالباً التصدير بـ Y-up خاطئ'))
    ok(10.5 <= dim[0] <= 13.8, f'الباع على X = {dim[0]:.1f} (11–13)')
    ok(dim[1] <= 3.8, f'الارتفاع على Y = {dim[1]:.1f} (≤ 3.6)')
    ok(abs((mx + mn)[2] / 2) < 1.2 and abs((mx + mn)[0] / 2) < 0.3, f'المركز قرب الأصل ({(mx+mn)[0]/2:.2f}, {(mx+mn)[1]/2:.2f}, {(mx+mn)[2]/2:.2f})')
    # الأنف: الطرف الأضيق (بعرض X) بأول/آخر 8% من الطول يجب أن يكون عند -Z
    lo = P[P[:, 2] < mn[2] + 0.08 * ln]; hi = P[P[:, 2] > mx[2] - 0.08 * ln]
    wlo = np.ptp(lo[:, 0]); whi = np.ptp(hi[:, 0])
    ok(wlo <= whi, f'الأنف نحو -Z (عرض طرف -Z = {wlo:.1f} ≤ طرف +Z = {whi:.1f})')
    ok(4500 <= tris <= 12500, f'المثلثات = {tris} (5–7 آلاف، حتى 12 ألف)')
    sz = os.path.getsize(p) / 1024
    ok(sz <= 800, f'الحجم = {sz:.0f}KB (≤ 800)')
    ms = j.get('materials', [])
    ok(1 <= len(ms) <= 8, f'المواد = {len(ms)} (≤ 8)')
    ok(len(j.get('meshes', [])) <= 12, f'الشبكات = {len(j.get("meshes", []))} (≤ 12)')
    cn = [m for m in ms if any(k in (m.get('name') or '').lower() for k in ('canopy', 'glass'))]
    ok(bool(cn), 'مادة مظلة باسم canopy/glass: ' + (cn[0]['name'] if cn else 'غير موجودة'))
    ok(bool(cn) and cn[0].get('alphaMode') == 'BLEND', 'المظلة alphaMode=BLEND: ' + (cn[0].get('alphaMode', 'OPAQUE') if cn else '-'))
    ok(not j.get('animations') and not j.get('cameras'), 'بلا أنيميشن/كاميرات')
    ok(not any(k in j.get('extensionsUsed', []) for k in ('KHR_draco_mesh_compression', 'EXT_meshopt_compression')), 'بلا Draco/meshopt')
    print(f'\n== {os.path.basename(p)} ==')
    for c, m in res: print(('  ✓ ' if c else '  ✗ ') + m)
    return all(c for c, _ in res)

if __name__ == '__main__':
    r = [check(p) for p in sys.argv[1:]]
    sys.exit(0 if all(r) else 1)
