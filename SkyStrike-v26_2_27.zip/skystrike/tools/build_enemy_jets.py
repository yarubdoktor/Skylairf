#!/usr/bin/env python3
"""بند #16 (v26.2.26): 3 مقاتلات عدو HD بخامات PBR مولّدة (تستبدل المجسم البرمجي mkJet للعدو).
تشغيل: python3 tools/build_enemy_jets.py [--preview]  → src/models/e_jet0|1|2.glb (+ /tmp/ejets_preview.png)
الاتجاه: الأنف −Z، y للأعلى، الذيل/المحركات عند +Z (نفس مقاييس mkJet: طول ≈ 15، فتحة جناح ≈ 11).
الفوهات تنتهي عند z=6.7 (حيث يضع craft/fighters.js اللهب). عقدة واحدة 'body' بمواد: paint/metal/glass/accent/navr/navg."""
import sys, os, math
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from hdlib import (loft, cbox, extrude, cyl, ellipsoid, place, cat, rot, rz, Model, uv_planar, vcolors,
                   tex_paint, tex_metal, write_glb_hd, render_model)

OUT = os.path.join(os.path.dirname(__file__), '..', 'src', 'models')

def mir(p):  # انعكاس x → -x (مع قلب ترتيب المثلثات)
    P, N = p; P2 = P * np.array([-1, 1, 1]); N2 = N * np.array([-1, 1, 1])
    idx = np.arange(len(P2)).reshape(-1, 3)[:, [0, 2, 1]].reshape(-1)
    return P2[idx], N2[idx]

def both(m, node, kind, p, t=(0, 0, 0), R=None):
    """يضيف النسخة اليمنى واليسرى (t.x موجب)"""
    r = place(p, R, t) if (R is not None or any(t)) else p
    m.add(node, kind, r); m.add(node, kind, mir(r))

def fuselage(secs, k=16, n=2.6):
    """secs = [(z, نصف عرض, ارتفاع علوي, ارتفاع سفلي, مركز y)] بترتيب z تصاعدي → جسم مصقول"""
    rings = []
    for z, w, top, bot, cy in secs:
        ring = []
        for i in range(k):
            a = 2 * math.pi * i / k; c, s = math.cos(a), math.sin(a)
            x = w * math.copysign(abs(c) ** (2 / n), c); y = cy + (top if s > 0 else bot) * math.copysign(abs(s) ** (2 / n), s)
            ring.append([x, y, z])
        rings.append(ring)
    return loft(rings, smooth=True, caps=True)

def wing(poly, y0, th, cant=0):
    """poly = [(z,x)] لجناح أيمن؛ سماكة th على y"""
    p = extrude(poly, -th / 2, th / 2, plane='zx')
    return place(p, rot(0, 0, cant), (0, y0, 0))

def missile(L=3.0, r=.13):
    body = cyl((0, 0, 0), r, L, 'z', seg=8)
    nose = cyl((0, 0, -L / 2 - .35), .01, .7, 'z', seg=8, r2=r)
    parts = [body, nose]
    for a in (0, 90, 180, 270):
        f = extrude([(0, 0), (.6, 0), (.6, .06), (0, .5)], -.015, .015, plane='zy')
        parts.append(place(f, rot(0, 0, a), (0, 0, L / 2 - .7)))
    return cat(*parts)

def nav(m, x, y, z, col):
    m.add('body', col, ellipsoid((x, y, z), (.14, .14, .14), seg=6, lat=4))

def build(v):
    m = Model(ground=False)
    # ---------------- الجسم
    if v == 0:   # مُعترِض: جناح دلتا، محرك واحد، زعنفة واحدة
        secs = [(-8.2, .02, .02, .02, .1), (-7.0, .25, .25, .22, .08), (-5.0, .6, .55, .5, .05), (-2.5, .95, .8, .65, .1),
                (0.5, 1.05, .85, .7, .1), (3.5, .95, .75, .6, .05), (5.4, .75, .6, .5, 0), (6.0, .6, .5, .5, 0)]
        wp = [(-1.0, 1.0), (2.4, 5.4), (3.6, 5.4), (4.2, 1.0)]; wy = -.25
        tail = [(3.8, 1.0), (5.9, 2.4), (6.5, 2.4), (6.3, 1.0)]
        xs = [0]; ncol = ('#5d6670', '#343a43', '#8a919b', '#262a31')
    elif v == 1:  # ضارب: جناح مائل، محركان، ذيلان مائلان
        secs = [(-8.2, .02, .02, .02, .1), (-7.2, .22, .22, .18, .1), (-5.2, .55, .5, .45, .1), (-2.8, 1.0, .75, .6, .1),
                (0.5, 1.45, .8, .65, .05), (3.5, 1.4, .75, .6, 0), (5.4, 1.25, .6, .55, 0), (6.0, 1.2, .55, .55, 0)]
        wp = [(-1.8, 1.2), (1.6, 5.6), (3.0, 5.6), (4.2, 1.2)]; wy = -.2
        tail = [(3.8, 1.2), (5.9, 3.0), (6.5, 3.0), (6.4, 1.2)]
        xs = [-.85, .85]; ncol = ('#4e5a52', '#2d3530', '#7b867e', '#1f2622')
    else:        # شبحي مع canard: جسم عريض مسطّح، ذيلان مائلان
        secs = [(-8.2, .02, .02, .02, .05), (-7.0, .3, .2, .18, .05), (-5.0, .75, .42, .4, .05), (-2.5, 1.2, .62, .5, .05),
                (0.5, 1.5, .7, .55, .05), (3.5, 1.45, .62, .5, 0), (5.4, 1.25, .5, .45, 0), (6.0, 1.2, .5, .45, 0)]
        wp = [(-1.2, 1.3), (1.4, 5.0), (3.4, 5.0), (4.2, 1.3)]; wy = -.1
        tail = [(4.0, 1.3), (5.8, 2.8), (6.5, 2.8), (6.4, 1.3)]
        xs = [-.85, .85]; ncol = ('#3c4048', '#22252b', '#5a5f69', '#15171b')
    m.add('body', 'paint', fuselage(secs))
    # ---------------- أجنحة + ذيول أفقية
    both(m, 'body', 'paint', wing(wp, wy, .2))
    both(m, 'body', 'paint', wing(tail, 0, .14), t=(0, 0, 0))
    if v == 2:   # كاناردات
        both(m, 'body', 'paint', wing([(-4.2, .9), (-3.0, 2.6), (-2.4, 2.6), (-2.6, .9)], .05, .1))
    # ---------------- زعانف
    fin = place(extrude([(3.6, .5), (6.2, 3.2 + v * .15), (6.9, 3.2 + v * .15), (6.6, .5)], -.06, .06, plane='zy'), None, (0, .4, 0))
    if v == 0: m.add('body', 'paint', place(extrude([(2.8, .4), (5.8, 3.4), (6.6, 3.4), (6.3, .4)], -.07, .07, plane='zy'), None, (0, .4, 0)))
    else:      both(m, 'body', 'paint', place(fin, rot(0, 0, -16), (1.15, 0, 0)))
    # ---------------- فتحات الهواء + فوهات
    if v == 0:
        both(m, 'body', 'metal', cbox((1.05, -.1, -2.4), (.8, .9, 2.8), .2))
    else:
        both(m, 'body', 'metal', cbox((1.2 + v * .15, -.4, -2.0), (1.0, 1.0, 3.2), .22))
    for x in xs:
        m.add('body', 'metal', cyl((x, 0, 6.0), .7 - (0 if v else .05), 1.4, 'z', seg=14, r2=.54))
        m.add('body', 'accent', cyl((x, 0, 5.4), .72, .12, 'z', seg=14))      # حلقة حمراء بالمحرك
    # ---------------- كابينة + أنف
    m.add('body', 'glass', ellipsoid((0, .75 + v * .02, -3.1 - v * .2), (.52, .5, 1.7), seg=12, lat=7))
    m.add('body', 'metal', cyl((0, .1, -8.4), .03, 1.4, 'z', seg=6))          # pitot
    # ---------------- صواريخ تحت الأجنحة + أطراف الجناح
    xw = wp[1][1]
    both(m, 'body', 'metal', missile(2.8), t=(2.8 if v else 2.4, wy - .3, 1.0))
    both(m, 'body', 'accent', cyl((0, 0, 0), .15, .35, 'z', seg=8), t=(2.8 if v else 2.4, wy - .3, .4))
    both(m, 'body', 'metal', missile(2.2, .1), t=(xw - .1, wy, 2.2))
    both(m, 'body', 'accent', cbox((xw, wy, 3.3), (.2, .16, .5), .04))        # شريط أحمر بطرف الجناح
    nav(m, -xw, wy, 2.4, 'navr'); nav(m, xw, wy, 2.4, 'navg')
    return m, xs, ncol

def mats(v, ncol):
    paint = tex_paint(512, palette=ncol, ratios=(.38, .3, .22, .1), seed=11 + v, panels=4, grime=.3, rough=.55, metal=.35)
    metal = tex_metal(256, base='#2a2d33', seed=21 + v, metal=.8, rough=.4)
    return {'paint': {'tex': paint, 'nscale': 1.0}, 'metal': {'tex': metal},
            'glass': {'color': [.04, .09, .14], 'metal': .9, 'rough': .08, 'emissive': [.05, .14, .26]},
            'accent': {'color': [.62, .09, .08], 'metal': .3, 'rough': .5},
            'navr': {'color': [1, .1, .1], 'emissive': [1, .1, .1]}, 'navg': {'color': [.1, 1, .3], 'emissive': [.1, 1, .3]}}

def pack(m, tex_kinds):
    groups = {}
    for node, kind, P, N in m.items():
        groups[kind] = (P, N, uv_planar(P, N, 9.0) if kind in tex_kinds else None, vcolors(P, N, ground=False))
    return [('body', None, groups)]

if __name__ == '__main__':
    prev = []
    for v in range(3):
        m, xs, ncol = build(v); M = mats(v, ncol); nodes = pack(m, ('paint', 'metal'))
        tris = sum(len(g[0]) // 3 for g in nodes[0][2].values())
        size = write_glb_hd(os.path.join(OUT, f'e_jet{v}.glb'), nodes, M)
        print(f'e_jet{v}.glb: {tris} مثلث، {size // 1024} KB')
        if '--preview' in sys.argv: prev.append(render_model(nodes, M, [(30, 18, f'jet{v} 3/4'), (90, 0, 'side'), (0, 90, 'top')], size=(420, 300)))
    if prev:
        from PIL import Image
        im = Image.new('RGB', (prev[0].width, sum(p.height for p in prev)))
        y = 0
        for p in prev: im.paste(p, (0, y)); y += p.height
        im.save('/tmp/ejets_preview.png'); print('preview ok')
